import express from 'express';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const app = express();
const PORT = 4000;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const dataDirectory = path.join(__dirname, 'server-data');
const dataFile = path.join(dataDirectory, 'complaints.json');

app.use(express.json());

/**
 * Simple CORS configuration for the DTIE prototype.
 * This allows the Vite frontend running on port 3000
 * to communicate with the Express backend on port 4000.
 */
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET,POST,PATCH,PUT,DELETE,OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.sendStatus(204);
    return;
  }

  next();
});

/**
 * Make sure the server-side data directory exists.
 */
async function ensureDataStore() {
  await fs.mkdir(dataDirectory, { recursive: true });

  try {
    await fs.access(dataFile);
  } catch {
    await fs.writeFile(dataFile, '[]', 'utf-8');
  }
}

/**
 * Read complaints from server-side storage.
 */
async function readComplaints(): Promise<any[]> {
  await ensureDataStore();

  const file = await fs.readFile(dataFile, 'utf-8');

  try {
    const data = JSON.parse(file);
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

/**
 * Save complaints to server-side storage.
 */
async function saveComplaints(complaints: any[]) {
  await ensureDataStore();

  await fs.writeFile(
    dataFile,
    JSON.stringify(complaints, null, 2),
    'utf-8'
  );
}

/**
 * Health check.
 */
app.get('/api/health', (_req, res) => {
  res.json({
    success: true,
    service: 'CivicPulse Backend',
    status: 'online',
    timestamp: new Date().toISOString(),
  });
});

/**
 * GET all complaints.
 */
app.get('/api/complaints', async (_req, res) => {
  try {
    const complaints = await readComplaints();

    res.json({
      success: true,
      count: complaints.length,
      complaints,
    });
  } catch (error) {
    console.error('Failed to read complaints:', error);

    res.status(500).json({
      success: false,
      message: 'Unable to retrieve complaints',
    });
  }
});

/**
 * GET a single complaint by ID.
 */
app.get('/api/complaints/:id', async (req, res) => {
  try {
    const complaints = await readComplaints();

    const complaint = complaints.find(
      (item) => item.id === req.params.id
    );

    if (!complaint) {
      res.status(404).json({
        success: false,
        message: 'Complaint not found',
      });
      return;
    }

    res.json({
      success: true,
      complaint,
    });
  } catch (error) {
    console.error('Failed to retrieve complaint:', error);

    res.status(500).json({
      success: false,
      message: 'Unable to retrieve complaint',
    });
  }
});

/**
 * CREATE a complaint.
 */
app.post('/api/complaints', async (req, res) => {
  try {
    const complaint = req.body;

    if (!complaint || !complaint.title || !complaint.description) {
      res.status(400).json({
        success: false,
        message: 'Title and description are required',
      });
      return;
    }

    const complaints = await readComplaints();

    const newComplaint = {
      ...complaint,
      createdAt: complaint.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    complaints.push(newComplaint);

    await saveComplaints(complaints);

    res.status(201).json({
      success: true,
      message: 'Complaint created successfully',
      complaint: newComplaint,
    });
  } catch (error) {
    console.error('Failed to create complaint:', error);

    res.status(500).json({
      success: false,
      message: 'Unable to create complaint',
    });
  }
});

/**
 * UPDATE a complaint.
 */
app.patch('/api/complaints/:id', async (req, res) => {
  try {
    const complaints = await readComplaints();

    const index = complaints.findIndex(
      (item) => item.id === req.params.id
    );

    if (index === -1) {
      res.status(404).json({
        success: false,
        message: 'Complaint not found',
      });
      return;
    }

    complaints[index] = {
      ...complaints[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    await saveComplaints(complaints);

    res.json({
      success: true,
      message: 'Complaint updated successfully',
      complaint: complaints[index],
    });
  } catch (error) {
    console.error('Failed to update complaint:', error);

    res.status(500).json({
      success: false,
      message: 'Unable to update complaint',
    });
  }
});

/**
 * DELETE a complaint.
 */
app.delete('/api/complaints/:id', async (req, res) => {
  try {
    const complaints = await readComplaints();

    const filtered = complaints.filter(
      (item) => item.id !== req.params.id
    );

    if (filtered.length === complaints.length) {
      res.status(404).json({
        success: false,
        message: 'Complaint not found',
      });
      return;
    }

    await saveComplaints(filtered);

    res.json({
      success: true,
      message: 'Complaint deleted successfully',
    });
  } catch (error) {
    console.error('Failed to delete complaint:', error);

    res.status(500).json({
      success: false,
      message: 'Unable to delete complaint',
    });
  }
});

ensureDataStore()
  .then(() => {
    app.listen(PORT, () => {
      console.log('');
      console.log('======================================');
      console.log('       CIVICPULSE BACKEND');
      console.log('======================================');
      console.log(`Server running on http://localhost:${PORT}`);
      console.log(`Health: http://localhost:${PORT}/api/health`);
      console.log(`API:    http://localhost:${PORT}/api/complaints`);
      console.log('======================================');
      console.log('');
    });
  })
  .catch((error) => {
    console.error('Failed to initialize CivicPulse backend:', error);
    process.exit(1);
  });