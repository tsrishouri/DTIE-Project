import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  Complaint,
  ComplaintCategory,
  ComplaintStatus,
  PriorityLevel,
  UserRole,
  MunicipalDepartment,
  FieldWorker,
  AuditLogEntry,
  ResolutionEvidence,
  WorkNote,
  AiTriageSuggestion,
} from '../types';
import { INITIAL_COMPLAINTS, DEMO_FIELD_WORKERS } from '../data/mockData';
import { extractWardName, extractZoneName } from '../utils/coordinates';
import { aiService } from '../services/aiService';

const STORAGE_KEY = 'civicpulse_complaints_v1';
const ROLE_STORAGE_KEY = 'civicpulse_active_role_v1';
const WORKERS_STORAGE_KEY = 'civicpulse_workers_v1';
const SELECTED_WORKER_KEY = 'civicpulse_selected_worker_v1';

interface CivicContextType {
  complaints: Complaint[];
  fieldWorkers: FieldWorker[];
  selectedWorkerId: string;
  setSelectedWorkerId: (id: string) => void;
  selectedWorker?: FieldWorker;
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  activeView: 'dashboard' | 'report' | 'track' | 'complaints' | 'analytics';
  setActiveView: (view: 'dashboard' | 'report' | 'track' | 'complaints' | 'analytics') => void;
  selectedComplaintId: string | null;
  setSelectedComplaintId: (id: string | null) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  selectedStatus: string;
  setSelectedStatus: (status: string) => void;
  selectedDepartment: string;
  setSelectedDepartment: (dept: string) => void;
  selectedPriority: string;
  setSelectedPriority: (priority: string) => void;
  selectedWard: string;
  setSelectedWard: (ward: string) => void;
  selectedZone: string;
  setSelectedZone: (zone: string) => void;
  createComplaint: (data: {
    title: string;
    description: string;
    category: ComplaintCategory;
    location: string;
    photoUrl?: string;
    citizenName: string;
    citizenPhone?: string;
    coordinates?: { lat: number; lng: number; capturedAt?: string; accuracy?: number };
    gpsCaptured?: boolean;
    gpsCapturedAt?: string;
    ward?: string;
    zone?: string;
    isContactMasked?: boolean;
    aiTriage?: AiTriageSuggestion;
  }) => string;
  triageComplaint: (
    complaintId: string,
    priority: PriorityLevel,
    department: MunicipalDepartment,
    deadlineHours: number,
    notes?: string,
    aiReview?: {
      accepted: boolean;
      suggestion?: AiTriageSuggestion;
    }
  ) => void;
  escalateComplaint: (complaintId: string, reason: string) => void;
  assignFieldWorker: (
    complaintId: string,
    worker: FieldWorker,
    customNote?: string
  ) => void;
  updateStatus: (
    complaintId: string,
    newStatus: ComplaintStatus,
    note: string,
    actor: string,
    role: UserRole | 'system',
    evidence?: ResolutionEvidence
  ) => void;
  startWork: (complaintId: string, workerName: string) => void;
  addWorkNote: (complaintId: string, workerName: string, noteText: string) => void;
  submitResolution: (
    complaintId: string,
    workerName: string,
    resolutionDescription: string,
    afterPhotoUrl: string,
    beforePhotoUrl?: string,
    partsReplaced?: string
  ) => void;
  verifyComplaint: (complaintId: string, citizenNotes?: string) => void;
  reopenComplaint: (complaintId: string, rejectionReason: string, reopenEvidenceUrl?: string) => void;
  reTriageComplaint: (
    complaintId: string,
    priority: PriorityLevel,
    department: MunicipalDepartment,
    deadlineHours: number,
    notes?: string
  ) => void;
  resetToDefaults: () => void;
}

import { getCategoryEvidence } from '../data/categoryEvidence';

const sanitizeDemoEvidence = (list: Complaint[]): Complaint[] => {
  return list.map((c) => {
    const template = getCategoryEvidence(c.category);

    // Sanitize initial photo if it was mismatched
    let photoUrl = c.photoUrl;
    if (c.category === 'Street Lights' && photoUrl?.includes('1515162816999')) {
      photoUrl = template.defaultBeforePhoto;
    }

    if (!c.evidence) {
      return { ...c, photoUrl };
    }

    let evidence = { ...c.evidence };

    // Street Lights category checks
    if (c.category === 'Street Lights') {
      const isRoadOrPotholeBefore =
        !evidence.beforePhotoUrl ||
        (evidence.beforePhotoUrl.includes('1515162816999') &&
          !evidence.beforePhotoUrl.startsWith('data:'));
      const isLandscapeOrRoadAfter =
        !evidence.afterPhotoUrl ||
        ((evidence.afterPhotoUrl.includes('1581092160607') ||
          evidence.afterPhotoUrl.includes('1581092335397') ||
          evidence.afterPhotoUrl.includes('1518241353330')) &&
          !evidence.afterPhotoUrl.startsWith('data:'));
      const isRoadMaterials =
        !evidence.partsReplaced ||
        evidence.partsReplaced.toLowerCase().includes('road') ||
        evidence.partsReplaced.toLowerCase().includes('asphalt') ||
        evidence.partsReplaced === 'Total Road is replaced and checked';
      const isRoadNotes =
        !evidence.workerNotes ||
        evidence.workerNotes.toLowerCase().includes('road') ||
        evidence.workerNotes.toLowerCase().includes('asphalt');

      if (isRoadOrPotholeBefore || isLandscapeOrRoadAfter || isRoadMaterials || isRoadNotes) {
        evidence = {
          ...evidence,
          beforePhotoUrl: isRoadOrPotholeBefore ? template.defaultBeforePhoto : evidence.beforePhotoUrl,
          afterPhotoUrl: isLandscapeOrRoadAfter ? template.defaultAfterPhoto : evidence.afterPhotoUrl,
          photoUrl: isLandscapeOrRoadAfter ? template.defaultAfterPhoto : evidence.photoUrl || template.defaultAfterPhoto,
          partsReplaced: isRoadMaterials ? template.defaultMaterialsUsed : evidence.partsReplaced,
          workerNotes: isRoadNotes ? template.defaultResolutionDescription : evidence.workerNotes,
          resolutionDescription:
            !evidence.resolutionDescription ||
            evidence.resolutionDescription.toLowerCase().includes('road')
              ? template.defaultResolutionDescription
              : evidence.resolutionDescription,
        };
      }
    } else if (c.category !== 'Roads') {
      // For any non-road category, check if old road materials or pothole photo leaked in
      const hasRoadMaterials =
        evidence.partsReplaced &&
        (evidence.partsReplaced.toLowerCase().includes('asphalt') ||
          evidence.partsReplaced === 'Total Road is replaced and checked');
      const hasPotholeBefore =
        evidence.beforePhotoUrl &&
        evidence.beforePhotoUrl.includes('1515162816999') &&
        !evidence.beforePhotoUrl.startsWith('data:');

      if (hasRoadMaterials || hasPotholeBefore) {
        evidence = {
          ...evidence,
          beforePhotoUrl: hasPotholeBefore ? template.defaultBeforePhoto : evidence.beforePhotoUrl,
          afterPhotoUrl: evidence.afterPhotoUrl || template.defaultAfterPhoto,
          partsReplaced: hasRoadMaterials ? template.defaultMaterialsUsed : evidence.partsReplaced,
          resolutionDescription:
            evidence.resolutionDescription || template.defaultResolutionDescription,
          workerNotes: evidence.workerNotes || template.defaultResolutionDescription,
        };
      }
    }

    // Sanitize timeline if Street Lighting had road comments
    const timeline = c.timeline.map((entry) => {
      if (
        c.category === 'Street Lights' &&
        entry.comment &&
        (entry.comment.toLowerCase().includes('road') ||
          entry.comment.toLowerCase().includes('asphalt'))
      ) {
        return {
          ...entry,
          comment: 'Repairs completed and verified live. Submitted luminaire replacement photo evidence.',
        };
      }
      return entry;
    });

    const ward = c.ward || extractWardName(c.location);
    const zone = c.zone || extractZoneName(c.location, ward);

    return {
      ...c,
      ward,
      zone,
      photoUrl,
      evidence,
      timeline,
      resolutionDescription:
        c.category === 'Street Lights' &&
        c.resolutionDescription?.toLowerCase().includes('road')
          ? template.defaultResolutionDescription
          : c.resolutionDescription || evidence.resolutionDescription,
    };
  });
};

const CivicContext = createContext<CivicContextType | undefined>(undefined);

export const CivicProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [complaints, setComplaints] = useState<Complaint[]>(() => {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) {
          const parsed: Complaint[] = JSON.parse(stored);
          if (Array.isArray(parsed) && parsed.length > 0) {
            const sanitized = sanitizeDemoEvidence(parsed);
            // Ensure CP-2026-9944 exists if missing
            const has9944 = sanitized.some((c) => c.id === 'CP-2026-9944');
            if (!has9944) {
              const seed9944 = INITIAL_COMPLAINTS.find((c) => c.id === 'CP-2026-9944');
              if (seed9944) {
                return [seed9944, ...sanitized];
              }
            }
            return sanitized;
          }
        }
      }
    } catch (e) {
      console.warn('Could not read complaints from localStorage, using initial defaults:', e);
    }
    return INITIAL_COMPLAINTS;
  });

  const [fieldWorkers, setFieldWorkers] = useState<FieldWorker[]>(() => {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        const stored = localStorage.getItem(WORKERS_STORAGE_KEY);
        if (stored) {
          const parsed = JSON.parse(stored);
          if (Array.isArray(parsed) && parsed.length > 0) {
            return parsed;
          }
        }
      }
    } catch (e) {
      console.warn('Could not read workers from localStorage:', e);
    }
    return DEMO_FIELD_WORKERS;
  });

  const [selectedWorkerId, setSelectedWorkerIdState] = useState<string>(() => {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        const stored = localStorage.getItem(SELECTED_WORKER_KEY);
        if (stored && DEMO_FIELD_WORKERS.some((w) => w.id === stored)) {
          return stored;
        }
      }
    } catch (e) {
      console.warn('Could not read selected worker id:', e);
    }
    return DEMO_FIELD_WORKERS[0].id; // Default to Ravi Kumar (w-101)
  });

  const [currentRole, setCurrentRoleState] = useState<UserRole>(() => {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        const stored = localStorage.getItem(ROLE_STORAGE_KEY) as UserRole;
        if (stored && ['citizen', 'field_worker', 'supervisor'].includes(stored)) {
          return stored;
        }
      }
    } catch (e) {
      console.warn('Could not read role from localStorage:', e);
    }
    return 'citizen';
  });

  const [activeView, setActiveView] = useState<'dashboard' | 'report' | 'track' | 'complaints' | 'analytics'>('dashboard');
  const [selectedComplaintId, setSelectedComplaintId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [selectedDepartment, setSelectedDepartment] = useState<string>('ALL');
  const [selectedPriority, setSelectedPriority] = useState<string>('ALL');
  const [selectedWard, setSelectedWard] = useState<string>('ALL');
  const [selectedZone, setSelectedZone] = useState<string>('ALL');

  // Persist complaints safely
  useEffect(() => {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(complaints));
      }
    } catch (e) {
      console.warn('Failed to persist complaints to localStorage:', e);
    }
  }, [complaints]);

  // Persist workers safely
  useEffect(() => {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        localStorage.setItem(WORKERS_STORAGE_KEY, JSON.stringify(fieldWorkers));
      }
    } catch (e) {
      console.warn('Failed to persist workers to localStorage:', e);
    }
  }, [fieldWorkers]);

  const setSelectedWorkerId = (id: string) => {
    setSelectedWorkerIdState(id);
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        localStorage.setItem(SELECTED_WORKER_KEY, id);
      }
    } catch (e) {
      console.warn('Failed to save selected worker id:', e);
    }
  };

  const selectedWorker = fieldWorkers.find((w) => w.id === selectedWorkerId);

  const setCurrentRole = (role: UserRole) => {
    setCurrentRoleState(role);
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        localStorage.setItem(ROLE_STORAGE_KEY, role);
      }
    } catch (e) {
      console.warn('Failed to save role:', e);
    }
  };

  const createComplaint = (data: {
    title: string;
    description: string;
    category: ComplaintCategory;
    location: string;
    photoUrl?: string;
    citizenName: string;
    citizenPhone?: string;
    coordinates?: { lat: number; lng: number; capturedAt?: string; accuracy?: number };
    gpsCaptured?: boolean;
    gpsCapturedAt?: string;
    ward?: string;
    zone?: string;
    isContactMasked?: boolean;
    aiTriage?: AiTriageSuggestion;
  }): string => {
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const newId = `CP-2026-${randomSuffix}`;
    const nowIso = new Date().toISOString();

    const ward = data.ward || extractWardName(data.location);
    const zone = data.zone || extractZoneName(data.location, ward);

    // Duplicate detection check
    const dupCheck = aiService.detectDuplicates(
      {
        title: data.title,
        description: data.description,
        category: data.category,
        location: data.location,
      },
      complaints
    );

    const newComplaint: Complaint = {
      id: newId,
      title: data.title.trim(),
      description: data.description.trim(),
      category: data.category,
      location: data.location.trim(),
      ward,
      zone,
      coordinates: data.coordinates,
      gpsCaptured: data.gpsCaptured,
      gpsCapturedAt: data.gpsCapturedAt,
      isContactMasked: data.isContactMasked ?? true,
      aiTriage: data.aiTriage,
      potentialDuplicate: dupCheck.isDuplicate ? dupCheck : undefined,
      photoUrl: data.photoUrl,
      status: 'REPORTED',
      priority: data.aiTriage?.suggestedPriority || 'MEDIUM',
      createdAt: nowIso,
      updatedAt: nowIso,
      citizenName: data.citizenName.trim() || 'Anonymous Citizen',
      citizenPhone: data.citizenPhone?.trim(),
      workNotes: [],
      timeline: [
        {
          id: `log-${Date.now()}`,
          timestamp: nowIso,
          status: 'REPORTED',
          actor: data.citizenName.trim() || 'Citizen',
          actorRole: 'citizen',
          comment: data.gpsCaptured
            ? `Complaint registered with verified GPS coordinates and photo evidence in ${ward} (${zone}).`
            : `Complaint registered via CivicPulse portal with photo evidence in ${ward}.`,
        },
      ],
    };

    setComplaints((prev) => [newComplaint, ...prev]);
    return newId;
  };

  const triageComplaint = (
    complaintId: string,
    priority: PriorityLevel,
    department: MunicipalDepartment,
    deadlineHours: number,
    notes?: string,
    aiReview?: {
      accepted: boolean;
      suggestion?: AiTriageSuggestion;
    }
  ) => {
    const nowIso = new Date().toISOString();
    const deadlineIso = new Date(Date.now() + deadlineHours * 3600 * 1000).toISOString();

    const existingComplaint = complaints.find((item) => item.id === complaintId);
    const isReTriage = existingComplaint?.status === 'REOPENED';
    let auditMessage = isReTriage
      ? `Complaint re-triaged after citizen rejection: Department: ${department}, Priority: ${priority}, SLA: ${deadlineHours} hours.${
          notes?.trim() ? ' Notes: ' + notes.trim() : ''
        }`
      : notes?.trim()
      ? `Triage decision: Department: ${department}, Priority: ${priority}, SLA: ${deadlineHours} hours. Notes: ${notes.trim()}`
      : `Triage decision: Department: ${department}, Priority: ${priority}, SLA: ${deadlineHours} hours.`;

    if (aiReview?.accepted) {
      auditMessage += ` [AI Triage Recommendation Accepted: ${Math.round((aiReview.suggestion?.confidence || 0.9) * 100)}% Confidence]`;
    } else if (aiReview && !aiReview.accepted) {
      auditMessage += ` [Supervisor Overrode AI Suggestion: Adjusted to ${priority} / ${department}]`;
    }

    const newLog: AuditLogEntry = {
      id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      timestamp: nowIso,
      status: 'TRIAGED',
      actor: 'Municipal Supervisor',
      actorRole: 'SUPERVISOR',
      comment: auditMessage,
    };

    setComplaints((prev) =>
      prev.map((c) => {
        if (c.id !== complaintId) return c;
        const updatedAi = c.aiTriage || aiReview?.suggestion
          ? {
              ...(c.aiTriage || aiReview?.suggestion!),
              acceptedBySupervisor: aiReview?.accepted ?? false,
              supervisorOverridden: aiReview ? !aiReview.accepted : false,
            }
          : undefined;

        return {
          ...c,
          status: 'TRIAGED',
          priority,
          department,
          assignedDepartment: department,
          deadline: deadlineIso,
          triageNotes: notes?.trim() || c.triageNotes,
          aiTriage: updatedAi,
          updatedAt: nowIso,
          timeline: [...c.timeline, newLog],
        };
      })
    );
  };

  const escalateComplaint = (complaintId: string, reason: string) => {
    const nowIso = new Date().toISOString();
    const emergencyDeadline = new Date(Date.now() + 6 * 3600 * 1000).toISOString();

    setComplaints((prev) =>
      prev.map((c) => {
        if (c.id !== complaintId) return c;
        const newLog: AuditLogEntry = {
          id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          timestamp: nowIso,
          status: c.status,
          actor: 'Municipal Supervisor',
          actorRole: 'SUPERVISOR',
          comment: `🚨 EMERGENCY SLA ESCALATION: Complaint expedited by supervisor. Reason: ${reason.trim()}`,
        };

        return {
          ...c,
          priority: 'CRITICAL',
          isEscalated: true,
          escalatedAt: nowIso,
          escalatedReason: reason.trim(),
          deadline: emergencyDeadline,
          updatedAt: nowIso,
          timeline: [...c.timeline, newLog],
        };
      })
    );
  };

  const reTriageComplaint = (
    complaintId: string,
    priority: PriorityLevel,
    department: MunicipalDepartment,
    deadlineHours: number,
    notes?: string
  ) => {
    triageComplaint(complaintId, priority, department, deadlineHours, notes);
  };

  const assignFieldWorker = (
    complaintId: string,
    worker: FieldWorker,
    customNote?: string
  ) => {
    const nowIso = new Date().toISOString();

    setComplaints((prev) =>
      prev.map((c) => {
        if (c.id !== complaintId) return c;

        const isReassignment = c.status === 'REOPENED' || (c.assignedWorker && c.assignedWorker !== worker.name);
        const auditMessage = customNote?.trim()
          ? customNote.trim()
          : isReassignment && c.status === 'REOPENED'
          ? `Complaint reassigned to ${worker.name} (${worker.department}) following citizen rejection.`
          : isReassignment
          ? `Complaint reassigned to ${worker.name} (${worker.department}).`
          : `Complaint assigned to ${worker.name}.`;

        const newLog: AuditLogEntry = {
          id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          timestamp: nowIso,
          status: 'ASSIGNED',
          actor: 'Municipal Supervisor',
          actorRole: 'SUPERVISOR',
          comment: auditMessage,
        };

        return {
          ...c,
          status: 'ASSIGNED',
          assignedWorker: worker.name,
          assignedWorkerId: worker.id,
          assignedDepartment: worker.department,
          department: worker.department,
          updatedAt: nowIso,
          timeline: [...c.timeline, newLog],
        };
      })
    );

    // Increment worker workload
    setFieldWorkers((prev) =>
      prev.map((w) => {
        if (w.id === worker.id) {
          return { ...w, currentWorkload: w.currentWorkload + 1 };
        }
        return w;
      })
    );
  };

  const updateStatus = (
    complaintId: string,
    newStatus: ComplaintStatus,
    note: string,
    actor: string,
    role: UserRole | 'system',
    evidence?: ResolutionEvidence
  ) => {
    const nowIso = new Date().toISOString();
    setComplaints((prev) =>
      prev.map((c) => {
        if (c.id !== complaintId) return c;

        const newLog: AuditLogEntry = {
          id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          timestamp: nowIso,
          status: newStatus,
          actor,
          actorRole: role,
          comment: note,
        };

        return {
          ...c,
          status: newStatus,
          updatedAt: nowIso,
          evidence: evidence || c.evidence,
          timeline: [...c.timeline, newLog],
        };
      })
    );
  };

  // Phase 3: Start work action
  const startWork = (complaintId: string, workerName: string) => {
    const nowIso = new Date().toISOString();
    const newLog: AuditLogEntry = {
      id: `log-${Date.now()}-start`,
      timestamp: nowIso,
      status: 'IN PROGRESS',
      actor: workerName,
      actorRole: 'field_worker',
      comment: 'Field worker started work on the complaint.',
    };

    setComplaints((prev) =>
      prev.map((c) => {
        if (c.id !== complaintId) return c;
        return {
          ...c,
          status: 'IN PROGRESS',
          updatedAt: nowIso,
          timeline: [...c.timeline, newLog],
        };
      })
    );
  };

  // Phase 3: Add work note without overwriting previous notes
  const addWorkNote = (complaintId: string, workerName: string, noteText: string) => {
    if (!noteText.trim()) return;
    const nowIso = new Date().toISOString();

    const newNote: WorkNote = {
      id: `wn-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      timestamp: nowIso,
      workerName,
      note: noteText.trim(),
    };

    const newLog: AuditLogEntry = {
      id: `log-${Date.now()}-note`,
      timestamp: nowIso,
      status: 'IN PROGRESS',
      actor: workerName,
      actorRole: 'field_worker',
      comment: `Work Note: "${noteText.trim()}"`,
    };

    setComplaints((prev) =>
      prev.map((c) => {
        if (c.id !== complaintId) return c;
        const existingNotes = c.workNotes || [];
        return {
          ...c,
          workNotes: [...existingNotes, newNote],
          updatedAt: nowIso,
          timeline: [...c.timeline, newLog],
        };
      })
    );
  };

  // Phase 3: Submit resolution with description, before/after evidence
  const submitResolution = (
    complaintId: string,
    workerName: string,
    resolutionDescription: string,
    afterPhotoUrl: string,
    beforePhotoUrl?: string,
    partsReplaced?: string
  ) => {
    const nowIso = new Date().toISOString();
    const evidence: ResolutionEvidence = {
      submittedAt: nowIso,
      submittedBy: workerName,
      workerNotes: resolutionDescription.trim(),
      photoUrl: afterPhotoUrl,
      afterPhotoUrl: afterPhotoUrl,
      beforePhotoUrl: beforePhotoUrl || undefined,
      partsReplaced: partsReplaced?.trim() || undefined,
      resolutionDescription: resolutionDescription.trim(),
    };

    const log1: AuditLogEntry = {
      id: `log-${Date.now()}-res`,
      timestamp: nowIso,
      status: 'RESOLUTION SUBMITTED',
      actor: workerName,
      actorRole: 'field_worker',
      comment: `Resolution submitted: ${resolutionDescription.trim()}`,
    };

    const log2: AuditLogEntry = {
      id: `log-${Date.now()}-ver`,
      timestamp: nowIso,
      status: 'AWAITING VERIFICATION',
      actor: 'CivicPulse Dispatcher',
      actorRole: 'system',
      comment: 'Work marked complete. Transferred to Citizen for resolution verification.',
    };

    setComplaints((prev) =>
      prev.map((c) => {
        if (c.id !== complaintId) return c;
        return {
          ...c,
          status: 'AWAITING VERIFICATION',
          resolutionDescription: resolutionDescription.trim(),
          updatedAt: nowIso,
          evidence,
          timeline: [...c.timeline, log1, log2],
        };
      })
    );
  };

  const verifyComplaint = (complaintId: string, citizenNotes?: string) => {
    const nowIso = new Date().toISOString();
    setComplaints((prev) =>
      prev.map((c) => {
        if (c.id !== complaintId) return c;

        const verifier = c.citizenName || 'Citizen';
        const verifyMessage = citizenNotes?.trim()
          ? `Citizen verified that the reported issue was resolved. Note: "${citizenNotes.trim()}"`
          : 'Citizen verified that the reported issue was resolved.';

        // Entry 1: status = VERIFIED, actor = Citizen, actorRole = CITIZEN
        const logVerified: AuditLogEntry = {
          id: `log-${Date.now()}-ver`,
          timestamp: nowIso,
          status: 'VERIFIED',
          actor: verifier,
          actorRole: 'CITIZEN',
          comment: verifyMessage,
        };

        // Entry 2: status = CLOSED, actor = System, actorRole = SYSTEM
        const logClosed: AuditLogEntry = {
          id: `log-${Date.now() + 1}-closed`,
          timestamp: nowIso,
          status: 'CLOSED',
          actor: 'System',
          actorRole: 'SYSTEM',
          comment: 'Complaint closed after citizen verification.',
        };

        return {
          ...c,
          status: 'CLOSED',
          updatedAt: nowIso,
          verifiedAt: nowIso,
          closedAt: nowIso,
          verifiedBy: verifier,
          citizenVerificationNote: citizenNotes?.trim() || 'Citizen verified that the reported issue was resolved.',
          timeline: [...c.timeline, logVerified, logClosed],
        };
      })
    );
  };

  const reopenComplaint = (
    complaintId: string,
    rejectionReason: string,
    reopenEvidenceUrl?: string
  ) => {
    if (!rejectionReason.trim()) return;
    const nowIso = new Date().toISOString();

    setComplaints((prev) =>
      prev.map((c) => {
        if (c.id !== complaintId) return c;

        const reopener = c.citizenName || 'Citizen';
        const reopenMessage = `Citizen rejected resolution: "${rejectionReason.trim()}". Municipal action is required again.`;

        const newLog: AuditLogEntry = {
          id: `log-${Date.now()}-reopen`,
          timestamp: nowIso,
          status: 'REOPENED',
          actor: reopener,
          actorRole: 'CITIZEN',
          comment: reopenMessage,
        };

        return {
          ...c,
          status: 'REOPENED',
          updatedAt: nowIso,
          reopenedAt: nowIso,
          reopenReason: rejectionReason.trim(),
          reopenedBy: reopener,
          reopenEvidenceUrl: reopenEvidenceUrl || undefined,
          timeline: [...c.timeline, newLog],
        };
      })
    );
  };

  const resetToDefaults = () => {
    setComplaints(INITIAL_COMPLAINTS);
    setFieldWorkers(DEMO_FIELD_WORKERS);
    setSelectedWorkerIdState(DEMO_FIELD_WORKERS[0].id);
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_COMPLAINTS));
        localStorage.setItem(WORKERS_STORAGE_KEY, JSON.stringify(DEMO_FIELD_WORKERS));
        localStorage.setItem(SELECTED_WORKER_KEY, DEMO_FIELD_WORKERS[0].id);
      }
    } catch (e) {
      console.warn('Reset error:', e);
    }
  };

  return (
    <CivicContext.Provider
      value={{
        complaints,
        fieldWorkers,
        selectedWorkerId,
        setSelectedWorkerId,
        selectedWorker,
        currentRole,
        setCurrentRole,
        activeView,
        setActiveView,
        selectedComplaintId,
        setSelectedComplaintId,
        searchQuery,
        setSearchQuery,
        selectedCategory,
        setSelectedCategory,
        selectedStatus,
        setSelectedStatus,
        selectedDepartment,
        setSelectedDepartment,
        selectedPriority,
        setSelectedPriority,
        selectedWard,
        setSelectedWard,
        selectedZone,
        setSelectedZone,
        createComplaint,
        triageComplaint,
        escalateComplaint,
        assignFieldWorker,
        updateStatus,
        startWork,
        addWorkNote,
        submitResolution,
        verifyComplaint,
        reopenComplaint,
        reTriageComplaint,
        resetToDefaults,
      }}
    >
      {children}
    </CivicContext.Provider>
  );
};

export const useCivic = (): CivicContextType => {
  const context = useContext(CivicContext);
  if (!context) {
    throw new Error('useCivic must be used within a CivicProvider');
  }
  return context;
};
