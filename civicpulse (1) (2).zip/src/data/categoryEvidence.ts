import { ComplaintCategory } from '../types';

export interface CategoryEvidenceTemplate {
  category: ComplaintCategory;
  defaultBeforePhoto: string;
  defaultAfterPhoto: string;
  defaultResolutionDescription: string;
  defaultMaterialsUsed: string;
  beforePresets: { label: string; url: string }[];
  afterPresets: { label: string; url: string }[];
}

export const CATEGORY_EVIDENCE_MAP: Record<ComplaintCategory, CategoryEvidenceTemplate> = {
  'Street Lights': {
    category: 'Street Lights',
    defaultBeforePhoto:
      'https://images.unsplash.com/photo-1509114397022-ed747cca3f65?w=600&auto=format&fit=crop&q=80',
    defaultAfterPhoto:
      'https://images.unsplash.com/photo-1517646287270-a5a9ca602e5c?w=600&auto=format&fit=crop&q=80',
    defaultResolutionDescription:
      'Replaced burnt out 120W LED luminaire module and repaired faulty wiring in junction box. Re-energized and verified full illumination.',
    defaultMaterialsUsed:
      '120W Philips LED Luminaire, High-voltage junction connector, 10AWG grounding clamp',
    beforePresets: [
      {
        label: 'Dark / Unlit Street Light',
        url: 'https://images.unsplash.com/photo-1509114397022-ed747cca3f65?w=600&auto=format&fit=crop&q=80',
      },
      {
        label: 'Damaged Luminaire Housing',
        url: 'https://images.unsplash.com/photo-1517524206127-48bbd363f3d7?w=600&auto=format&fit=crop&q=80',
      },
    ],
    afterPresets: [
      {
        label: 'Illuminated LED Street Light',
        url: 'https://images.unsplash.com/photo-1517646287270-a5a9ca602e5c?w=600&auto=format&fit=crop&q=80',
      },
      {
        label: 'Restored Pathway Lighting',
        url: 'https://images.unsplash.com/photo-1507499739999-097706ad8914?w=600&auto=format&fit=crop&q=80',
      },
    ],
  },

  'Roads': {
    category: 'Roads',
    defaultBeforePhoto:
      'https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?w=600&auto=format&fit=crop&q=80',
    defaultAfterPhoto:
      'https://images.unsplash.com/photo-1518241353330-0f7941c2d9b5?w=600&auto=format&fit=crop&q=80',
    defaultResolutionDescription:
      'Excavated damaged road section, applied emulsion tack coat, filled with 60kg hot-mix asphalt and compacted flush with roller.',
    defaultMaterialsUsed:
      '60kg Bitumen hot-mix asphalt, Tack coat emulsion, Road edge sealant',
    beforePresets: [
      {
        label: 'Deep Road Pothole',
        url: 'https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?w=600&auto=format&fit=crop&q=80',
      },
      {
        label: 'Cracked Pavement Collapse',
        url: 'https://images.unsplash.com/photo-1584463699042-327c5bf383fa?w=600&auto=format&fit=crop&q=80',
      },
    ],
    afterPresets: [
      {
        label: 'Compacted Asphalt Road Patch',
        url: 'https://images.unsplash.com/photo-1518241353330-0f7941c2d9b5?w=600&auto=format&fit=crop&q=80',
      },
      {
        label: 'Smooth Finished Pavement',
        url: 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?w=600&auto=format&fit=crop&q=80',
      },
    ],
  },

  'Water Supply': {
    category: 'Water Supply',
    defaultBeforePhoto:
      'https://images.unsplash.com/photo-1541888946425-d0fbb186f5f8?w=600&auto=format&fit=crop&q=80',
    defaultAfterPhoto:
      'https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=600&auto=format&fit=crop&q=80',
    defaultResolutionDescription:
      'Excavated trench, isolated ruptured pipeline section, welded new heavy-duty HDPE pipe collar and replaced gate valve. Pressure tested to 6 bar.',
    defaultMaterialsUsed:
      '6-inch HDPE pipe coupling, Stainless steel repair clamp, Pressure gate valve',
    beforePresets: [
      {
        label: 'Ruptured Water Main Pipeline',
        url: 'https://images.unsplash.com/photo-1541888946425-d0fbb186f5f8?w=600&auto=format&fit=crop&q=80',
      },
      {
        label: 'Leaking Pipe Joint',
        url: 'https://images.unsplash.com/photo-1585704032915-c3400ca199e7?w=600&auto=format&fit=crop&q=80',
      },
    ],
    afterPresets: [
      {
        label: 'Secured Pipeline & Valve Connection',
        url: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=600&auto=format&fit=crop&q=80',
      },
      {
        label: 'Repaired Pressure Pipe Section',
        url: 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=600&auto=format&fit=crop&q=80',
      },
    ],
  },

  'Garbage': {
    category: 'Garbage',
    defaultBeforePhoto:
      'https://images.unsplash.com/photo-1530587191325-3db32d826c18?w=600&auto=format&fit=crop&q=80',
    defaultAfterPhoto:
      'https://images.unsplash.com/photo-1563245372-f21724e3856d?w=600&auto=format&fit=crop&q=80',
    defaultResolutionDescription:
      'Compactor truck cleared 2.8 tons of accumulated waste from container area. Cleared perimeter and disinfected apron with lime spray.',
    defaultMaterialsUsed:
      'Hydraulic waste compactor service, Municipal disinfectant spray, Heavy-duty liners',
    beforePresets: [
      {
        label: 'Overflowing Waste Dumpster',
        url: 'https://images.unsplash.com/photo-1530587191325-3db32d826c18?w=600&auto=format&fit=crop&q=80',
      },
      {
        label: 'Accumulated Public Trash',
        url: 'https://images.unsplash.com/photo-1605600659908-0ef719419d41?w=600&auto=format&fit=crop&q=80',
      },
    ],
    afterPresets: [
      {
        label: 'Cleared & Disinfected Collection Station',
        url: 'https://images.unsplash.com/photo-1563245372-f21724e3856d?w=600&auto=format&fit=crop&q=80',
      },
      {
        label: 'Cleaned Public Pavement',
        url: 'https://images.unsplash.com/photo-1528740561666-dc2479dc08ab?w=600&auto=format&fit=crop&q=80',
      },
    ],
  },

  'Drainage': {
    category: 'Drainage',
    defaultBeforePhoto:
      'https://images.unsplash.com/photo-1544717305-2782549b5136?w=600&auto=format&fit=crop&q=80',
    defaultAfterPhoto:
      'https://images.unsplash.com/photo-1574958269340-fa927503f3dd?w=600&auto=format&fit=crop&q=80',
    defaultResolutionDescription:
      'Hydro-jetting unit cleared severe silt and root obstruction inside storm culvert. Grating cleaned and re-anchored for unobstructed gravity flow.',
    defaultMaterialsUsed:
      'High-pressure vacuum de-silting, Cast-iron grating anchors, Bio-enzyme cleaner',
    beforePresets: [
      {
        label: 'Clogged Storm Drain Inlet',
        url: 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=600&auto=format&fit=crop&q=80',
      },
      {
        label: 'Flooded Street Gutter & Silt',
        url: 'https://images.unsplash.com/photo-1508873696983-2df5293cb32b?w=600&auto=format&fit=crop&q=80',
      },
    ],
    afterPresets: [
      {
        label: 'Cleared Flowing Drainage Channel',
        url: 'https://images.unsplash.com/photo-1574958269340-fa927503f3dd?w=600&auto=format&fit=crop&q=80',
      },
      {
        label: 'Unblocked Storm Culvert',
        url: 'https://images.unsplash.com/photo-1519817650390-64a93db51149?w=600&auto=format&fit=crop&q=80',
      },
    ],
  },

  'Public Safety': {
    category: 'Public Safety',
    defaultBeforePhoto:
      'https://images.unsplash.com/photo-1584438784894-089d6a62b8fa?w=600&auto=format&fit=crop&q=80',
    defaultAfterPhoto:
      'https://images.unsplash.com/photo-1578575437130-527eed3abbec?w=600&auto=format&fit=crop&q=80',
    defaultResolutionDescription:
      'Removed damaged pedestrian barrier, anchored structural steel posts and installed powder-coated yellow safety railing with reflective warning panels.',
    defaultMaterialsUsed:
      'Galvanized pedestrian safety railing, M16 expansion anchor bolts, High-intensity reflective tape',
    beforePresets: [
      {
        label: 'Damaged Safety Barricade',
        url: 'https://images.unsplash.com/photo-1584438784894-089d6a62b8fa?w=600&auto=format&fit=crop&q=80',
      },
      {
        label: 'Hazardous Walkway Obstruction',
        url: 'https://images.unsplash.com/photo-1508873696983-2df5293cb32b?w=600&auto=format&fit=crop&q=80',
      },
    ],
    afterPresets: [
      {
        label: 'Restored Steel Safety Barrier',
        url: 'https://images.unsplash.com/photo-1578575437130-527eed3abbec?w=600&auto=format&fit=crop&q=80',
      },
      {
        label: 'Secured Public Infrastructure',
        url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=600&auto=format&fit=crop&q=80',
      },
    ],
  },

  'Other': {
    category: 'Other',
    defaultBeforePhoto:
      'https://images.unsplash.com/photo-1584467735815-f778f274e296?w=600&auto=format&fit=crop&q=80',
    defaultAfterPhoto:
      'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=600&auto=format&fit=crop&q=80',
    defaultResolutionDescription:
      'Municipal maintenance team completed structural repair, hardware replacement, and verified facility safety compliance.',
    defaultMaterialsUsed:
      'Structural mounting hardware, Weatherproof protective coating',
    beforePresets: [
      {
        label: 'Damaged Municipal Asset',
        url: 'https://images.unsplash.com/photo-1584467735815-f778f274e296?w=600&auto=format&fit=crop&q=80',
      },
    ],
    afterPresets: [
      {
        label: 'Restored Municipal Facility',
        url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=600&auto=format&fit=crop&q=80',
      },
    ],
  },
};

export function getCategoryEvidence(category: ComplaintCategory): CategoryEvidenceTemplate {
  return CATEGORY_EVIDENCE_MAP[category] || CATEGORY_EVIDENCE_MAP['Other'];
}
