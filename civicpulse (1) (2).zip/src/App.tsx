import React, { useState } from 'react';
import { CivicProvider, useCivic } from './context/CivicContext';
import { Navbar } from './components/Navbar';
import { CitizenDashboard } from './components/CitizenDashboard';
import { FieldWorkerDashboard } from './components/FieldWorkerDashboard';
import { SupervisorDashboard } from './components/SupervisorDashboard';
import { ReportIssueModal } from './components/ReportIssueModal';
import { TrackComplaintView } from './components/TrackComplaintView';
import { ComplaintDetailModal } from './components/ComplaintDetailModal';
import { CommandCenterView } from './components/CommandCenterView';
import { Complaint } from './types';
import { Building2, ShieldCheck, HeartHandshake } from 'lucide-react';

function CivicPulseContent() {
  const { currentRole, activeView } = useCivic();
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col text-slate-800 font-sans antialiased">
      {/* Navbar with Role Switcher */}
      <Navbar />

      {/* Main View Area */}
      <main className="flex-1 pb-16">
        {activeView === 'report' ? (
          <ReportIssueModal />
        ) : activeView === 'track' ? (
          <TrackComplaintView onSelectComplaint={(c) => setSelectedComplaint(c)} />
        ) : activeView === 'analytics' ? (
          <CommandCenterView onSelectComplaint={(c) => setSelectedComplaint(c)} />
        ) : currentRole === 'citizen' ? (
          <CitizenDashboard onSelectComplaint={(c) => setSelectedComplaint(c)} />
        ) : currentRole === 'field_worker' ? (
          <FieldWorkerDashboard onSelectComplaint={(c) => setSelectedComplaint(c)} />
        ) : (
          <SupervisorDashboard onSelectComplaint={(c) => setSelectedComplaint(c)} />
        )}
      </main>

      {/* Detail / Lifecycle / Verification Modal */}
      {selectedComplaint && (
        <ComplaintDetailModal
          complaint={selectedComplaint}
          onClose={() => setSelectedComplaint(null)}
        />
      )}

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 text-slate-400 py-8 px-4 text-xs">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-emerald-400" />
            <span className="font-bold text-white text-sm">CivicPulse</span>
            <span className="text-slate-500">•</span>
            <span>Civic Issue Reporting & Resolution System</span>
          </div>

          <div className="flex items-center gap-6 text-slate-400">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              <span>Verifiable Resolution Protocol</span>
            </span>
            <span className="flex items-center gap-1.5">
              <HeartHandshake className="w-4 h-4 text-teal-400" />
              <span>Citizen-Governed Closure</span>
            </span>
          </div>

          <div className="text-slate-500 text-[11px]">
            © 2026 CivicPulse Municipal Digital Services
          </div>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <CivicProvider>
      <CivicPulseContent />
    </CivicProvider>
  );
}
