export type ComplaintCategory =
  | 'Roads'
  | 'Street Lights'
  | 'Water Supply'
  | 'Garbage'
  | 'Drainage'
  | 'Public Safety'
  | 'Other';

export type ComplaintStatus =
  | 'REPORTED'
  | 'TRIAGED'
  | 'ASSIGNED'
  | 'IN PROGRESS'
  | 'RESOLUTION SUBMITTED'
  | 'AWAITING VERIFICATION'
  | 'VERIFIED'
  | 'CLOSED'
  | 'VERIFIED / CLOSED'
  | 'REOPENED';

export type PriorityLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type UserRole = 'citizen' | 'field_worker' | 'supervisor' | 'system';

export type MunicipalDepartment =
  | 'Road Maintenance'
  | 'Street Lighting'
  | 'Water Supply'
  | 'Sanitation'
  | 'Drainage'
  | 'Public Safety'
  | 'General Services';

export interface FieldWorker {
  id: string;
  name: string;
  department: MunicipalDepartment;
  active: boolean;
  currentWorkload: number;
  phone?: string;
  specialty?: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  status: ComplaintStatus;
  actor: string;
  actorRole: UserRole | string;
  comment?: string;
}

export interface WorkNote {
  id: string;
  timestamp: string;
  workerName: string;
  note: string;
}

export interface ResolutionEvidence {
  submittedAt: string;
  submittedBy: string;
  workerNotes: string;
  photoUrl?: string; // Primary after photo
  beforePhotoUrl?: string; // Before work photo
  afterPhotoUrl?: string; // After work photo
  partsReplaced?: string;
  resolutionDescription?: string;
}

export interface AiTriageSuggestion {
  suggestedCategory: ComplaintCategory;
  suggestedPriority: PriorityLevel;
  suggestedDepartment: MunicipalDepartment;
  recommendedSlaHours: number;
  confidence: number; // 0 to 1
  reasoning: string;
  keyFactors: string[];
  model: string;
  acceptedBySupervisor?: boolean;
  supervisorOverridden?: boolean;
  analyzedAt: string;
}

export interface DuplicateMatchResult {
  isDuplicate: boolean;
  matchedComplaintId?: string;
  matchedTitle?: string;
  similarity: number; // percentage 0-100
  reason?: string;
}

export interface Complaint {
  id: string;
  title: string;
  description: string;
  category: ComplaintCategory;
  location: string;
  ward?: string;
  zone?: string;
  coordinates?: {
    lat: number;
    lng: number;
    capturedAt?: string;
    accuracy?: number;
  };
  gpsCaptured?: boolean;
  gpsCapturedAt?: string;
  photoUrl?: string; // Citizen initial issue evidence
  status: ComplaintStatus;
  priority: PriorityLevel;
  createdAt: string;
  updatedAt: string;
  deadline?: string;
  citizenName: string;
  citizenPhone?: string;
  isContactMasked?: boolean;
  department?: MunicipalDepartment | string;
  assignedDepartment?: MunicipalDepartment | string;
  assignedWorker?: string;
  assignedWorkerId?: string;
  triageNotes?: string;
  workNotes?: WorkNote[];
  resolutionDescription?: string;
  evidence?: ResolutionEvidence;
  timeline: AuditLogEntry[];
  // Accountability Loop (Phase 4)
  verifiedAt?: string;
  closedAt?: string;
  verifiedBy?: string;
  citizenVerificationNote?: string;
  reopenedAt?: string;
  reopenedBy?: string;
  reopenReason?: string;
  reopenEvidenceUrl?: string;
  // Presentation Requirements: AI Triage, Escalation & Duplicate Detection
  aiTriage?: AiTriageSuggestion;
  duplicateOfId?: string;
  potentialDuplicate?: DuplicateMatchResult;
  isEscalated?: boolean;
  escalatedAt?: string;
  escalatedReason?: string;
}
