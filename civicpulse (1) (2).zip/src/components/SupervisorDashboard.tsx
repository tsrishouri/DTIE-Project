import React, { useState, useMemo } from 'react';
import { useCivic } from '../context/CivicContext';
import { Complaint, ComplaintCategory, ComplaintStatus, PriorityLevel, MunicipalDepartment } from '../types';
import { StatusBadge, PriorityBadge, SlaBadge } from './StatusBadge';
import { TriageModal } from './TriageModal';
import { AssignWorkerModal } from './AssignWorkerModal';
import { MUNICIPAL_DEPARTMENTS } from '../data/mockData';
import {
  calculateHotspots,
  extractWardName,
  extractZoneName,
  maskSensitiveContact,
} from '../utils/coordinates';
import {
  Building2,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  AlertTriangle,
  HardHat,
  ChevronRight,
  ClipboardCheck,
  UserCheck,
  Calendar,
  Layers,
  ArrowRight,
  MapPin,
  Activity,
  RotateCcw,
  Flame,
  ShieldAlert,
  Sparkles,
  Copy,
  Compass,
  Zap,
  X,
} from 'lucide-react';

interface SupervisorDashboardProps {
  onSelectComplaint: (complaint: Complaint) => void;
}

export const SupervisorDashboard: React.FC<SupervisorDashboardProps> = ({ onSelectComplaint }) => {
  const { complaints, setActiveView, escalateComplaint } = useCivic();

  // Search & Filters state
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [filterCategory, setFilterCategory] = useState<string>('ALL');
  const [filterPriority, setFilterPriority] = useState<string>('ALL');
  const [filterDepartment, setFilterDepartment] = useState<string>('ALL');
  const [filterWard, setFilterWard] = useState<string>('ALL');
  const [filterZone, setFilterZone] = useState<string>('ALL');
  const [filterEscalatedOnly, setFilterEscalatedOnly] = useState<boolean>(false);

  // Modal states for direct triage and assignment from dashboard table
  const [triageTarget, setTriageTarget] = useState<Complaint | null>(null);
  const [assignTarget, setAssignTarget] = useState<Complaint | null>(null);
  const [escalateTarget, setEscalateTarget] = useState<Complaint | null>(null);
  const [escalationReason, setEscalationReason] = useState<string>('');

  // 1. Hotspot Analysis Clusters (Derived from actual complaint coordinates and wards)
  const hotspots = useMemo(() => calculateHotspots(complaints), [complaints]);

  // Unique Wards and Zones for Filter Dropdowns
  const availableWards = useMemo(() => {
    const set = new Set<string>();
    complaints.forEach((c) => set.add(c.ward || extractWardName(c.location)));
    return Array.from(set).sort();
  }, [complaints]);

  const availableZones = useMemo(() => {
    const set = new Set<string>();
    complaints.forEach((c) => set.add(c.zone || extractZoneName(c.location)));
    return Array.from(set).sort();
  }, [complaints]);

  // Summary statistics calculated dynamically from shared complaint data
  const stats = useMemo(() => {
    const total = complaints.length;
    const newReports = complaints.filter((c) => c.status === 'REPORTED').length;
    const inProgress = complaints.filter((c) => c.status === 'IN PROGRESS').length;
    const awaitingVerification = complaints.filter(
      (c) => c.status === 'AWAITING VERIFICATION' || c.status === 'RESOLUTION SUBMITTED'
    ).length;
    const resolved = complaints.filter(
      (c) =>
        c.status === 'CLOSED' ||
        c.status === 'VERIFIED / CLOSED' ||
        c.status === 'VERIFIED'
    ).length;
    const criticalOrHigh = complaints.filter(
      (c) => c.priority === 'CRITICAL' || c.priority === 'HIGH'
    ).length;
    const reopened = complaints.filter((c) => c.status === 'REOPENED').length;
    const escalated = complaints.filter((c) => c.isEscalated).length;

    return {
      total,
      newReports,
      inProgress,
      awaitingVerification,
      resolved,
      criticalOrHigh,
      reopened,
      escalated,
    };
  }, [complaints]);

  // Recent Supervisor Activity extracted dynamically from actual complaint history
  const recentActivities = useMemo(() => {
    const activities: {
      id: string;
      complaintId: string;
      text: string;
      timestamp: string;
      status: ComplaintStatus;
    }[] = [];

    complaints.forEach((c) => {
      c.timeline.forEach((log) => {
        if (
          log.actorRole === 'supervisor' ||
          log.actor === 'Municipal Supervisor' ||
          log.status === 'TRIAGED' ||
          log.status === 'ASSIGNED' ||
          log.status === 'REPORTED' ||
          log.status === 'REOPENED' ||
          log.status === 'CLOSED' ||
          log.comment?.includes('ESCALATION')
        ) {
          let text = '';
          if (log.comment?.includes('ESCALATION')) {
            text = `${c.id} SLA escalated to emergency priority.`;
          } else if (log.status === 'TRIAGED') {
            text = `${c.id} was triaged (${c.assignedDepartment || c.category}).`;
          } else if (log.status === 'ASSIGNED') {
            text = `${c.id} assigned to ${c.assignedWorker || 'Field Specialist'}.`;
          } else if (log.status === 'REPORTED') {
            text = `${c.id} reported by citizen ${c.citizenName}.`;
          } else if (log.status === 'REOPENED') {
            text = `${c.id} reopened by citizen (Resolution rejected).`;
          } else if (log.status === 'CLOSED') {
            text = `${c.id} verified & closed by citizen.`;
          } else {
            text = `${c.id} status updated to ${log.status}.`;
          }

          activities.push({
            id: log.id,
            complaintId: c.id,
            text,
            timestamp: log.timestamp,
            status: log.status,
          });
        }
      });
    });

    return activities
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, 6);
  }, [complaints]);

  // Combined dynamic filtering
  const filteredComplaints = useMemo(() => {
    return complaints.filter((c) => {
      // Search by ID, Issue Title, Location
      const q = search.trim().toLowerCase();
      const matchesSearch =
        q === '' ||
        c.id.toLowerCase().includes(q) ||
        c.title.toLowerCase().includes(q) ||
        c.location.toLowerCase().includes(q) ||
        (c.ward && c.ward.toLowerCase().includes(q));

      // Status filter
      const matchesStatus = filterStatus === 'ALL' || c.status === filterStatus;

      // Category filter
      const matchesCategory = filterCategory === 'ALL' || c.category === filterCategory;

      // Priority filter
      const matchesPriority = filterPriority === 'ALL' || c.priority === filterPriority;

      // Department filter
      const matchesDept =
        filterDepartment === 'ALL' ||
        c.department === filterDepartment ||
        c.assignedDepartment === filterDepartment;

      // Ward filter
      const compWard = c.ward || extractWardName(c.location);
      const matchesWard = filterWard === 'ALL' || compWard === filterWard;

      // Zone filter
      const compZone = c.zone || extractZoneName(c.location, compWard);
      const matchesZone = filterZone === 'ALL' || compZone === filterZone;

      // Escalated filter
      const matchesEscalated = !filterEscalatedOnly || c.isEscalated === true;

      return (
        matchesSearch &&
        matchesStatus &&
        matchesCategory &&
        matchesPriority &&
        matchesDept &&
        matchesWard &&
        matchesZone &&
        matchesEscalated
      );
    });
  }, [
    complaints,
    search,
    filterStatus,
    filterCategory,
    filterPriority,
    filterDepartment,
    filterWard,
    filterZone,
    filterEscalatedOnly,
  ]);

  const clearAllFilters = () => {
    setSearch('');
    setFilterStatus('ALL');
    setFilterCategory('ALL');
    setFilterPriority('ALL');
    setFilterDepartment('ALL');
    setFilterWard('ALL');
    setFilterZone('ALL');
    setFilterEscalatedOnly(false);
  };

  const hasActiveFilters =
    search !== '' ||
    filterStatus !== 'ALL' ||
    filterCategory !== 'ALL' ||
    filterPriority !== 'ALL' ||
    filterDepartment !== 'ALL' ||
    filterWard !== 'ALL' ||
    filterZone !== 'ALL' ||
    filterEscalatedOnly;

  const handleConfirmEscalate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!escalateTarget) return;
    const reason = escalationReason.trim() || 'Urgent public hazard mitigation requested by supervisor';
    escalateComplaint(escalateTarget.id, reason);
    setEscalateTarget(null);
    setEscalationReason('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* 1. Header */}
      <div className="bg-[#0F1E36] text-white rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border border-slate-800 shadow-md">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-semibold mb-2 border border-blue-500/30">
            <Building2 className="w-3.5 h-3.5" />
            <span>CivicPulse Operations Center</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            CivicPulse Operations Center
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Monitor, triage, escalate and dispatch civic complaints across Municipal Wards & Zones.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="bg-slate-800/90 border border-slate-700/80 rounded-xl px-4 py-2.5 flex items-center gap-3 shadow-inner">
            <div className="w-9 h-9 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-sm">
              {stats.newReports}
            </div>
            <div>
              <div className="text-[11px] uppercase font-bold text-slate-400">Needs Triage</div>
              <div className="text-xs font-semibold text-white">Pending Review</div>
            </div>
          </div>

          <button
            onClick={() => setActiveView('analytics')}
            className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-all flex items-center gap-2 hover:scale-[1.02]"
          >
            <Activity className="w-4 h-4" />
            <span>Launch Command Center →</span>
          </button>
        </div>
      </div>

      {/* Summary Statistics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3.5">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-slate-300 transition-all">
          <div className="text-slate-500 text-xs font-medium">Total Complaints</div>
          <div className="text-2xl font-extrabold text-slate-900 mt-1">{stats.total}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Municipal registry</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-blue-300 transition-all">
          <div className="text-blue-700 text-xs font-semibold">New Reports</div>
          <div className="text-2xl font-extrabold text-blue-900 mt-1">{stats.newReports}</div>
          <div className="text-[11px] text-blue-600 mt-0.5 font-medium">Status: REPORTED</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-amber-300 transition-all">
          <div className="text-amber-700 text-xs font-semibold">In Progress</div>
          <div className="text-2xl font-extrabold text-amber-900 mt-1">{stats.inProgress}</div>
          <div className="text-[11px] text-amber-600 mt-0.5">Active field repairs</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-orange-300 transition-all">
          <div className="text-orange-700 text-xs font-semibold">Awaiting Verification</div>
          <div className="text-2xl font-extrabold text-orange-900 mt-1">{stats.awaitingVerification}</div>
          <div className="text-[11px] text-orange-600 mt-0.5">Proof submitted</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-emerald-300 transition-all">
          <div className="text-emerald-700 text-xs font-semibold">Resolved</div>
          <div className="text-2xl font-extrabold text-emerald-900 mt-1">{stats.resolved}</div>
          <div className="text-[11px] text-emerald-600 mt-0.5">Citizen verified</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-rose-300 transition-all">
          <div className="text-rose-700 text-xs font-semibold">Critical / High</div>
          <div className="text-2xl font-extrabold text-rose-900 mt-1">{stats.criticalOrHigh}</div>
          <div className="text-[11px] text-rose-600 mt-0.5 font-medium">Urgent intervention</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-purple-300 transition-all">
          <div className="text-purple-700 text-xs font-semibold flex items-center gap-1">
            <Zap className="w-3.5 h-3.5 text-purple-600" />
            <span>Escalated SLA</span>
          </div>
          <div className="text-2xl font-extrabold text-purple-900 mt-1">{stats.escalated}</div>
          <div className="text-[11px] text-purple-600 mt-0.5 font-medium">Emergency expedited</div>
        </div>
      </div>

      {/* 7. HOTSPOT ANALYSIS ALERT BANNER */}
      {hotspots.length > 0 && (
        <div className="bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-300 rounded-2xl p-4 sm:p-5 shadow-sm text-amber-950 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 animate-in fade-in">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-600 text-white flex items-center justify-center shrink-0 shadow-md">
              <Flame className="w-5 h-5" />
            </div>
            <div>
              <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-amber-200 text-amber-900 text-[10px] font-bold uppercase tracking-wider mb-1">
                Spatial Hotspot Analysis
              </div>
              <h3 className="text-base font-bold text-amber-950">
                {hotspots.length} Active Hotspot Cluster{hotspots.length > 1 ? 's' : ''} Detected
              </h3>
              <p className="text-xs text-amber-800 mt-0.5 max-w-2xl">
                Concentrated civic issues found in: {hotspots.map((h) => `${h.wardName} (${h.count} active ${h.dominantCategory.toLowerCase()} issues)`).join('; ')}.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {hotspots.slice(0, 3).map((h) => (
              <button
                key={h.wardName}
                onClick={() => setFilterWard(h.wardName)}
                className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-sm transition-all flex items-center gap-1"
              >
                <Flame className="w-3.5 h-3.5" />
                <span>Filter {h.wardName} ({h.count})</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Citizen Reopened Complaints Alert Banner */}
      {stats.reopened > 0 && (
        <div className="bg-rose-50 border-2 border-rose-300 rounded-2xl p-4 sm:p-5 shadow-sm text-rose-950 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 animate-in fade-in">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0 shadow-md">
              <RotateCcw className="w-5 h-5" />
            </div>
            <div>
              <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-rose-200 text-rose-900 text-[11px] font-bold uppercase tracking-wider mb-1">
                Citizen Accountability Feedback
              </div>
              <h3 className="text-base font-bold text-rose-950">
                {stats.reopened} Complaint{stats.reopened > 1 ? 's' : ''} Reopened — Resolution Rejected
              </h3>
              <p className="text-xs text-rose-800 mt-0.5 max-w-2xl">
                Citizens have verified that reported issues remain unresolved on-site. Immediate supervisor re-triage or worker re-dispatch is required.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setFilterStatus('REOPENED')}
              className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-md transition-all flex items-center gap-1.5"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Filter Reopened ({stats.reopened})</span>
            </button>
          </div>
        </div>
      )}

      {/* Main Grid: Management Table + Activity Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
        {/* Table Column (3 cols on large) */}
        <div className="lg:col-span-3 space-y-4">
          {/* Search and Filters Header */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 space-y-3.5">
            {/* Search Input */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="relative w-full">
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search by Complaint ID (e.g. CP-2026-9944), title, ward, or location..."
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-inner"
                />
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              </div>

              {hasActiveFilters && (
                <button
                  onClick={clearAllFilters}
                  className="px-3 py-2 text-xs font-semibold text-rose-700 hover:text-rose-800 hover:bg-rose-50 rounded-lg flex items-center gap-1 shrink-0 transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset Filters</span>
                </button>
              )}
            </div>

            {/* Combined Filters (Row 1) */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 border-t border-slate-100">
              {/* Status Filter */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">
                  Status
                </label>
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs bg-white text-slate-900 font-medium"
                >
                  <option value="ALL">All Statuses</option>
                  <option value="REPORTED">REPORTED</option>
                  <option value="TRIAGED">TRIAGED</option>
                  <option value="ASSIGNED">ASSIGNED</option>
                  <option value="IN PROGRESS">IN PROGRESS</option>
                  <option value="RESOLUTION SUBMITTED">RESOLUTION SUBMITTED</option>
                  <option value="AWAITING VERIFICATION">AWAITING VERIFICATION</option>
                  <option value="VERIFIED / CLOSED">VERIFIED / CLOSED</option>
                  <option value="REOPENED">REOPENED</option>
                </select>
              </div>

              {/* Category Filter */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">
                  Category
                </label>
                <select
                  value={filterCategory}
                  onChange={(e) => setFilterCategory(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs bg-white text-slate-900 font-medium"
                >
                  <option value="ALL">All Categories</option>
                  <option value="Roads">Roads</option>
                  <option value="Street Lights">Street Lights</option>
                  <option value="Water Supply">Water Supply</option>
                  <option value="Garbage">Garbage</option>
                  <option value="Drainage">Drainage</option>
                  <option value="Public Safety">Public Safety</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              {/* Priority Filter */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">
                  Priority
                </label>
                <select
                  value={filterPriority}
                  onChange={(e) => setFilterPriority(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs bg-white text-slate-900 font-medium"
                >
                  <option value="ALL">All Priorities</option>
                  <option value="LOW">LOW</option>
                  <option value="MEDIUM">MEDIUM</option>
                  <option value="HIGH">HIGH</option>
                  <option value="CRITICAL">CRITICAL</option>
                </select>
              </div>

              {/* Department Filter */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">
                  Department
                </label>
                <select
                  value={filterDepartment}
                  onChange={(e) => setFilterDepartment(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs bg-white text-slate-900 font-medium"
                >
                  <option value="ALL">All Departments</option>
                  {MUNICIPAL_DEPARTMENTS.map((dept) => (
                    <option key={dept} value={dept}>
                      {dept}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Combined Filters (Row 2: Ward, Zone & Escalation) */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-100 items-end">
              {/* Ward Filter */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">
                  Municipal Ward
                </label>
                <select
                  value={filterWard}
                  onChange={(e) => setFilterWard(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs bg-white text-slate-900 font-medium"
                >
                  <option value="ALL">All Wards</option>
                  {availableWards.map((w) => (
                    <option key={w} value={w}>
                      {w}
                    </option>
                  ))}
                </select>
              </div>

              {/* Zone Filter */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">
                  Administrative Zone
                </label>
                <select
                  value={filterZone}
                  onChange={(e) => setFilterZone(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs bg-white text-slate-900 font-medium"
                >
                  <option value="ALL">All Zones</option>
                  {availableZones.map((z) => (
                    <option key={z} value={z}>
                      {z}
                    </option>
                  ))}
                </select>
              </div>

              {/* Escalated SLA Toggle */}
              <div className="sm:col-span-2 flex items-center justify-end pb-1">
                <button
                  type="button"
                  onClick={() => setFilterEscalatedOnly(!filterEscalatedOnly)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all flex items-center gap-1.5 ${
                    filterEscalatedOnly
                      ? 'bg-purple-100 border-purple-400 text-purple-900 ring-2 ring-purple-300'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <Zap className={`w-3.5 h-3.5 ${filterEscalatedOnly ? 'text-purple-700' : 'text-slate-500'}`} />
                  <span>Filter: SLA Escalated ({stats.escalated})</span>
                </button>
              </div>
            </div>
          </div>

          {/* Complaints Table Container */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <div className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                Municipal Complaint Ledger ({filteredComplaints.length} matched)
              </div>
              <span className="text-[11px] text-slate-500">
                Sorted by latest updates
              </span>
            </div>

            {filteredComplaints.length === 0 ? (
              <div className="p-12 text-center text-slate-500 space-y-2">
                <Clock className="w-10 h-10 text-slate-400 mx-auto mb-2" />
                <h3 className="text-sm font-bold text-slate-800">No complaints match your filters</h3>
                <p className="text-xs text-slate-500">
                  Try clearing search terms or setting filters back to "All".
                </p>
                <button
                  onClick={clearAllFilters}
                  className="mt-2 px-3.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold"
                >
                  Clear Filters
                </button>
              </div>
            ) : (
              <>
                {/* Desktop Table View */}
                <div className="hidden md:block overflow-x-auto">
                  <table className="w-full text-left text-xs text-slate-600">
                    <thead className="bg-slate-100/70 border-b border-slate-200 text-slate-700 uppercase font-bold text-[11px]">
                      <tr>
                        <th className="px-4 py-3">Complaint ID</th>
                        <th className="px-4 py-3">Issue Title & Context</th>
                        <th className="px-4 py-3">Category</th>
                        <th className="px-4 py-3">Ward / Zone</th>
                        <th className="px-4 py-3">Priority</th>
                        <th className="px-4 py-3">Status</th>
                        <th className="px-4 py-3">Department</th>
                        <th className="px-4 py-3">Assigned Worker</th>
                        <th className="px-4 py-3">SLA Status</th>
                        <th className="px-4 py-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredComplaints.map((c) => (
                        <tr
                          key={c.id}
                          onClick={() => onSelectComplaint(c)}
                          className="hover:bg-blue-50/50 cursor-pointer transition-colors"
                        >
                          <td className="px-4 py-3.5 font-mono font-bold text-slate-900 whitespace-nowrap">
                            <div className="flex items-center gap-1.5">
                              <span>{c.id}</span>
                              {c.isEscalated && (
                                <span className="bg-purple-600 text-white text-[9px] px-1 py-0.2 rounded font-bold uppercase tracking-wider">
                                  ESC
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="px-4 py-3.5 font-medium text-slate-900 max-w-xs">
                            <div className="truncate font-semibold" title={c.title}>
                              {c.title}
                            </div>
                            <div className="flex items-center gap-1.5 mt-0.5 text-[10px] text-slate-500">
                              {c.gpsCaptured && (
                                <span className="text-emerald-700 font-semibold flex items-center gap-0.5">
                                  <MapPin className="w-2.5 h-2.5" /> GPS Verified
                                </span>
                              )}
                              {c.potentialDuplicate?.isDuplicate && (
                                <span className="text-amber-800 bg-amber-100 px-1 py-0.2 rounded font-bold flex items-center gap-0.5">
                                  <Copy className="w-2.5 h-2.5" /> Dup {c.potentialDuplicate.similarity}%
                                </span>
                              )}
                              {c.aiTriage && (
                                <span className="text-blue-700 bg-blue-50 px-1 py-0.2 rounded font-medium flex items-center gap-0.5">
                                  <Sparkles className="w-2.5 h-2.5" /> AI: {c.aiTriage.suggestedPriority}
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="px-4 py-3.5 whitespace-nowrap">
                            <span className="font-semibold text-slate-700">{c.category}</span>
                          </td>
                          <td className="px-4 py-3.5 text-slate-600 whitespace-nowrap">
                            <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-medium text-[11px]">
                              {c.ward || extractWardName(c.location)}
                            </span>
                          </td>
                          <td className="px-4 py-3.5 whitespace-nowrap">
                            <PriorityBadge priority={c.priority} />
                          </td>
                          <td className="px-4 py-3.5 whitespace-nowrap">
                            <StatusBadge status={c.status} size="sm" />
                          </td>
                          <td className="px-4 py-3.5 text-slate-800 whitespace-nowrap">
                            {c.department || c.assignedDepartment || (
                              <span className="text-slate-400 italic">Unassigned</span>
                            )}
                          </td>
                          <td className="px-4 py-3.5 text-slate-800 whitespace-nowrap">
                            {c.assignedWorker ? (
                              <span className="font-semibold text-slate-900">{c.assignedWorker}</span>
                            ) : (
                              <span className="text-amber-700 font-semibold bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                                None
                              </span>
                            )}
                          </td>
                          <td className="px-4 py-3.5 whitespace-nowrap">
                            <SlaBadge deadline={c.deadline} />
                          </td>
                          <td className="px-4 py-3.5 text-right whitespace-nowrap">
                            <div className="flex items-center justify-end gap-1.5" onClick={(e) => e.stopPropagation()}>
                              {c.status === 'REPORTED' && (
                                <button
                                  onClick={() => setTriageTarget(c)}
                                  className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-[11px] shadow-sm flex items-center gap-1 transition-all"
                                >
                                  <ClipboardCheck className="w-3 h-3" />
                                  <span>Triage</span>
                                </button>
                              )}

                              {c.status === 'TRIAGED' && (
                                <button
                                  onClick={() => setAssignTarget(c)}
                                  className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg text-[11px] shadow-sm flex items-center gap-1 transition-all"
                                >
                                  <HardHat className="w-3 h-3" />
                                  <span>Assign</span>
                                </button>
                              )}

                              {c.status === 'REOPENED' && (
                                <>
                                  <button
                                    onClick={() => setTriageTarget(c)}
                                    className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-[11px] shadow-sm flex items-center gap-1 transition-all"
                                    title="Re-triage reopened complaint"
                                  >
                                    <ClipboardCheck className="w-3 h-3" />
                                    <span>Re-triage</span>
                                  </button>
                                  <button
                                    onClick={() => setAssignTarget(c)}
                                    className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg text-[11px] shadow-sm flex items-center gap-1 transition-all"
                                    title="Reassign field specialist"
                                  >
                                    <HardHat className="w-3 h-3" />
                                    <span>Reassign</span>
                                  </button>
                                </>
                              )}

                              {/* SLA Escalation Button (Available for non-closed complaints) */}
                              {c.status !== 'CLOSED' && c.status !== 'VERIFIED / CLOSED' && (
                                <button
                                  onClick={() => setEscalateTarget(c)}
                                  className={`p-1.5 rounded-lg text-[11px] font-bold transition-all ${
                                    c.isEscalated
                                      ? 'bg-purple-100 text-purple-700 hover:bg-purple-200'
                                      : 'bg-slate-100 text-slate-600 hover:bg-rose-50 hover:text-rose-700'
                                  }`}
                                  title={c.isEscalated ? 'SLA already escalated' : 'Escalate SLA deadline to Emergency'}
                                >
                                  <Zap className="w-3.5 h-3.5" />
                                </button>
                              )}

                              <button
                                onClick={() => onSelectComplaint(c)}
                                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
                                title="View details"
                              >
                                <ChevronRight className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Mobile Card View */}
                <div className="md:hidden divide-y divide-slate-100">
                  {filteredComplaints.map((c) => (
                    <div
                      key={c.id}
                      onClick={() => onSelectComplaint(c)}
                      className="p-4 space-y-2.5 hover:bg-blue-50/40 cursor-pointer text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono font-bold text-slate-900 text-sm">
                          {c.id}
                        </span>
                        <div className="flex items-center gap-1.5">
                          {c.isEscalated && (
                            <span className="bg-purple-600 text-white text-[9px] px-1.5 py-0.5 rounded font-bold">
                              ESCALATED
                            </span>
                          )}
                          <StatusBadge status={c.status} size="sm" />
                        </div>
                      </div>

                      <h4 className="font-semibold text-slate-900 line-clamp-1">{c.title}</h4>

                      <div className="flex flex-wrap items-center gap-2 text-slate-500">
                        <span className="px-2 py-0.5 bg-slate-100 rounded text-slate-700 font-medium">
                          {c.category}
                        </span>
                        <span className="px-2 py-0.5 bg-slate-100 rounded text-slate-700 font-medium">
                          {c.ward || extractWardName(c.location)}
                        </span>
                        <PriorityBadge priority={c.priority} />
                      </div>

                      <div className="flex items-center justify-between pt-1 border-t border-slate-100">
                        <SlaBadge deadline={c.deadline} />
                        <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                          {c.status === 'REPORTED' && (
                            <button
                              onClick={() => setTriageTarget(c)}
                              className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-[11px]"
                            >
                              Triage
                            </button>
                          )}
                          {c.status === 'TRIAGED' && (
                            <button
                              onClick={() => setAssignTarget(c)}
                              className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg text-[11px]"
                            >
                              Assign
                            </button>
                          )}
                          {c.status === 'REOPENED' && (
                            <>
                              <button
                                onClick={() => setTriageTarget(c)}
                                className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-[11px]"
                              >
                                Re-triage
                              </button>
                              <button
                                onClick={() => setAssignTarget(c)}
                                className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg text-[11px]"
                              >
                                Reassign
                              </button>
                            </>
                          )}
                          <button
                            onClick={() => onSelectComplaint(c)}
                            className="p-1 text-slate-400 hover:text-slate-600"
                          >
                            <ChevronRight className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>

        {/* Activity & Quick Stats Sidebar */}
        <div className="space-y-4">
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
            <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-100">
              <Activity className="w-4 h-4 text-blue-600" />
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Recent Supervisor Activity
              </h3>
            </div>

            {recentActivities.length === 0 ? (
              <p className="text-xs text-slate-400 py-3 text-center">No recent activity recorded.</p>
            ) : (
              <div className="space-y-3">
                {recentActivities.map((act) => (
                  <div
                    key={act.id}
                    onClick={() => {
                      const matched = complaints.find((c) => c.id === act.complaintId);
                      if (matched) onSelectComplaint(matched);
                    }}
                    className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 hover:border-blue-200 hover:bg-blue-50/40 cursor-pointer transition-all text-xs"
                  >
                    <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
                      <span className="font-mono font-bold text-slate-700">{act.complaintId}</span>
                      <span>
                        {new Date(act.timestamp).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                    <p className="font-medium text-slate-800 leading-snug">{act.text}</p>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Quick Help Card */}
          <div className="bg-blue-50/60 border border-blue-200 rounded-2xl p-4 text-xs text-blue-900 space-y-2">
            <h4 className="font-bold flex items-center gap-1.5 text-blue-950">
              <ClipboardCheck className="w-4 h-4 text-blue-700" />
              <span>Supervisor Triage Protocol</span>
            </h4>
            <p className="text-[11px] text-blue-800 leading-relaxed">
              1. <strong>Triage</strong> incoming issues: Review AI category recommendations and confirm severity.<br />
              2. <strong>Assign</strong> field technicians with target SLA window.<br />
              3. <strong>Escalate</strong> SLA for urgent safety hazards or imminent breaches.
            </p>
          </div>
        </div>
      </div>

      {/* 8. SLA ESCALATION CONFIRMATION MODAL */}
      {escalateTarget && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden animate-in zoom-in-95">
            <div className="bg-purple-900 text-white px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Zap className="w-5 h-5 text-amber-300" />
                <h3 className="font-bold text-sm">Escalate SLA: {escalateTarget.id}</h3>
              </div>
              <button onClick={() => setEscalateTarget(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleConfirmEscalate} className="p-6 space-y-4 text-xs">
              <p className="text-slate-700">
                Triggering an <strong>Emergency SLA Escalation</strong> will elevate this issue to <strong>CRITICAL</strong> priority and shorten the target SLA resolution window to <strong>6 hours</strong>.
              </p>
              <div>
                <label className="block text-slate-800 font-bold mb-1">
                  Escalation Justification / Public Hazard Details
                </label>
                <textarea
                  rows={3}
                  value={escalationReason}
                  onChange={(e) => setEscalationReason(e.target.value)}
                  placeholder="e.g. Critical safety hazard near school crossing; high pedestrian traffic requires emergency deployment."
                  className="w-full p-2.5 rounded-lg border border-slate-300 text-slate-900 text-xs focus:ring-2 focus:ring-purple-500 focus:outline-none"
                />
              </div>
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEscalateTarget(null)}
                  className="px-3.5 py-2 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-purple-700 hover:bg-purple-800 text-white font-bold shadow-md transition-all flex items-center gap-1.5"
                >
                  <Zap className="w-3.5 h-3.5" />
                  <span>Confirm Emergency Escalation</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Triage Modal for fast triage directly from supervisor table */}
      {triageTarget && (
        <TriageModal
          complaint={triageTarget}
          onClose={() => setTriageTarget(null)}
          onTriageComplete={() => {
            const updated = complaints.find((c) => c.id === triageTarget.id);
            if (updated) setAssignTarget(updated);
          }}
        />
      )}

      {/* Assignment Modal for fast dispatch directly from supervisor table */}
      {assignTarget && (
        <AssignWorkerModal
          complaint={assignTarget}
          onClose={() => setAssignTarget(null)}
        />
      )}
    </div>
  );
};
