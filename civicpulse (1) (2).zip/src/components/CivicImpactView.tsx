import React from 'react';
import { Complaint } from '../types';
import { calculateCivicImpact, calculateKpis } from '../utils/analytics';
import {
  ShieldCheck,
  Users,
  CheckCircle2,
  Droplets,
  Zap,
  Trash2,
  Waves,
  HeartHandshake,
  Activity,
  ArrowUpRight,
  Award,
} from 'lucide-react';

interface CivicImpactViewProps {
  complaints: Complaint[];
}

export const CivicImpactView: React.FC<CivicImpactViewProps> = ({ complaints }) => {
  const impact = calculateCivicImpact(complaints);
  const kpis = calculateKpis(complaints);

  return (
    <div className="space-y-6">
      {/* Hero Impact Header Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-teal-900 to-slate-900 text-white rounded-2xl p-6 sm:p-8 border border-emerald-800/40 shadow-xl relative overflow-hidden">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-semibold mb-3 border border-emerald-500/30">
            <Award className="w-4 h-4 text-emerald-400" />
            <span>Measurable Municipal Accountability</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Civic Impact Dashboard
          </h2>
          <p className="mt-2 text-emerald-100 text-xs sm:text-sm leading-relaxed">
            Quantifying real-world community benefits from citizen-verified civic resolutions. Every verified closure delivers safer thoroughfares, illuminated neighborhoods, and clean drinking water infrastructure.
          </p>
        </div>

        <div className="mt-6 grid grid-cols-2 sm:grid-cols-3 gap-4 pt-4 border-t border-emerald-800/60">
          <div>
            <span className="text-[11px] text-emerald-300 font-bold uppercase tracking-wider block">
              Estimated Community Impact
            </span>
            <span className="text-2xl sm:text-3xl font-extrabold text-white mt-0.5 block">
              {impact.citizensServed.toLocaleString()}
            </span>
            <span className="text-[11px] text-emerald-200">Residents directly benefited</span>
          </div>

          <div>
            <span className="text-[11px] text-emerald-300 font-bold uppercase tracking-wider block">
              Civic Trust Score
            </span>
            <span className="text-2xl sm:text-3xl font-extrabold text-emerald-300 mt-0.5 block">
              {impact.civicTrustScore}%
            </span>
            <span className="text-[11px] text-emerald-200">Resolution satisfaction rate</span>
          </div>

          <div>
            <span className="text-[11px] text-emerald-300 font-bold uppercase tracking-wider block">
              Verified Closures
            </span>
            <span className="text-2xl sm:text-3xl font-extrabold text-white mt-0.5 block">
              {kpis.resolvedComplaints}
            </span>
            <span className="text-[11px] text-emerald-200">Inspected & accepted by citizens</span>
          </div>
        </div>
      </div>

      {/* Physical Infrastructure Restored Grid */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-base font-bold text-slate-900">Physical Infrastructure Restored</h3>
            <p className="text-xs text-slate-500">Tangible municipal assets returned to safe service</p>
          </div>
          <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
            Real-Time Asset Ledger
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5">
          {/* Roads */}
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm hover:border-amber-300 transition-all">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-amber-800 uppercase tracking-wider">Roads</span>
              <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
                🛣️
              </div>
            </div>
            <div className="text-2xl font-extrabold text-slate-900">{impact.potholesRepaired}</div>
            <p className="text-[11px] text-slate-500 mt-1">Hazardous potholes patched with hot-mix asphalt</p>
          </div>

          {/* Street Lights */}
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm hover:border-yellow-300 transition-all">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-yellow-800 uppercase tracking-wider">Lighting</span>
              <div className="w-8 h-8 rounded-lg bg-yellow-100 text-yellow-700 flex items-center justify-center font-bold">
                💡
              </div>
            </div>
            <div className="text-2xl font-extrabold text-slate-900">{impact.streetLightsIlluminated}</div>
            <p className="text-[11px] text-slate-500 mt-1">Luminaires replaced and pedestrian routes secured</p>
          </div>

          {/* Water Preserved */}
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm hover:border-blue-300 transition-all">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-blue-800 uppercase tracking-wider">Clean Water</span>
              <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
                💧
              </div>
            </div>
            <div className="text-2xl font-extrabold text-slate-900">
              {impact.waterPreservedGallons.toLocaleString()} gal
            </div>
            <p className="text-[11px] text-slate-500 mt-1">Drinking water saved from ruptured main collars</p>
          </div>

          {/* Waste Cleared */}
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm hover:border-emerald-300 transition-all">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider">Sanitation</span>
              <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                ♻️
              </div>
            </div>
            <div className="text-2xl font-extrabold text-slate-900">{impact.wasteTonsCleared} tons</div>
            <p className="text-[11px] text-slate-500 mt-1">Municipal waste compacted and sites sanitized</p>
          </div>

          {/* Drainage */}
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm hover:border-cyan-300 transition-all">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-cyan-800 uppercase tracking-wider">Drainage</span>
              <div className="w-8 h-8 rounded-lg bg-cyan-100 text-cyan-700 flex items-center justify-center font-bold">
                🌊
              </div>
            </div>
            <div className="text-2xl font-extrabold text-slate-900">{impact.drainsUnclogged}</div>
            <p className="text-[11px] text-slate-500 mt-1">Storm drains de-silted preventing stagnant overflow</p>
          </div>
        </div>
      </div>

      {/* Civic Trust & Accountability Loop Indicators */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-4">
          <div className="flex items-center gap-3 border-b border-slate-100 pb-3">
            <div className="w-10 h-10 rounded-xl bg-teal-100 text-teal-800 flex items-center justify-center">
              <HeartHandshake className="w-5 h-5 text-teal-700" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900">Citizen-Governed Verification Protocol</h4>
              <p className="text-xs text-slate-500">Eliminating "ghost resolutions" and fake ticket closures</p>
            </div>
          </div>

          <div className="space-y-3 text-xs text-slate-600">
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200">
              <span className="font-semibold text-slate-800">Verification Gate Status:</span>
              <span className="font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                100% Enforced
              </span>
            </div>

            <p className="leading-relaxed">
              In traditional civic systems, work orders are closed unilaterally by municipal staff without independent confirmation. CivicPulse ensures that no complaint can reach closed status until the reporting citizen inspects photographic proof and verifies on-site satisfaction.
            </p>

            <div className="flex items-center gap-2 pt-1 text-slate-700 font-medium">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Two-party cryptographic audit record with citizen name & timestamp.</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-4">
          <div className="flex items-center gap-3 border-b border-slate-100 pb-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center">
              <Activity className="w-5 h-5 text-blue-700" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900">SLA Turnaround Velocity</h4>
              <p className="text-xs text-slate-500">Citizen service level commitment compliance</p>
            </div>
          </div>

          <div className="space-y-3 text-xs text-slate-600">
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200">
              <span className="font-semibold text-slate-800">Mean Resolution Velocity:</span>
              <span className="font-mono font-bold text-slate-900 bg-white px-2 py-0.5 rounded border border-slate-200">
                {kpis.avgResolutionFormatted}
              </span>
            </div>

            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200">
              <span className="font-semibold text-slate-800">SLA Commitment Compliance:</span>
              <span className="font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                {kpis.slaComplianceRate !== null ? `${kpis.slaComplianceRate}% on-time` : '100% on-time'}
              </span>
            </div>

            <p className="leading-relaxed text-slate-500">
              Priority-based SLA dispatch guarantees 4-hour emergency response for critical hazards and 24–48 hours for standard municipal repairs.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
