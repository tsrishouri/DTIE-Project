import React from 'react';
import { ComplaintStatus, PriorityLevel } from '../types';
import { CheckCircle2, Clock, AlertCircle, Wrench, Send, ShieldAlert, ArrowUpRight } from 'lucide-react';

interface StatusBadgeProps {
  status: ComplaintStatus;
  size?: 'sm' | 'md' | 'lg';
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, size = 'md' }) => {
  const getBadgeConfig = () => {
    switch (status) {
      case 'REPORTED':
        return {
          label: 'Reported',
          bg: 'bg-slate-100 text-slate-800 border-slate-300',
          dot: 'bg-slate-500',
          icon: Clock,
        };
      case 'TRIAGED':
        return {
          label: 'Triaged',
          bg: 'bg-blue-50 text-blue-800 border-blue-200',
          dot: 'bg-blue-500',
          icon: Clock,
        };
      case 'ASSIGNED':
        return {
          label: 'Assigned',
          bg: 'bg-sky-50 text-sky-800 border-sky-200',
          dot: 'bg-sky-500',
          icon: ArrowUpRight,
        };
      case 'IN PROGRESS':
        return {
          label: 'In Progress',
          bg: 'bg-amber-50 text-amber-900 border-amber-300',
          dot: 'bg-amber-500 animate-pulse',
          icon: Wrench,
        };
      case 'RESOLUTION SUBMITTED':
        return {
          label: 'Resolution Submitted',
          bg: 'bg-indigo-50 text-indigo-900 border-indigo-200',
          dot: 'bg-indigo-500',
          icon: Send,
        };
      case 'AWAITING VERIFICATION':
        return {
          label: 'Awaiting Verification',
          bg: 'bg-orange-100 text-orange-900 border-orange-300 font-semibold',
          dot: 'bg-orange-500 animate-ping',
          icon: AlertCircle,
        };
      case 'VERIFIED':
        return {
          label: 'Citizen Verified',
          bg: 'bg-teal-50 text-teal-900 border-teal-300 font-semibold',
          dot: 'bg-teal-600',
          icon: CheckCircle2,
        };
      case 'CLOSED':
        return {
          label: 'Closed',
          bg: 'bg-emerald-100 text-emerald-900 border-emerald-300 font-semibold',
          dot: 'bg-emerald-600',
          icon: CheckCircle2,
        };
      case 'VERIFIED / CLOSED':
        return {
          label: 'Verified & Closed',
          bg: 'bg-emerald-50 text-emerald-800 border-emerald-300 font-semibold',
          dot: 'bg-emerald-500',
          icon: CheckCircle2,
        };
      case 'REOPENED':
        return {
          label: 'Reopened',
          bg: 'bg-rose-100 text-rose-900 border-rose-300 font-semibold',
          dot: 'bg-rose-600',
          icon: ShieldAlert,
        };
      default:
        return {
          label: status,
          bg: 'bg-slate-100 text-slate-700 border-slate-200',
          dot: 'bg-slate-400',
          icon: Clock,
        };
    }
  };

  const config = getBadgeConfig();
  const Icon = config.icon;

  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5 gap-1',
    md: 'text-xs px-2.5 py-1 gap-1.5',
    lg: 'text-sm px-3.5 py-1.5 gap-2',
  }[size];

  return (
    <span
      className={`inline-flex items-center rounded-full border ${config.bg} ${sizeClasses} transition-all`}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${config.dot}`} />
      <Icon className="w-3.5 h-3.5 shrink-0" />
      <span>{config.label}</span>
    </span>
  );
};

export const PriorityBadge: React.FC<{ priority: PriorityLevel }> = ({ priority }) => {
  const styles = {
    LOW: 'bg-slate-100 text-slate-700 border-slate-200',
    MEDIUM: 'bg-blue-50 text-blue-700 border-blue-200',
    HIGH: 'bg-amber-100 text-amber-800 border-amber-300',
    CRITICAL: 'bg-rose-100 text-rose-800 border-rose-300 font-semibold',
  }[priority];

  return (
    <span className={`inline-flex items-center text-xs px-2 py-0.5 rounded border uppercase tracking-wider font-medium ${styles}`}>
      {priority}
    </span>
  );
};

export const SlaBadge: React.FC<{ deadline?: string }> = ({ deadline }) => {
  if (!deadline) {
    return (
      <span className="inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded border bg-slate-100 text-slate-500 border-slate-200">
        <Clock className="w-3 h-3 text-slate-400" />
        <span>SLA: Pending</span>
      </span>
    );
  }

  const deadlineMs = new Date(deadline).getTime();
  const nowMs = Date.now();
  const diffHours = (deadlineMs - nowMs) / (1000 * 60 * 60);

  if (diffHours < 0) {
    const overdue = Math.abs(Math.round(diffHours));
    return (
      <span className="inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-full border bg-rose-100 text-rose-800 border-rose-300 font-bold animate-pulse">
        <span className="w-1.5 h-1.5 rounded-full bg-rose-600" />
        <span>SLA BREACHED ({overdue}h)</span>
      </span>
    );
  }

  if (diffHours <= 6) {
    const hours = Math.max(1, Math.round(diffHours));
    return (
      <span className="inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-full border bg-amber-100 text-amber-900 border-amber-300 font-semibold">
        <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping" />
        <span>Due Soon ({hours}h left)</span>
      </span>
    );
  }

  const hours = Math.round(diffHours);
  const label = hours >= 48 ? `${Math.round(hours / 24)}d left` : `${hours}h left`;
  return (
    <span className="inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-full border bg-emerald-50 text-emerald-800 border-emerald-300 font-medium">
      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
      <span>SLA: {label}</span>
    </span>
  );
};

