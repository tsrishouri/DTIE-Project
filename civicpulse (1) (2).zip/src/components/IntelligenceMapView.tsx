import React, { useState, useMemo } from 'react';
import { Complaint, ComplaintCategory, ComplaintStatus, PriorityLevel } from '../types';
import { getComplaintCoordinates, extractWardName, DISTRICT_CENTER } from '../utils/coordinates';
import { StatusBadge, PriorityBadge } from './StatusBadge';
import {
  MapPin,
  Layers,
  Filter,
  Flame,
  Search,
  Maximize2,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Eye,
  HardHat,
  Building2,
  X,
  Compass,
} from 'lucide-react';

interface IntelligenceMapViewProps {
  complaints: Complaint[];
  onSelectComplaint: (complaint: Complaint) => void;
}

export const IntelligenceMapView: React.FC<IntelligenceMapViewProps> = ({
  complaints,
  onSelectComplaint,
}) => {
  // Filter states
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [selectedPriority, setSelectedPriority] = useState<string>('ALL');
  const [showHeatmap, setShowHeatmap] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Map viewport states
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [selectedPinId, setSelectedPinId] = useState<string | null>(null);

  // Category Color Palette
  const categoryColors: Record<ComplaintCategory, { pinBg: string; text: string; hex: string }> = {
    'Roads': { pinBg: 'bg-amber-500', text: 'text-amber-700', hex: '#f59e0b' },
    'Street Lights': { pinBg: 'bg-yellow-500', text: 'text-yellow-700', hex: '#eab308' },
    'Water Supply': { pinBg: 'bg-blue-600', text: 'text-blue-700', hex: '#2563eb' },
    'Garbage': { pinBg: 'bg-emerald-600', text: 'text-emerald-700', hex: '#059669' },
    'Drainage': { pinBg: 'bg-cyan-600', text: 'text-cyan-700', hex: '#0891b2' },
    'Public Safety': { pinBg: 'bg-rose-600', text: 'text-rose-700', hex: '#e11d48' },
    'Other': { pinBg: 'bg-purple-600', text: 'text-purple-700', hex: '#9333ea' },
  };

  // Filter complaints
  const filteredComplaints = useMemo(() => {
    return complaints.filter((c) => {
      const matchesCat = selectedCategory === 'ALL' || c.category === selectedCategory;
      const matchesPriority = selectedPriority === 'ALL' || c.priority === selectedPriority;
      const matchesSearch =
        searchQuery === '' ||
        c.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.location.toLowerCase().includes(searchQuery.toLowerCase());

      let matchesStat = true;
      if (selectedStatus === 'ACTIVE') {
        matchesStat = c.status !== 'CLOSED' && c.status !== 'VERIFIED / CLOSED';
      } else if (selectedStatus === 'RESOLVED') {
        matchesStat =
          c.status === 'CLOSED' ||
          c.status === 'VERIFIED / CLOSED' ||
          c.status === 'VERIFIED';
      } else if (selectedStatus !== 'ALL') {
        matchesStat = c.status === selectedStatus;
      }

      return matchesCat && matchesPriority && matchesStat && matchesSearch;
    });
  }, [complaints, selectedCategory, selectedStatus, selectedPriority, searchQuery]);

  // Map geographic bounding box:
  // Center: lat: 37.7749, lng: -122.4194
  // Min lat: 37.745, Max lat: 37.805 (span ~0.060)
  // Min lng: -122.450, Max lng: -122.390 (span ~0.060)
  const mapBounds = {
    minLat: 37.745,
    maxLat: 37.805,
    minLng: -122.450,
    maxLng: -122.390,
  };

  // Convert GPS coordinates to percentage x, y on 1000x650 SVG canvas
  const getCoordinatesPct = (coords: { lat: number; lng: number }) => {
    const latSpan = mapBounds.maxLat - mapBounds.minLat;
    const lngSpan = mapBounds.maxLng - mapBounds.minLng;

    // Invert lat for SVG Y (higher lat = lower Y)
    const yPct = ((mapBounds.maxLat - coords.lat) / latSpan) * 100;
    const xPct = ((coords.lng - mapBounds.minLng) / lngSpan) * 100;

    return {
      x: Math.max(5, Math.min(95, xPct)),
      y: Math.max(5, Math.min(95, yPct)),
    };
  };

  const selectedComplaint = useMemo(() => {
    return complaints.find((c) => c.id === selectedPinId) || null;
  }, [complaints, selectedPinId]);

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col space-y-0">
      {/* Map Control Bar */}
      <div className="p-4 bg-slate-900 text-white border-b border-slate-800 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <h3 className="text-base font-bold tracking-tight text-white flex items-center gap-2">
              <Compass className="w-5 h-5 text-emerald-400" />
              <span>Civic Issue Intelligence Map</span>
            </h3>
            <span className="text-[11px] font-mono bg-slate-800 px-2 py-0.5 rounded text-slate-300 border border-slate-700">
              {filteredComplaints.length} plotted
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Geographic spatial clustering across municipal wards and infrastructure sectors
          </p>
        </div>

        {/* Filter Controls Bar */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          {/* Category Filter */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-slate-200 focus:outline-none focus:ring-1 focus:ring-emerald-500 font-medium"
          >
            <option value="ALL">All Categories</option>
            <option value="Roads">Roads</option>
            <option value="Street Lights">Street Lights</option>
            <option value="Water Supply">Water Supply</option>
            <option value="Garbage">Garbage</option>
            <option value="Drainage">Drainage</option>
            <option value="Public Safety">Public Safety</option>
            <option value="Other">Other</option>
          </select>

          {/* Status Filter */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-slate-200 focus:outline-none focus:ring-1 focus:ring-emerald-500 font-medium"
          >
            <option value="ALL">All Statuses</option>
            <option value="ACTIVE">Active (In Triage / Field)</option>
            <option value="AWAITING VERIFICATION">Awaiting Verification</option>
            <option value="RESOLVED">Verified & Closed</option>
            <option value="REOPENED">Reopened</option>
          </select>

          {/* Priority Filter */}
          <select
            value={selectedPriority}
            onChange={(e) => setSelectedPriority(e.target.value)}
            className="px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-slate-200 focus:outline-none focus:ring-1 focus:ring-emerald-500 font-medium"
          >
            <option value="ALL">All Priorities</option>
            <option value="CRITICAL">Critical</option>
            <option value="HIGH">High</option>
            <option value="MEDIUM">Medium</option>
            <option value="LOW">Low</option>
          </select>

          {/* Heatmap Toggle */}
          <button
            onClick={() => setShowHeatmap(!showHeatmap)}
            className={`px-3 py-1.5 rounded-lg border flex items-center gap-1.5 transition-all font-semibold ${
              showHeatmap
                ? 'bg-rose-500/20 border-rose-500/60 text-rose-300'
                : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
            }`}
          >
            <Flame className="w-3.5 h-3.5 text-rose-400" />
            <span>Hotspots</span>
          </button>

          {/* Zoom controls */}
          <div className="flex items-center bg-slate-800 rounded-lg border border-slate-700 p-0.5">
            <button
              onClick={() => setZoomLevel((z) => Math.min(1.6, z + 0.15))}
              className="p-1 hover:text-white text-slate-400"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setZoomLevel((z) => Math.max(0.85, z - 0.15))}
              className="p-1 hover:text-white text-slate-400"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setZoomLevel(1)}
              className="p-1 hover:text-white text-slate-400"
              title="Reset Zoom"
            >
              <RotateCcw className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Map Body: GIS Vector Canvas + Sidebar / Drawer */}
      <div className="relative w-full h-[520px] bg-[#0c1829] overflow-hidden select-none">
        {/* Interactive SVG GIS Map Canvas */}
        <div
          className="w-full h-full transition-transform duration-300 ease-out origin-center"
          style={{ transform: `scale(${zoomLevel})` }}
        >
          <svg
            className="w-full h-full"
            viewBox="0 0 1000 600"
            preserveAspectRatio="none"
          >
            <defs>
              {/* Radial gradient for hotspot heat zones */}
              <radialGradient id="heatGradient" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#ef4444" stopOpacity="0.45" />
                <stop offset="40%" stopColor="#f59e0b" stopOpacity="0.25" />
                <stop offset="80%" stopColor="#3b82f6" stopOpacity="0.1" />
                <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
              </radialGradient>

              {/* Grid pattern */}
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1e293b" strokeWidth="0.8" />
              </pattern>
            </defs>

            {/* Background Grid */}
            <rect width="1000" height="600" fill="#0f172a" />
            <rect width="1000" height="600" fill="url(#grid)" />

            {/* Stylized River / Water Canal */}
            <path
              d="M -50 480 Q 250 440, 480 320 T 950 200 L 1050 210 L 1050 240 Q 520 350, 240 470 T -50 510 Z"
              fill="#0284c7"
              fillOpacity="0.18"
            />
            <path
              d="M -50 495 Q 250 455, 480 335 T 950 215"
              fill="none"
              stroke="#38bdf8"
              strokeWidth="2"
              strokeOpacity="0.3"
              strokeDasharray="6 4"
            />

            {/* Municipal Green Belts / Parks */}
            <rect x="80" y="80" width="160" height="110" rx="16" fill="#065f46" fillOpacity="0.2" />
            <text x="95" y="105" fill="#34d399" fontSize="11" fontWeight="bold" opacity="0.6">
              CENTRAL NATURE RESERVE
            </text>

            <rect x="680" y="380" width="220" height="140" rx="20" fill="#065f46" fillOpacity="0.2" />
            <text x="700" y="410" fill="#34d399" fontSize="11" fontWeight="bold" opacity="0.6">
              LAKEVIEW PARKLANDS
            </text>

            {/* Major Arterial Roads */}
            {/* Horizontal Ring Road */}
            <line x1="0" y1="280" x2="1000" y2="280" stroke="#334155" strokeWidth="12" />
            <line x1="0" y1="280" x2="1000" y2="280" stroke="#475569" strokeWidth="4" strokeDasharray="14 10" />

            {/* Vertical Boulevard */}
            <line x1="480" y1="0" x2="480" y2="600" stroke="#334155" strokeWidth="12" />
            <line x1="480" y1="0" x2="480" y2="600" stroke="#475569" strokeWidth="4" strokeDasharray="14 10" />

            {/* Diagonal Arterials */}
            <line x1="120" y1="0" x2="880" y2="600" stroke="#1e293b" strokeWidth="6" />
            <line x1="880" y1="0" x2="120" y2="600" stroke="#1e293b" strokeWidth="6" />

            {/* Ward Zones Overlay Labels */}
            <g opacity="0.5" fill="#94a3b8" fontSize="11" fontWeight="600">
              <text x="140" y="240">WARD 12 (NORTH-WEST)</text>
              <text x="620" y="140">WARD 5 (MARKET DISTRICT)</text>
              <text x="320" y="360">WARD 7 (CENTRAL CORRIDOR)</text>
              <text x="720" y="260">SECTOR 8 (EAST COMMERCIAL)</text>
              <text x="180" y="440">SECTOR 4 (RESIDENTIAL)</text>
              <text x="640" y="520">LAKEVIEW COLONY (SOUTH)</text>
            </g>

            {/* Dynamic Heatmap Density Clusters */}
            {showHeatmap &&
              filteredComplaints.map((c) => {
                const coords = getComplaintCoordinates(c);
                const { x, y } = getCoordinatesPct(coords);
                const svgX = (x / 100) * 1000;
                const svgY = (y / 100) * 600;
                const radius = c.priority === 'CRITICAL' ? 110 : c.priority === 'HIGH' ? 85 : 60;

                return (
                  <circle
                    key={`heat-${c.id}`}
                    cx={svgX}
                    cy={svgY}
                    r={radius}
                    fill="url(#heatGradient)"
                    className="pointer-events-none animate-pulse-subtle"
                  />
                );
              })}
          </svg>
        </div>

        {/* DOM HTML Layer: Pins on Map */}
        <div
          className="absolute inset-0 pointer-events-none transition-transform duration-300 ease-out origin-center"
          style={{ transform: `scale(${zoomLevel})` }}
        >
          {filteredComplaints.map((c) => {
            const coords = getComplaintCoordinates(c);
            const { x, y } = getCoordinatesPct(coords);
            const isSelected = selectedPinId === c.id;
            const catConfig = categoryColors[c.category] || categoryColors['Other'];
            const isCriticalOrHigh = c.priority === 'CRITICAL' || c.priority === 'HIGH';
            const isClosed = c.status === 'CLOSED' || c.status === 'VERIFIED / CLOSED' || c.status === 'VERIFIED';
            const isReopened = c.status === 'REOPENED';
            const isAwaiting = c.status === 'AWAITING VERIFICATION';

            return (
              <div
                key={c.id}
                onClick={() => setSelectedPinId(isSelected ? null : c.id)}
                style={{ left: `${x}%`, top: `${y}%` }}
                className="absolute -translate-x-1/2 -translate-y-1/2 pointer-events-auto cursor-pointer z-10 group"
              >
                {/* Pulsing halo for active critical issues */}
                {isCriticalOrHigh && !isClosed && (
                  <span className="absolute -inset-2.5 rounded-full bg-rose-500/40 animate-ping pointer-events-none" />
                )}

                {/* Pin Circle */}
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-white shadow-xl transition-all border-2 ${
                    isSelected
                      ? 'scale-125 ring-4 ring-white border-white z-30'
                      : 'hover:scale-115 border-slate-900 group-hover:ring-2 group-hover:ring-emerald-400'
                  } ${catConfig.pinBg}`}
                >
                  {isClosed ? (
                    <CheckCircle2 className="w-4 h-4 text-white" />
                  ) : isReopened ? (
                    <RotateCcw className="w-4 h-4 text-white" />
                  ) : isAwaiting ? (
                    <Clock className="w-4 h-4 text-white animate-spin-slow" />
                  ) : (
                    <MapPin className="w-4 h-4 text-white" />
                  )}
                </div>

                {/* Floating Tooltip Pill */}
                <div
                  className={`absolute left-1/2 -translate-x-1/2 bottom-full mb-1 px-2 py-0.5 rounded-md bg-slate-900 text-white font-mono text-[10px] font-bold shadow-md whitespace-nowrap transition-all border border-slate-700 pointer-events-none ${
                    isSelected ? 'opacity-100 scale-105' : 'opacity-0 group-hover:opacity-100'
                  }`}
                >
                  {c.id} • {c.category}
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Complaint Inspection Drawer */}
        {selectedComplaint && (
          <div className="absolute right-4 top-4 bottom-4 w-80 sm:w-96 bg-white/95 backdrop-blur-md rounded-2xl shadow-2xl border border-slate-300 p-5 z-40 overflow-y-auto animate-in slide-in-from-right space-y-4">
            <div className="flex items-start justify-between border-b border-slate-200 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs font-bold bg-slate-900 text-emerald-400 px-2.5 py-0.5 rounded">
                    {selectedComplaint.id}
                  </span>
                  <StatusBadge status={selectedComplaint.status} size="sm" />
                </div>
                <h4 className="text-sm font-bold text-slate-900 mt-1 leading-snug">
                  {selectedComplaint.title}
                </h4>
              </div>
              <button
                onClick={() => setSelectedPinId(null)}
                className="p-1 text-slate-400 hover:text-slate-800 rounded-lg hover:bg-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Photo Preview if available */}
            {selectedComplaint.photoUrl && (
              <div className="h-32 w-full rounded-xl overflow-hidden border border-slate-200 bg-slate-100">
                <img
                  src={selectedComplaint.photoUrl}
                  alt={selectedComplaint.title}
                  className="w-full h-full object-cover"
                />
              </div>
            )}

            <div className="space-y-2 text-xs">
              <div className="flex items-start gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                <MapPin className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                <div>
                  <span className="text-[11px] font-bold text-slate-400 uppercase block">Location & Ward:</span>
                  <span className="font-medium text-slate-800">{selectedComplaint.location}</span>
                  <div className="flex items-center gap-1.5 mt-1 text-[10px]">
                    <span className="px-1.5 py-0.2 bg-slate-200 text-slate-700 rounded font-semibold">
                      {selectedComplaint.ward || extractWardName(selectedComplaint.location)}
                    </span>
                    {selectedComplaint.coordinates && (
                      <span className="text-emerald-700 font-semibold">
                        GPS: {selectedComplaint.coordinates.lat.toFixed(4)}, {selectedComplaint.coordinates.lng.toFixed(4)}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-400 uppercase block">Category:</span>
                  <span className="font-bold text-slate-900">{selectedComplaint.category}</span>
                </div>
                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-400 uppercase block">Priority:</span>
                  <PriorityBadge priority={selectedComplaint.priority} />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-400 uppercase block">Department:</span>
                  <span className="font-semibold text-slate-800 truncate block">
                    {selectedComplaint.department || selectedComplaint.assignedDepartment || 'Pending Triage'}
                  </span>
                </div>
                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-400 uppercase block">Field Worker:</span>
                  <span className="font-semibold text-slate-800 truncate block">
                    {selectedComplaint.assignedWorker || 'Unassigned'}
                  </span>
                </div>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => onSelectComplaint(selectedComplaint)}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2 hover:scale-[1.01]"
              >
                <Eye className="w-4 h-4 text-emerald-400" />
                <span>Open Full Complaint Dossier</span>
              </button>
            </div>
          </div>
        )}

        {/* Floating Map Legend (Bottom Left) */}
        <div className="absolute left-4 bottom-4 bg-slate-900/90 backdrop-blur-sm border border-slate-800 text-white p-3 rounded-xl shadow-lg text-[11px] hidden sm:block z-20">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1.5">
            Category Map Key:
          </span>
          <div className="grid grid-cols-2 gap-x-3 gap-y-1">
            {Object.entries(categoryColors).map(([cat, cfg]) => (
              <div key={cat} className="flex items-center gap-1.5">
                <span className={`w-2.5 h-2.5 rounded-full ${cfg.pinBg}`} />
                <span className="text-slate-300 font-medium">{cat}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
