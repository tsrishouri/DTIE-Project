import React, { useState, useEffect, useRef } from 'react';
import { useCivic } from '../context/CivicContext';
import { ComplaintCategory, AiTriageSuggestion, DuplicateMatchResult } from '../types';
import { getCategoryEvidence } from '../data/categoryEvidence';
import { extractWardName, extractZoneName } from '../utils/coordinates';
import { aiService } from '../services/aiService';
import {
  Camera,
  MapPin,
  CheckCircle2,
  X,
  AlertTriangle,
  Lightbulb,
  Droplets,
  Trash2,
  ShieldAlert,
  HelpCircle,
  Car,
  Waves,
  UploadCloud,
  Mic,
  MicOff,
  Sparkles,
  Lock,
  Copy,
  Compass,
  Radio,
  ExternalLink,
} from 'lucide-react';

const CATEGORIES: { id: ComplaintCategory; label: string; icon: React.ElementType; color: string }[] = [
  { id: 'Roads', label: 'Roads', icon: Car, color: 'text-amber-600 bg-amber-50 border-amber-200' },
  { id: 'Street Lights', label: 'Street Lights', icon: Lightbulb, color: 'text-yellow-600 bg-yellow-50 border-yellow-200' },
  { id: 'Water Supply', label: 'Water Supply', icon: Droplets, color: 'text-blue-600 bg-blue-50 border-blue-200' },
  { id: 'Garbage', label: 'Garbage', icon: Trash2, color: 'text-emerald-600 bg-emerald-50 border-emerald-200' },
  { id: 'Drainage', label: 'Drainage', icon: Waves, color: 'text-cyan-600 bg-cyan-50 border-cyan-200' },
  { id: 'Public Safety', label: 'Public Safety', icon: ShieldAlert, color: 'text-rose-600 bg-rose-50 border-rose-200' },
  { id: 'Other', label: 'Other', icon: HelpCircle, color: 'text-purple-600 bg-purple-200 border-purple-200' },
];

export const ReportIssueModal: React.FC = () => {
  const { complaints, createComplaint, setActiveView, setSelectedComplaintId } = useCivic();

  const [category, setCategory] = useState<ComplaintCategory>('Roads');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [ward, setWard] = useState('Ward 7');
  const [zone, setZone] = useState('East Zone');
  const [photoUrl, setPhotoUrl] = useState<string>(
    getCategoryEvidence('Roads').defaultBeforePhoto
  );
  const [citizenName, setCitizenName] = useState('Citizen Resident');
  const [citizenPhone, setCitizenPhone] = useState('+1 (555) 019-2834');
  const [isContactMasked, setIsContactMasked] = useState(true);
  const [submittedId, setSubmittedId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // 1. Voice Reporting State
  const [isVoiceSupported, setIsVoiceSupported] = useState(true);
  const [isRecording, setIsRecording] = useState(false);
  const [voiceTranscript, setVoiceTranscript] = useState('');
  const [voiceNotice, setVoiceNotice] = useState<string | null>(null);
  const speechRecognitionRef = useRef<any>(null);

  // 2. GPS + Timestamp State
  const [gpsStatus, setGpsStatus] = useState<'idle' | 'capturing' | 'captured' | 'denied'>('idle');
  const [gpsData, setGpsData] = useState<{
    lat: number;
    lng: number;
    capturedAt: string;
    accuracy?: number;
  } | null>(null);

  // 3. AI Civic Triage & Duplicate Assistance
  const [aiSuggestion, setAiSuggestion] = useState<AiTriageSuggestion | null>(null);
  const [duplicateWarning, setDuplicateWarning] = useState<DuplicateMatchResult | null>(null);
  const [isAiAnalyzing, setIsAiAnalyzing] = useState(false);

  const categoryEvidence = getCategoryEvidence(category);

  // Check speech recognition capability on mount
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const hasSpeech = 'SpeechRecognition' in window || 'webkitSpeechRecognition' in window;
      setIsVoiceSupported(hasSpeech);
      if (!hasSpeech) {
        setVoiceNotice('Voice input is not supported in this browser. You can continue with text.');
      }
    }
  }, []);

  // Update Ward and Zone automatically when location text changes
  useEffect(() => {
    if (location.trim()) {
      const extractedWard = extractWardName(location);
      const extractedZone = extractZoneName(location, extractedWard);
      setWard(extractedWard);
      setZone(extractedZone);
    }
  }, [location]);

  // AI Assistance & Duplicate Similarity Check (Debounced)
  useEffect(() => {
    if (title.length < 5 && description.length < 5) {
      setAiSuggestion(null);
      setDuplicateWarning(null);
      return;
    }

    const timer = setTimeout(async () => {
      setIsAiAnalyzing(true);
      try {
        const suggestion = await aiService.suggestTriage(title, description, location);
        setAiSuggestion(suggestion);

        const dup = aiService.detectDuplicates(
          {
            title,
            description,
            category,
            location,
          },
          complaints
        );
        if (dup.isDuplicate) {
          setDuplicateWarning(dup);
        } else {
          setDuplicateWarning(null);
        }
      } catch (err) {
        console.warn('AI Triage error:', err);
      } finally {
        setIsAiAnalyzing(false);
      }
    }, 450);

    return () => clearTimeout(timer);
  }, [title, description, category, location, complaints]);

  const handleCategorySelect = (newCategory: ComplaintCategory) => {
    setCategory(newCategory);
    if (!photoUrl || !photoUrl.startsWith('data:')) {
      setPhotoUrl(getCategoryEvidence(newCategory).defaultBeforePhoto);
    }
  };

  // 1. Voice Reporting Handlers
  const startVoiceRecording = () => {
    if (!isVoiceSupported) {
      setVoiceNotice('Voice input is not supported in this browser. You can continue with text.');
      return;
    }

    try {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (!SpeechRecognition) {
        setIsVoiceSupported(false);
        setVoiceNotice('Voice input is not supported in this browser. You can continue with text.');
        return;
      }

      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        setIsRecording(true);
        setVoiceNotice(null);
      };

      recognition.onresult = (event: any) => {
        let current = '';
        for (let i = 0; i < event.results.length; i++) {
          current += event.results[i][0].transcript + ' ';
        }
        setVoiceTranscript(current.trim());
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        setIsRecording(false);
        if (event.error === 'not-allowed') {
          setVoiceNotice('Microphone permission was denied. You can continue typing with text.');
        } else {
          setVoiceNotice('Voice input interrupted. You can continue typing with text.');
        }
      };

      recognition.onend = () => {
        setIsRecording(false);
      };

      speechRecognitionRef.current = recognition;
      recognition.start();
    } catch (e) {
      console.warn('Speech recognition start failed:', e);
      setIsRecording(false);
      setVoiceNotice('Voice input is not supported in this browser. You can continue with text.');
    }
  };

  const stopVoiceRecording = () => {
    if (speechRecognitionRef.current) {
      speechRecognitionRef.current.stop();
      setIsRecording(false);
    }
  };

  const useVoiceTranscription = () => {
    if (voiceTranscript.trim()) {
      setDescription((prev) =>
        prev.trim() ? `${prev.trim()} ${voiceTranscript.trim()}` : voiceTranscript.trim()
      );
      setVoiceTranscript('');
      stopVoiceRecording();
    }
  };

  // 2. GPS + Timestamp Location Capture Handler
  const handleCaptureGpsLocation = () => {
    if (!navigator.geolocation) {
      setGpsStatus('denied');
      return;
    }

    setGpsStatus('capturing');

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const capturedAtIso = new Date().toISOString();
        const lat = Number(pos.coords.latitude.toFixed(5));
        const lng = Number(pos.coords.longitude.toFixed(5));

        setGpsData({
          lat,
          lng,
          capturedAt: capturedAtIso,
          accuracy: pos.coords.accuracy,
        });
        setGpsStatus('captured');

        // Autofill location text with extracted Ward and Coordinates
        const locationText = `Ward 7, Sector 3 (GPS: ${lat.toFixed(4)}° N, ${lng.toFixed(4)}° W)`;
        setLocation(locationText);
        setWard('Ward 7');
        setZone('East Zone');
      },
      (err) => {
        console.warn('Geolocation denied or unavailable:', err.message);
        setGpsStatus('denied');
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setPhotoUrl(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const applyAiCategory = () => {
    if (aiSuggestion) {
      handleCategorySelect(aiSuggestion.suggestedCategory);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Please provide a title for the issue.');
      return;
    }
    if (!description.trim()) {
      setError('Please provide a description of the problem.');
      return;
    }
    if (!location.trim()) {
      setError('Please specify the location or neighborhood.');
      return;
    }

    setError(null);
    const newId = createComplaint({
      title,
      description,
      category,
      location,
      ward,
      zone,
      photoUrl,
      citizenName,
      citizenPhone,
      isContactMasked,
      coordinates: gpsData ? { lat: gpsData.lat, lng: gpsData.lng, capturedAt: gpsData.capturedAt } : undefined,
      gpsCaptured: gpsStatus === 'captured',
      gpsCapturedAt: gpsData?.capturedAt,
      aiTriage: aiSuggestion || undefined,
    });

    setSubmittedId(newId);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      {submittedId ? (
        <div className="bg-white rounded-2xl shadow-xl border border-emerald-100 p-8 text-center animate-fade-in">
          <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle2 className="w-10 h-10" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Complaint Submitted Successfully!</h2>
          <p className="text-slate-600 max-w-lg mx-auto mb-6">
            Your complaint has been registered in the municipal database with timestamped evidence and dispatched to the triage desk.
          </p>

          <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 mb-8 max-w-md mx-auto">
            <div className="text-xs uppercase font-semibold tracking-wider text-slate-500 mb-1">
              Your Unique Tracking ID
            </div>
            <div className="text-2xl font-mono font-bold text-emerald-700 tracking-wider">
              {submittedId}
            </div>
            <div className="flex items-center justify-center gap-2 mt-2 text-xs text-slate-500">
              <Compass className="w-3.5 h-3.5 text-blue-600" />
              <span>Assigned: {ward} • {zone}</span>
              {gpsData && <span className="text-emerald-600 font-semibold">• GPS Verified</span>}
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={() => {
                setSelectedComplaintId(submittedId);
                setActiveView('track');
              }}
              className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold shadow-md transition-all"
            >
              Track Complaint Status
            </button>
            <button
              onClick={() => {
                setSubmittedId(null);
                setTitle('');
                setDescription('');
                setActiveView('dashboard');
              }}
              className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold transition-all"
            >
              Return to Citizen Portal
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white p-6 sm:p-8">
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs font-semibold tracking-wider text-emerald-400 uppercase">
                    CivicPulse Citizen Reporting Engine
                  </span>
                  <span className="bg-blue-900/60 text-blue-300 text-[10px] px-2 py-0.5 rounded-full font-mono border border-blue-700/50">
                    Voice + GPS + AI Copilot
                  </span>
                </div>
                <h1 className="text-2xl sm:text-3xl font-bold">Report a Civic Problem</h1>
                <p className="text-sm text-slate-300 mt-1">
                  Voice input, real-time GPS coordinates, and transparent before/after verification.
                </p>
              </div>
              <button
                onClick={() => setActiveView('dashboard')}
                className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-700 transition-colors"
                title="Cancel"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
          </div>

          {/* Privacy & Sandbox Notice Banner */}
          <div className="bg-emerald-50/80 border-b border-emerald-200 px-6 py-2.5 flex items-center justify-between text-xs text-emerald-900">
            <div className="flex items-center gap-2">
              <Lock className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
              <span>
                <strong>Privacy Guard Active:</strong> Contact information is masked from public visibility. Prototype records persist securely in your local browser sandbox.
              </span>
            </div>
          </div>

          {error && (
            <div className="m-6 p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 shrink-0 text-rose-600" />
              <p className="text-sm font-medium">{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="p-6 sm:p-8 space-y-6">
            {/* Category Selection */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-semibold text-slate-800">
                  Issue Category <span className="text-rose-500">*</span>
                </label>
                {aiSuggestion && aiSuggestion.suggestedCategory !== category && (
                  <button
                    type="button"
                    onClick={applyAiCategory}
                    className="inline-flex items-center gap-1.5 text-xs text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 px-2.5 py-1 rounded-lg font-medium transition-all"
                  >
                    <Sparkles className="w-3 h-3 text-blue-600" />
                    <span>AI suggests: <strong>{aiSuggestion.suggestedCategory}</strong> ({Math.round(aiSuggestion.confidence * 100)}%)</span>
                  </button>
                )}
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {CATEGORIES.map((cat) => {
                  const Icon = cat.icon;
                  const isSelected = category === cat.id;
                  const isAiRecommended = aiSuggestion?.suggestedCategory === cat.id;

                  return (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => handleCategorySelect(cat.id)}
                      className={`relative flex flex-col items-center justify-center p-3 rounded-xl border text-center transition-all ${
                        isSelected
                          ? 'border-emerald-600 bg-emerald-50/70 text-emerald-900 shadow-sm ring-2 ring-emerald-500'
                          : 'border-slate-200 hover:border-slate-300 bg-slate-50/50 text-slate-700'
                      }`}
                    >
                      {isAiRecommended && !isSelected && (
                        <span className="absolute -top-1.5 -right-1 bg-blue-600 text-white text-[9px] px-1.5 py-0.2 rounded-full font-bold shadow-xs flex items-center gap-0.5">
                          <Sparkles className="w-2.5 h-2.5" /> AI
                        </span>
                      )}
                      <Icon className={`w-5 h-5 mb-1.5 ${isSelected ? 'text-emerald-700' : 'text-slate-500'}`} />
                      <span className="text-xs font-medium">{cat.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Title */}
            <div>
              <label className="block text-sm font-semibold text-slate-800 mb-1.5">
                Issue Title <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Broken street light pole array near pathway"
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 text-sm"
              />
            </div>

            {/* Duplicate Detection Alert Card (Real-time duplicate detection) */}
            {duplicateWarning && duplicateWarning.isDuplicate && (
              <div className="p-4 rounded-xl bg-amber-50 border-2 border-amber-300 text-amber-950 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-in fade-in">
                <div className="flex items-start gap-3">
                  <Copy className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-xs uppercase tracking-wider text-amber-800">
                        Possible Duplicate Found ({duplicateWarning.similarity}% similarity)
                      </span>
                      <span className="bg-amber-200 text-amber-900 text-[10px] px-2 py-0.5 rounded font-mono font-bold">
                        {duplicateWarning.matchedComplaintId}
                      </span>
                    </div>
                    <p className="text-xs text-amber-900 mt-0.5 font-medium">
                      "{duplicateWarning.matchedTitle}"
                    </p>
                    <p className="text-[11px] text-amber-700 mt-1">
                      {duplicateWarning.reason}. You can check if this issue is already being resolved before filing a duplicate.
                    </p>
                  </div>
                </div>
                {duplicateWarning.matchedComplaintId && (
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedComplaintId(duplicateWarning.matchedComplaintId!);
                      setActiveView('track');
                    }}
                    className="shrink-0 text-xs px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-semibold rounded-lg shadow-sm flex items-center gap-1"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>View Existing</span>
                  </button>
                )}
              </div>
            )}

            {/* Description + Voice Reporting Interface */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-sm font-semibold text-slate-800">
                  Detailed Description <span className="text-rose-500">*</span>
                </label>

                {/* Voice Input Buttons */}
                <div className="flex items-center gap-2">
                  {!isRecording ? (
                    <button
                      type="button"
                      onClick={startVoiceRecording}
                      className="inline-flex items-center gap-1.5 px-3 py-1 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 text-slate-700 rounded-lg text-xs font-semibold border border-slate-200 transition-all"
                      title="Speak your complaint using microphone"
                    >
                      <Mic className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Start Voice Report</span>
                    </button>
                  ) : (
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={stopVoiceRecording}
                        className="inline-flex items-center gap-1 px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-semibold transition-all shadow-xs"
                      >
                        <MicOff className="w-3 h-3" />
                        <span>Stop Recording</span>
                      </button>
                      {voiceTranscript.trim() && (
                        <button
                          type="button"
                          onClick={useVoiceTranscription}
                          className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold transition-all shadow-xs"
                        >
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Use Transcription</span>
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Voice Notice (Browser support fallback) */}
              {voiceNotice && (
                <div className="mb-2 p-2 rounded-lg bg-slate-100 border border-slate-200 text-xs text-slate-600 flex items-center justify-between">
                  <span>{voiceNotice}</span>
                  <button type="button" onClick={() => setVoiceNotice(null)} className="text-slate-400 hover:text-slate-600">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {/* Live Voice Recording Preview Box */}
              {isRecording && (
                <div className="mb-2 p-3 bg-rose-50/70 border border-rose-200 rounded-xl text-xs text-rose-950 flex flex-col gap-2 animate-in fade-in">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-rose-600 animate-ping" />
                      <span className="font-bold text-rose-900">Listening to voice input...</span>
                    </div>
                    <span className="text-[11px] text-rose-700">Speak clearly into microphone</span>
                  </div>
                  <div className="p-2 bg-white rounded-lg border border-rose-200 italic text-slate-800 min-h-[36px]">
                    {voiceTranscript || 'Waiting for speech...'}
                  </div>
                  {voiceTranscript && (
                    <button
                      type="button"
                      onClick={useVoiceTranscription}
                      className="self-end px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg transition-all"
                    >
                      Use Transcription
                    </button>
                  )}
                </div>
              )}

              <textarea
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe the severity, duration, hazards, and exact issue details..."
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 text-sm"
              />
            </div>

            {/* AI Triage Copilot Recommendation Box */}
            {aiSuggestion && (
              <div className="p-3.5 rounded-xl bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 text-xs text-slate-800">
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-1.5 font-bold text-blue-900">
                    <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                    <span>AI Civic Triage Recommendation (Demo Copilot)</span>
                  </div>
                  <span className="text-[11px] font-semibold text-blue-700 bg-blue-100 px-2 py-0.5 rounded-md">
                    {Math.round(aiSuggestion.confidence * 100)}% Confidence
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-2 pt-2 border-t border-blue-200/60 text-slate-700">
                  <div>
                    <span className="text-[10px] uppercase text-slate-500 font-bold block">Category</span>
                    <span className="font-semibold text-slate-900">{aiSuggestion.suggestedCategory}</span>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase text-slate-500 font-bold block">Assessed Severity</span>
                    <span className={`font-bold ${
                      aiSuggestion.suggestedPriority === 'CRITICAL' ? 'text-rose-600' :
                      aiSuggestion.suggestedPriority === 'HIGH' ? 'text-amber-700' : 'text-blue-700'
                    }`}>
                      {aiSuggestion.suggestedPriority}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase text-slate-500 font-bold block">Responsible Unit</span>
                    <span className="font-semibold text-slate-900">{aiSuggestion.suggestedDepartment}</span>
                  </div>
                </div>
                <p className="mt-2 text-[11px] text-slate-600 italic">
                  "{aiSuggestion.reasoning}"
                </p>
              </div>
            )}

            {/* Location + GPS Capture */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-sm font-semibold text-slate-800">
                  Location / Address <span className="text-rose-500">*</span>
                </label>

                {/* GPS Capture Button */}
                <button
                  type="button"
                  onClick={handleCaptureGpsLocation}
                  disabled={gpsStatus === 'capturing'}
                  className="text-xs font-medium text-emerald-700 hover:text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-3 py-1 rounded-lg flex items-center gap-1.5 transition-all"
                >
                  <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                  <span>
                    {gpsStatus === 'capturing'
                      ? 'Acquiring GPS...'
                      : gpsStatus === 'captured'
                      ? 'Re-Capture Current Location'
                      : 'Capture Current Location'}
                  </span>
                </button>
              </div>

              <div className="relative mb-2">
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="e.g. 14th Cross Road near Government Hospital, Ward 8"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 text-sm"
                />
                <MapPin className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              </div>

              {/* GPS Verification Status Indicator */}
              {gpsStatus === 'captured' && gpsData && (
                <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-950 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>
                      <strong>Location captured:</strong> {gpsData.lat}° N, {gpsData.lng}° W • Captured at {new Date(gpsData.capturedAt).toLocaleTimeString()}
                    </span>
                  </div>
                  <span className="text-[10px] bg-emerald-200 text-emerald-900 font-bold px-2 py-0.5 rounded">
                    GPS Verified
                  </span>
                </div>
              )}

              {gpsStatus === 'denied' && (
                <div className="p-2.5 rounded-lg bg-slate-100 border border-slate-200 text-xs text-slate-600 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>
                    Location permission unavailable. You can continue with manual location text.
                  </span>
                </div>
              )}

              {/* Ward and Zone Context Confirmation */}
              <div className="grid grid-cols-2 gap-3 mt-3">
                <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl">
                  <span className="text-[10px] uppercase font-bold text-slate-500 block">Civic Ward</span>
                  <input
                    type="text"
                    value={ward}
                    onChange={(e) => setWard(e.target.value)}
                    placeholder="e.g. Ward 7"
                    className="w-full bg-transparent text-xs font-semibold text-slate-900 focus:outline-none"
                  />
                </div>
                <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl">
                  <span className="text-[10px] uppercase font-bold text-slate-500 block">Administrative Zone</span>
                  <input
                    type="text"
                    value={zone}
                    onChange={(e) => setZone(e.target.value)}
                    placeholder="e.g. East Zone"
                    className="w-full bg-transparent text-xs font-semibold text-slate-900 focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Photo Attachment & Presets */}
            <div>
              <label className="block text-sm font-semibold text-slate-800 mb-1.5">
                Issue Photo Evidence <span className="text-xs font-normal text-slate-500">({category} Evidence)</span>
              </label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Upload or Preview */}
                <div className="border-2 border-dashed border-slate-300 rounded-xl p-4 text-center bg-slate-50 flex flex-col items-center justify-center relative min-h-[160px]">
                  {photoUrl ? (
                    <div className="relative w-full h-36 rounded-lg overflow-hidden group">
                      <img src={photoUrl} alt="Preview" className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() => setPhotoUrl('')}
                        className="absolute top-2 right-2 p-1.5 bg-black/60 text-white rounded-full hover:bg-black transition-opacity"
                        title="Remove photo"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <div>
                      <Camera className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                      <p className="text-xs text-slate-600 font-medium">Upload photo from device</p>
                      <label className="mt-2 inline-flex items-center gap-1 px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 cursor-pointer hover:bg-slate-100 shadow-sm">
                        <UploadCloud className="w-3.5 h-3.5" />
                        <span>Select file</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={handleFileChange}
                        />
                      </label>
                    </div>
                  )}
                </div>

                {/* Quick Presets for fast testing */}
                <div className="space-y-2">
                  <span className="text-xs font-medium text-slate-500">
                    Category Demo Presets ({category}):
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {categoryEvidence.beforePresets.map((preset, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setPhotoUrl(preset.url)}
                        className={`p-2 rounded-lg border text-left text-xs transition-all flex items-center gap-2 ${
                          photoUrl === preset.url
                            ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-semibold ring-1 ring-emerald-500'
                            : 'border-slate-200 hover:border-slate-300 bg-white text-slate-700'
                        }`}
                      >
                        <img
                          src={preset.url}
                          alt={preset.label}
                          className="w-9 h-9 rounded object-cover shrink-0 border border-slate-200"
                        />
                        <span className="text-[11px] font-medium leading-snug line-clamp-2">
                          {preset.label}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Reporter details & Privacy Protection */}
            <div className="pt-2 border-t border-slate-100 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Citizen Name
                  </label>
                  <input
                    type="text"
                    value={citizenName}
                    onChange={(e) => setCitizenName(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Contact Phone (for SMS / verification)
                  </label>
                  <input
                    type="text"
                    value={citizenPhone}
                    onChange={(e) => setCitizenPhone(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs text-slate-900"
                  />
                </div>
              </div>

              {/* Privacy Safeguard Checkbox */}
              <div className="flex items-center gap-2 p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <input
                  type="checkbox"
                  id="maskContact"
                  checked={isContactMasked}
                  onChange={(e) => setIsContactMasked(e.target.checked)}
                  className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500 border-slate-300"
                />
                <label htmlFor="maskContact" className="text-xs text-slate-700 cursor-pointer select-none">
                  <strong>Mask contact details from public tracking:</strong> Protect personal phone number with prototype PII redaction.
                </label>
              </div>
            </div>

            {/* Submit button */}
            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3.5 px-6 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-lg shadow-emerald-900/20 transition-all flex items-center justify-center gap-2 hover:scale-[1.01]"
              >
                <CheckCircle2 className="w-5 h-5" />
                <span>Submit Complaint to CivicPulse</span>
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
