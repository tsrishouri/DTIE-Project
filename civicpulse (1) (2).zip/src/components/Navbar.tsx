import React from 'react';
import { useCivic } from '../context/CivicContext';
import { UserRole } from '../types';
import {
  Building2,
  HardHat,
  UserCheck,
  PlusCircle,
  Search,
  RotateCcw,
  SlidersHorizontal,
  Home,
  CheckCircle2,
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    currentRole,
    setCurrentRole,
    activeView,
    setActiveView,
    complaints,
    resetToDefaults,
  } = useCivic();

  const awaitingCount = complaints.filter(
    (c) => c.status === 'AWAITING VERIFICATION' || c.status === 'RESOLUTION SUBMITTED'
  ).length;

  const roles: { id: UserRole; label: string; icon: React.ElementType; badge?: string }[] = [
    { id: 'citizen', label: 'Citizen', icon: UserCheck, badge: awaitingCount > 0 ? `${awaitingCount} To Verify` : undefined },
    { id: 'field_worker', label: 'Field Worker', icon: HardHat },
    { id: 'supervisor', label: 'Municipal Supervisor', icon: Building2 },
  ];

  return (
    <header className="sticky top-0 z-40 bg-slate-900 border-b border-slate-800 text-white shadow-md">
      {/* Top Utility / Role Switcher Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-center justify-between py-3 gap-3 border-b border-slate-800/80">
          {/* Brand Logo */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveView('dashboard')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center text-white shadow-inner shadow-emerald-400/30">
              <Building2 className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-bold tracking-tight text-white">CivicPulse</span>
                <span className="text-[10px] uppercase tracking-wider font-semibold bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/30">
                  Municipal Portal
                </span>
              </div>
              <p className="text-xs text-slate-400">Verifiable civic complaint & resolution lifecycle</p>
            </div>
          </div>

          {/* Active Role Switcher */}
          <div className="flex items-center bg-slate-800/90 p-1 rounded-xl border border-slate-700 shadow-inner">
            <span className="text-xs text-slate-400 font-medium px-2.5 hidden md:inline">Simulate Role:</span>
            <div className="flex space-x-1">
              {roles.map((r) => {
                const Icon = r.icon;
                const isActive = currentRole === r.id;
                return (
                  <button
                    key={r.id}
                    onClick={() => {
                      setCurrentRole(r.id);
                      setActiveView('dashboard');
                    }}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                      isActive
                        ? 'bg-emerald-600 text-white shadow-sm font-semibold'
                        : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{r.label}</span>
                    {r.badge && (
                      <span className="ml-1 px-1.5 py-0.2 text-[10px] rounded-full bg-amber-400 text-slate-900 font-bold">
                        {r.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Navigation & Action Bar */}
        <div className="flex items-center justify-between py-2.5">
          <nav className="flex items-center space-x-1 sm:space-x-3 text-sm">
            <button
              onClick={() => setActiveView('dashboard')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg font-medium transition-colors ${
                activeView === 'dashboard'
                  ? 'bg-slate-800 text-emerald-400 font-semibold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <Home className="w-4 h-4" />
              <span>
                {currentRole === 'citizen'
                  ? 'Citizen Portal'
                  : currentRole === 'field_worker'
                  ? 'Field Assignments'
                  : 'Operations Center'}
              </span>
            </button>

            {currentRole === 'citizen' && (
              <>
                <button
                  onClick={() => setActiveView('track')}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg font-medium transition-colors ${
                    activeView === 'track'
                      ? 'bg-slate-800 text-emerald-400 font-semibold'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
                  }`}
                >
                  <Search className="w-4 h-4" />
                  <span>Track Complaint</span>
                </button>
              </>
            )}

            {currentRole === 'supervisor' && (
              <button
                onClick={() => setActiveView('analytics')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg font-medium transition-colors ${
                  activeView === 'analytics'
                    ? 'bg-emerald-600 text-white font-semibold shadow-xs'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                <SlidersHorizontal className="w-4 h-4" />
                <span>Command Center</span>
              </button>
            )}
          </nav>

          <div className="flex items-center gap-2">
            <button
              onClick={resetToDefaults}
              title="Reset sample complaints"
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 text-xs flex items-center gap-1 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline text-xs">Reset Demo</span>
            </button>

            {currentRole === 'citizen' && (
              <button
                onClick={() => setActiveView('report')}
                className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs sm:text-sm shadow-sm transition-all"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Report Issue</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
