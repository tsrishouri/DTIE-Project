import React, { useState, useMemo } from 'react';
import { useCivic } from '../context/CivicContext';
import { Complaint } from '../types';
import { StatusBadge, PriorityBadge, SlaBadge } from './StatusBadge';
import { WorkOrderDetailModal } from './WorkOrderDetailModal';
import { calculateSla } from '../utils/sla';
import {
  HardHat,
  MapPin,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Wrench,
  Camera,
  FileCheck,
  ChevronRight,
  User,
  Calendar,
  Send,
  Building2,
  Filter,
  ArrowRight,
  Layers,
  Sparkles,
} from 'lucide-react';

interface FieldWorkerDashboardProps {
  onSelectComplaint?: (complaint: Complaint) => void;
}

export const FieldWorkerDashboard: React.FC<FieldWorkerDashboardProps> = () => {
  const {
    complaints,
    fieldWorkers,
    selectedWorkerId,
    setSelectedWorkerId,
    selectedWorker,
    startWork,
  } = useCivic();

  const [activeTab, setActiveTab] = useState<'all' | 'assigned' | 'in_progress' | 'awaiting'>('all');
  const [selectedWorkOrder, setSelectedWorkOrder] = useState<Complaint | null>(null);

  // Current active worker name
  const currentWorker = selectedWorker || fieldWorkers[0];

  // Complaints assigned to THIS specific field worker (matched by assignedWorkerId or assignedWorker name)
  const workerComplaints = useMemo(() => {
    return complaints.filter((c) => {
      const matchesId = c.assignedWorkerId && c.assignedWorkerId === currentWorker.id;
      const matchesName =
        c.assignedWorker &&
        c.assignedWorker.toLowerCase().includes(currentWorker.name.toLowerCase());
      return matchesId || matchesName;
    });
  }, [complaints, currentWorker]);

  // 1. Dynamic summary statistics calculated strictly from the actual complaint data for this worker
  const stats = useMemo(() => {
    const assigned = workerComplaints.filter((c) => c.status === 'ASSIGNED').length;
    const inProgress = workerComplaints.filter((c) => c.status === 'IN PROGRESS').length;
    const submittedForVerification = workerComplaints.filter(
      (c) => c.status === 'AWAITING VERIFICATION' || c.status === 'RESOLUTION SUBMITTED'
    ).length;
    const slaDueSoon = workerComplaints.filter((c) => {
      if (c.status === 'VERIFIED / CLOSED') return false;
      const sla = calculateSla(c.deadline);
      return sla.status === 'DUE_SOON' || sla.status === 'BREACHED';
    }).length;

    return {
      assigned,
      inProgress,
      submittedForVerification,
      slaDueSoon,
    };
  }, [workerComplaints]);

  // Filter by status tab
  const filteredWorkQueue = useMemo(() => {
    switch (activeTab) {
      case 'assigned':
        return workerComplaints.filter((c) => c.status === 'ASSIGNED');
      case 'in_progress':
        return workerComplaints.filter((c) => c.status === 'IN PROGRESS');
      case 'awaiting':
        return workerComplaints.filter(
          (c) => c.status === 'AWAITING VERIFICATION' || c.status === 'RESOLUTION SUBMITTED'
        );
      default:
        return workerComplaints;
    }
  }, [workerComplaints, activeTab]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* 1. Header with Worker Identity Selector */}
      <div className="bg-[#0F1E36] text-white rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 border border-slate-800 shadow-md">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-semibold mb-2 border border-amber-500/30">
            <HardHat className="w-3.5 h-3.5" />
            <span>Field Operations Console</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Field Operations
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Manage assigned civic work orders and submit resolution evidence.
          </p>
        </div>

        {/* 2. Worker Identity Dropdown Selector */}
        <div className="bg-slate-800/90 border border-slate-700 rounded-xl p-3 flex flex-col sm:flex-row items-start sm:items-center gap-3 shadow-inner w-full md:w-auto">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs">
              {currentWorker.name
                .split(' ')
                .map((n) => n[0])
                .join('')}
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">
                Active Field Identity:
              </span>
              <span className="text-xs font-bold text-white">{currentWorker.name}</span>
            </div>
          </div>

          <div className="w-full sm:w-auto border-t sm:border-t-0 sm:border-l border-slate-700/80 pt-2 sm:pt-0 sm:pl-3">
            <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">
              Switch Worker (Demo):
            </label>
            <select
              value={selectedWorkerId}
              onChange={(e) => setSelectedWorkerId(e.target.value)}
              className="w-full sm:w-auto px-3 py-1.5 rounded-lg border border-slate-600 bg-slate-900 text-white text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-amber-500"
            >
              {fieldWorkers.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name} — {w.department}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* 1. Summary Cards (Calculated dynamically) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {/* Assigned */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-sky-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-sky-700 uppercase tracking-wider">
              Assigned
            </span>
            <div className="w-7 h-7 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-slate-900 mt-2">{stats.assigned}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Ready for work</div>
        </div>

        {/* In Progress */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-amber-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-700 uppercase tracking-wider">
              In Progress
            </span>
            <div className="w-7 h-7 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center">
              <Wrench className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-amber-950 mt-2">{stats.inProgress}</div>
          <div className="text-[11px] text-amber-600 mt-0.5 font-medium">Currently executing</div>
        </div>

        {/* Submitted for Verification */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-emerald-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider">
              Submitted for Verification
            </span>
            <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <FileCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-emerald-950 mt-2">
            {stats.submittedForVerification}
          </div>
          <div className="text-[11px] text-emerald-600 mt-0.5 font-medium">Proof submitted</div>
        </div>

        {/* SLA Due Soon */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-rose-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-rose-700 uppercase tracking-wider">
              SLA Due Soon
            </span>
            <div className="w-7 h-7 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-rose-950 mt-2">{stats.slaDueSoon}</div>
          <div className="text-[11px] text-rose-600 mt-0.5 font-medium">Under 6h or breached</div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="bg-white rounded-xl p-2 border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center space-x-1.5 overflow-x-auto">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'all'
                ? 'bg-slate-900 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            All Work Orders ({workerComplaints.length})
          </button>

          <button
            onClick={() => setActiveTab('assigned')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'assigned'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Assigned Queue ({stats.assigned})
          </button>

          <button
            onClick={() => setActiveTab('in_progress')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'in_progress'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            In Progress ({stats.inProgress})
          </button>

          <button
            onClick={() => setActiveTab('awaiting')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'awaiting'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Awaiting Verification ({stats.submittedForVerification})
          </button>
        </div>

        <div className="text-xs text-slate-500 font-medium px-2">
          Department: <strong className="text-slate-800">{currentWorker.department}</strong>
        </div>
      </div>

      {/* 3. Assigned Work Queue Cards */}
      <div className="space-y-4">
        {filteredWorkQueue.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center text-slate-500 space-y-3">
            <HardHat className="w-12 h-12 text-slate-400 mx-auto" />
            <h3 className="text-base font-bold text-slate-800">
              No work orders assigned to {currentWorker.name} in this view
            </h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              Switch worker using the selector above or assign tickets to this specialist from the Municipal Supervisor dashboard.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredWorkQueue.map((work) => {
              const isAssigned = work.status === 'ASSIGNED';
              const isInProgress = work.status === 'IN PROGRESS';

              return (
                <div
                  key={work.id}
                  className="bg-white rounded-2xl border border-slate-200 shadow-sm hover:border-amber-400 hover:shadow-md transition-all flex flex-col justify-between overflow-hidden"
                >
                  <div className="p-5 space-y-3">
                    {/* Top Meta */}
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-xs font-bold text-slate-900 bg-slate-100 px-2.5 py-1 rounded border border-slate-200">
                        {work.id}
                      </span>
                      <div className="flex items-center gap-1.5">
                        <PriorityBadge priority={work.priority} />
                        <StatusBadge status={work.status} size="sm" />
                      </div>
                    </div>

                    {/* Title & Category */}
                    <div>
                      <div className="flex items-center gap-2 text-[11px] text-slate-500 font-semibold mb-1">
                        <span className="uppercase text-amber-700">{work.category}</span>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          Assigned: {new Date(work.updatedAt).toLocaleDateString()}
                        </span>
                      </div>
                      <h3 className="font-bold text-slate-900 text-sm leading-snug line-clamp-2">
                        {work.title}
                      </h3>
                    </div>

                    {/* Location */}
                    <div className="flex items-center gap-1.5 text-xs text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                      <MapPin className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                      <span className="truncate font-medium">{work.location}</span>
                    </div>

                    {/* SLA Status */}
                    <div className="flex items-center justify-between pt-1">
                      <span className="text-[11px] text-slate-400 font-medium">SLA Deadline:</span>
                      <SlaBadge deadline={work.deadline} />
                    </div>

                    {/* Notes count indicator */}
                    {work.workNotes && work.workNotes.length > 0 && (
                      <div className="text-[11px] text-slate-500 font-medium">
                        📝 {work.workNotes.length} preliminary work note{work.workNotes.length > 1 ? 's' : ''} recorded
                      </div>
                    )}
                  </div>

                  {/* Actions Bar */}
                  <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between gap-2">
                    {isAssigned && (
                      <button
                        onClick={() => startWork(work.id, currentWorker.name)}
                        className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold shadow-sm flex items-center gap-1 transition-all"
                      >
                        <Wrench className="w-3.5 h-3.5" />
                        <span>START WORK</span>
                      </button>
                    )}

                    {isInProgress && (
                      <button
                        onClick={() => setSelectedWorkOrder(work)}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-sm flex items-center gap-1 transition-all"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Submit Proof</span>
                      </button>
                    )}

                    <button
                      onClick={() => setSelectedWorkOrder(work)}
                      className="ml-auto px-3.5 py-1.5 bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 font-semibold rounded-lg text-xs flex items-center gap-1 shadow-2xs transition-colors"
                    >
                      <span>View Work Order</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 4. Dedicated Work Order Details & Evidence Modal */}
      {selectedWorkOrder && (
        <WorkOrderDetailModal
          complaint={selectedWorkOrder}
          onClose={() => setSelectedWorkOrder(null)}
        />
      )}
    </div>
  );
};
