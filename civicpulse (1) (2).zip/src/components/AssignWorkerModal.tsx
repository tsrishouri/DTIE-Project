import React, { useState } from 'react';
import { Complaint, FieldWorker, MunicipalDepartment } from '../types';
import { useCivic } from '../context/CivicContext';
import {
  X,
  HardHat,
  UserCheck,
  CheckCircle2,
  Building2,
  Briefcase,
  Phone,
  AlertCircle,
  Filter,
} from 'lucide-react';

interface AssignWorkerModalProps {
  complaint: Complaint;
  onClose: () => void;
  onAssignComplete?: () => void;
}

export const AssignWorkerModal: React.FC<AssignWorkerModalProps> = ({
  complaint,
  onClose,
  onAssignComplete,
}) => {
  const { fieldWorkers, assignFieldWorker } = useCivic();

  const currentDept = (complaint.department || complaint.assignedDepartment || 'Road Maintenance') as MunicipalDepartment;
  const [selectedDeptFilter, setSelectedDeptFilter] = useState<MunicipalDepartment>(currentDept);
  const [selectedWorkerId, setSelectedWorkerId] = useState<string>('');
  const [customNote, setCustomNote] = useState<string>('');

  // Filter workers appropriate for the department
  const filteredWorkers = fieldWorkers.filter(
    (w) => w.department === selectedDeptFilter
  );

  const selectedWorker = fieldWorkers.find((w) => w.id === selectedWorkerId);

  const handleAssign = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedWorker) return;

    assignFieldWorker(
      complaint.id,
      selectedWorker,
      customNote.trim() ? `Complaint assigned to ${selectedWorker.name}. Notes: ${customNote.trim()}` : undefined
    );

    if (onAssignComplete) onAssignComplete();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden animate-in zoom-in-95">
        {/* Header */}
        <div className="bg-[#0F1E36] text-white px-6 py-5 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
              <HardHat className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs uppercase font-bold text-amber-400 tracking-wider">
                  Phase 2: Field Dispatch
                </span>
                <span className="font-mono text-xs bg-slate-800 text-emerald-400 px-2 py-0.5 rounded font-bold">
                  {complaint.id}
                </span>
              </div>
              <h2 className="text-lg font-bold text-white">Assign Field Worker</h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Complaint info banner */}
        <div className="bg-slate-50 border-b border-slate-200 px-6 py-3 text-xs text-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="truncate font-semibold text-slate-900">
            {complaint.title}
          </div>
          <div className="flex items-center gap-3 text-slate-500 shrink-0">
            <span>Department: <strong className="text-slate-800">{selectedDeptFilter}</strong></span>
            <span>Priority: <strong className="text-amber-700">{complaint.priority}</strong></span>
          </div>
        </div>

        <form onSubmit={handleAssign} className="p-6 space-y-5">
          {/* Department selector if supervisor needs to adjust */}
          <div className="flex items-center justify-between gap-3 text-xs">
            <label className="font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1">
              <Building2 className="w-3.5 h-3.5 text-blue-600" />
              <span>Matching Department:</span>
            </label>
            <select
              value={selectedDeptFilter}
              onChange={(e) => {
                setSelectedDeptFilter(e.target.value as MunicipalDepartment);
                setSelectedWorkerId('');
              }}
              className="px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs text-slate-800 bg-white font-medium"
            >
              <option value="Road Maintenance">Road Maintenance</option>
              <option value="Street Lighting">Street Lighting</option>
              <option value="Water Supply">Water Supply</option>
              <option value="Sanitation">Sanitation</option>
              <option value="Drainage">Drainage</option>
              <option value="Public Safety">Public Safety</option>
              <option value="General Services">General Services</option>
            </select>
          </div>

          {/* Workers list */}
          <div>
            <div className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center justify-between">
              <span>Select Active Field Specialist ({filteredWorkers.length} available)</span>
              <span className="text-[11px] text-slate-500 font-normal">Ranked by availability</span>
            </div>

            {filteredWorkers.length === 0 ? (
              <div className="p-6 border border-dashed border-slate-300 rounded-xl text-center text-xs text-slate-500 bg-slate-50">
                No active field technicians registered for {selectedDeptFilter}. Please choose another department.
              </div>
            ) : (
              <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                {filteredWorkers.map((worker) => {
                  const isSelected = selectedWorkerId === worker.id;
                  return (
                    <div
                      key={worker.id}
                      onClick={() => setSelectedWorkerId(worker.id)}
                      className={`p-3 rounded-xl border text-left cursor-pointer transition-all flex items-center justify-between ${
                        isSelected
                          ? 'border-emerald-600 bg-emerald-50/70 ring-2 ring-emerald-500 shadow-sm'
                          : 'border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50/50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs ${
                            isSelected
                              ? 'bg-emerald-600 text-white'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {worker.name
                            .split(' ')
                            .map((n) => n[0])
                            .join('')}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-900 text-xs sm:text-sm">
                              {worker.name}
                            </span>
                            <span className="inline-flex items-center gap-1 text-[10px] text-emerald-700 bg-emerald-100 px-1.5 py-0.2 rounded font-semibold">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                              Active
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500">
                            {worker.specialty || worker.department}
                          </p>
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="text-xs font-semibold text-slate-700 flex items-center gap-1 justify-end">
                          <Briefcase className="w-3.5 h-3.5 text-slate-400" />
                          <span>{worker.currentWorkload} active job{worker.currentWorkload !== 1 ? 's' : ''}</span>
                        </div>
                        {worker.phone && (
                          <div className="text-[10px] text-slate-400 mt-0.5">{worker.phone}</div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Optional dispatch note */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Work Order Instructions (Optional)
            </label>
            <input
              type="text"
              value={customNote}
              onChange={(e) => setCustomNote(e.target.value)}
              placeholder="e.g. Inspect school gate curb section first before paving."
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!selectedWorkerId}
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-semibold shadow-md transition-all flex items-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Confirm & Dispatch to {selectedWorker ? selectedWorker.name : 'Worker'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
