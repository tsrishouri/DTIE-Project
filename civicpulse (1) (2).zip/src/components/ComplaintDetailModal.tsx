import React, { useState } from 'react';
import { useCivic } from '../context/CivicContext';
import { Complaint, ComplaintStatus, PriorityLevel } from '../types';
import { StatusBadge, PriorityBadge, SlaBadge } from './StatusBadge';
import {
  X,
  MapPin,
  Calendar,
  User,
  Phone,
  Clock,
  Wrench,
  CheckCircle2,
  FileCheck,
  AlertCircle,
  RotateCcw,
  CheckCircle,
  Building2,
  HardHat,
  ShieldAlert,
  ClipboardCheck,
  Camera,
  UploadCloud,
  Layers,
  ArrowRight,
  ShieldCheck,
  AlertTriangle,
  Zap,
  Sparkles,
  Copy,
  Lock,
} from 'lucide-react';
import { TriageModal } from './TriageModal';
import { AssignWorkerModal } from './AssignWorkerModal';
import { calculateSla } from '../utils/sla';
import { getCategoryEvidence } from '../data/categoryEvidence';
import { extractWardName, extractZoneName, maskSensitiveContact } from '../utils/coordinates';

const WORKFLOW_STAGES = [
  { stage: 'REPORT', label: '1. Report', desc: 'Citizen registered' },
  { stage: 'TRIAGE', label: '2. Triage', desc: 'Priority & Dept set' },
  { stage: 'ASSIGN', label: '3. Assign', desc: 'Field crew assigned' },
  { stage: 'ACT', label: '4. Act', desc: 'Work in progress' },
  { stage: 'PROVE', label: '5. Prove', desc: 'Resolution proof' },
  { stage: 'VERIFY', label: '6. Verify', desc: 'Citizen verification' },
];

export const ComplaintDetailModal: React.FC<{
  complaint: Complaint;
  onClose: () => void;
}> = ({ complaint, onClose }) => {
  const {
    complaints,
    currentRole,
    verifyComplaint,
    reopenComplaint,
    startWork,
    submitResolution,
  } = useCivic();

  // Keep fresh complaint data if updated during modal view
  const activeComplaint = complaints.find((c) => c.id === complaint.id) || complaint;
  const categoryTemplate = getCategoryEvidence(activeComplaint.category);

  // Modals for Supervisor workflow
  const [showTriageModal, setShowTriageModal] = useState(false);
  const [showAssignModal, setShowAssignModal] = useState(false);

  // Verification states for citizen (Phase 4)
  const [citizenNotes, setCitizenNotes] = useState('');
  const [reopenReason, setReopenReason] = useState('');
  const [reopenEvidenceUrl, setReopenEvidenceUrl] = useState('');
  const [reopenError, setReopenError] = useState<string | null>(null);
  const [isReopening, setIsReopening] = useState(false);
  const [isConfirmingVerify, setIsConfirmingVerify] = useState(false);

  // Field worker resolution submission state (for field worker simulator)
  const [showResolveForm, setShowResolveForm] = useState(false);
  const [workerNotes, setWorkerNotes] = useState('');
  const [partsReplaced, setPartsReplaced] = useState('');

  // SLA computation
  const slaInfo = calculateSla(activeComplaint.deadline);

  // Determine stage progression for the 6-stage lifecycle
  const getStageStatus = (stageName: string) => {
    if (activeComplaint.status === 'REOPENED') {
      if (stageName === 'REPORT') return 'completed';
      if (stageName === 'TRIAGE') return 'current';
      return 'reopened';
    }

    const stageHierarchy: Record<ComplaintStatus, number> = {
      'REPORTED': 0,
      'TRIAGED': 1,
      'ASSIGNED': 2,
      'IN PROGRESS': 3,
      'RESOLUTION SUBMITTED': 4,
      'AWAITING VERIFICATION': 5,
      'VERIFIED': 5,
      'CLOSED': 6,
      'VERIFIED / CLOSED': 6,
      'REOPENED': 1,
    };

    const currentStageNum = stageHierarchy[activeComplaint.status] ?? 0;
    const stageIndexMap: Record<string, number> = {
      'REPORT': 0,
      'TRIAGE': 1,
      'ASSIGN': 2,
      'ACT': 3,
      'PROVE': 4,
      'VERIFY': 5,
    };

    const thisIndex = stageIndexMap[stageName];

    if (thisIndex < currentStageNum) return 'completed';
    if (thisIndex === currentStageNum || (thisIndex === 5 && currentStageNum >= 5)) return 'current';
    return 'pending';
  };

  const handleConfirmVerify = () => {
    verifyComplaint(activeComplaint.id, citizenNotes.trim() || undefined);
    setIsConfirmingVerify(false);
  };

  const handleConfirmReopen = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reopenReason.trim()) {
      setReopenError('Please provide a specific reason why the issue is not resolved.');
      return;
    }
    setReopenError(null);
    reopenComplaint(
      activeComplaint.id,
      reopenReason.trim(),
      reopenEvidenceUrl.trim() || undefined
    );
    setIsReopening(false);
  };

  const handleReopenFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setReopenEvidenceUrl(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleWorkerResolve = (e: React.FormEvent) => {
    e.preventDefault();
    if (!workerNotes.trim()) return;
    submitResolution(
      activeComplaint.id,
      activeComplaint.assignedWorker || 'Field Specialist',
      workerNotes,
      categoryTemplate.defaultAfterPhoto,
      activeComplaint.photoUrl || categoryTemplate.defaultBeforePhoto,
      partsReplaced.trim() || categoryTemplate.defaultMaterialsUsed
    );
    setShowResolveForm(false);
  };

  const isAwaitingVerification =
    activeComplaint.status === 'AWAITING VERIFICATION' ||
    activeComplaint.status === 'RESOLUTION SUBMITTED';

  const isClosed =
    activeComplaint.status === 'CLOSED' ||
    activeComplaint.status === 'VERIFIED / CLOSED';

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden animate-in zoom-in-95">
        {/* Header */}
        <div className="bg-[#0F1E36] text-white px-6 py-5 flex items-center justify-between border-b border-slate-800">
          <div className="flex flex-wrap items-center gap-3">
            <span className="font-mono text-sm font-bold bg-slate-800 px-3 py-1 rounded-lg border border-slate-700 text-emerald-400">
              {activeComplaint.id}
            </span>
            <StatusBadge status={activeComplaint.status} size="md" />
            <PriorityBadge priority={activeComplaint.priority} />
            <SlaBadge deadline={activeComplaint.deadline} />
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="overflow-y-auto p-6 space-y-6">
          {/* 1. CITIZEN VERIFICATION NOTICE BANNER (When Awaiting Verification) */}
          {isAwaitingVerification && (
            <div className="bg-gradient-to-r from-amber-500/15 via-orange-500/10 to-amber-500/20 border-2 border-amber-400 rounded-2xl p-4 sm:p-5 shadow-sm animate-pulse-subtle">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-md">
                    <AlertCircle className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-[11px] uppercase font-extrabold tracking-wider text-amber-900 block">
                      Civic Accountability Action
                    </span>
                    <h3 className="text-base sm:text-lg font-bold text-amber-950">
                      Resolution submitted — your verification is required.
                    </h3>
                    <p className="text-xs text-amber-900 mt-0.5 max-w-2xl">
                      Field specialist <strong className="text-amber-950">{activeComplaint.assignedWorker || 'Field Crew'}</strong> has submitted repair proof. Please inspect the original defect and the field worker resolution evidence below to verify closure or request a reopen.
                    </p>
                  </div>
                </div>

                {!isConfirmingVerify && !isReopening && (
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => {
                        setIsConfirmingVerify(true);
                        setIsReopening(false);
                      }}
                      className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-all flex items-center gap-1.5"
                    >
                      <CheckCircle className="w-4 h-4" />
                      <span>Verify Resolution</span>
                    </button>
                    <button
                      onClick={() => {
                        setIsReopening(true);
                        setIsConfirmingVerify(false);
                      }}
                      className="px-3.5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md transition-all flex items-center gap-1.5"
                    >
                      <RotateCcw className="w-4 h-4" />
                      <span>Issue Not Resolved</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Title & Metadata */}
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 font-medium mb-1">
              <span className="uppercase tracking-wider text-emerald-700 font-bold">
                {activeComplaint.category}
              </span>
              <span>•</span>
              <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-medium">
                {activeComplaint.ward || extractWardName(activeComplaint.location)} • {activeComplaint.zone || extractZoneName(activeComplaint.location)}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                {new Date(activeComplaint.createdAt).toLocaleString(undefined, {
                  month: 'short',
                  day: 'numeric',
                  year: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </span>
            </div>

            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 leading-snug">
              {activeComplaint.title}
            </h1>

            {/* SLA Escalation Banner */}
            {activeComplaint.isEscalated && (
              <div className="mt-2.5 p-3 rounded-xl bg-purple-50 border-2 border-purple-300 text-purple-950 flex items-center justify-between text-xs font-medium">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-purple-700 shrink-0" />
                  <span>
                    <strong>Emergency SLA Escalation:</strong> {activeComplaint.escalatedReason || 'Expedited to emergency resolution queue by supervisor.'}
                  </span>
                </div>
                {activeComplaint.escalatedAt && (
                  <span className="text-[11px] text-purple-700 font-mono shrink-0">
                    {new Date(activeComplaint.escalatedAt).toLocaleTimeString()}
                  </span>
                )}
              </div>
            )}

            {/* Potential Duplicate Banner */}
            {activeComplaint.potentialDuplicate?.isDuplicate && (
              <div className="mt-2.5 p-3 rounded-xl bg-amber-50 border border-amber-300 text-amber-950 flex items-center gap-2 text-xs">
                <Copy className="w-4 h-4 text-amber-700 shrink-0" />
                <span>
                  <strong>Potential Duplicate of {activeComplaint.potentialDuplicate.matchedComplaintId}:</strong> {activeComplaint.potentialDuplicate.similarity}% match ({activeComplaint.potentialDuplicate.reason})
                </span>
              </div>
            )}

            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600 mt-2.5">
              <span className="flex items-center gap-1.5 font-medium text-slate-700">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                <span>{activeComplaint.location}</span>
              </span>

              {/* GPS Timestamp if captured */}
              {activeComplaint.coordinates && (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 font-semibold text-[11px]">
                  <MapPin className="w-3 h-3 text-emerald-600" />
                  <span>GPS: {activeComplaint.coordinates.lat}° N, {activeComplaint.coordinates.lng}° W</span>
                  {activeComplaint.coordinates.capturedAt && (
                    <span className="text-emerald-700 font-normal">
                      • {new Date(activeComplaint.coordinates.capturedAt).toLocaleTimeString()}
                    </span>
                  )}
                </span>
              )}

              <span className="flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-slate-400" />
                <span>
                  Citizen Reporter:{' '}
                  <strong className="text-slate-800">{activeComplaint.citizenName}</strong>
                </span>
              </span>

              {activeComplaint.citizenPhone && (
                <span className="flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  <span>
                    {maskSensitiveContact(
                      activeComplaint.citizenPhone,
                      activeComplaint.isContactMasked && currentRole === 'citizen'
                    )}
                  </span>
                  {activeComplaint.isContactMasked && currentRole === 'citizen' && (
                    <span className="text-[10px] text-emerald-700 flex items-center gap-0.5" title="Privacy Guard Active">
                      <Lock className="w-2.5 h-2.5" /> Masked
                    </span>
                  )}
                </span>
              )}
            </div>
          </div>

          {/* Visual Lifecycle Stepper: REPORT → TRIAGE → ASSIGN → ACT → PROVE → VERIFY */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 sm:p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <span>CivicPulse Resolution Pathway</span>
                <span className="text-[11px] text-slate-400 font-normal">
                  (REPORT → TRIAGE → ASSIGN → ACT → PROVE → VERIFY)
                </span>
              </div>
              {activeComplaint.status === 'REOPENED' && (
                <span className="text-xs bg-rose-100 text-rose-800 px-2 py-0.5 rounded font-bold border border-rose-300">
                  REOPENED BY CITIZEN
                </span>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-6 gap-2">
              {WORKFLOW_STAGES.map((step) => {
                const stepState = getStageStatus(step.stage);
                const isCurrent = stepState === 'current';
                const isCompleted = stepState === 'completed';
                const isReopenedStep = stepState === 'reopened';

                return (
                  <div
                    key={step.stage}
                    className={`p-2.5 rounded-xl border text-center transition-all ${
                      isCompleted
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                        : isCurrent
                        ? 'bg-blue-50 border-blue-500 text-blue-950 ring-2 ring-blue-500 font-bold shadow-sm'
                        : isReopenedStep
                        ? 'bg-rose-50/50 border-rose-200 text-rose-800/80'
                        : 'bg-white border-slate-200 text-slate-400'
                    }`}
                  >
                    <div className="flex items-center justify-center mb-1">
                      {isCompleted ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      ) : isCurrent ? (
                        <div className="w-2.5 h-2.5 rounded-full bg-blue-600 animate-ping" />
                      ) : isReopenedStep ? (
                        <RotateCcw className="w-3.5 h-3.5 text-rose-500" />
                      ) : (
                        <div className="w-2 h-2 rounded-full bg-slate-300" />
                      )}
                    </div>
                    <div className="text-xs font-bold leading-tight">{step.label}</div>
                    <div className="text-[10px] text-slate-500 mt-0.5">{step.desc}</div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Supervisor Action Bar */}
          {currentRole === 'supervisor' && (
            <div className="bg-slate-900 text-white rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md">
              <div>
                <span className="text-[11px] uppercase font-bold text-blue-400 tracking-wider">
                  Supervisor Action Center
                </span>
                <p className="text-xs text-slate-300 mt-0.5">
                  {activeComplaint.status === 'REPORTED'
                    ? 'Complaint is newly reported. Complete triage to assign department, priority, and SLA.'
                    : activeComplaint.status === 'TRIAGED'
                    ? 'Complaint is triaged. Assign an active field specialist to begin work.'
                    : activeComplaint.status === 'REOPENED'
                    ? 'Citizen rejected previous resolution. Review reason and re-triage or reassign crew.'
                    : activeComplaint.status === 'ASSIGNED'
                    ? `Dispatched to ${activeComplaint.assignedWorker}. Field crew will mark in progress.`
                    : 'Complaint is actively in field execution or verification.'}
                </p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {activeComplaint.status === 'REPORTED' && (
                  <button
                    onClick={() => setShowTriageModal(true)}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold shadow-md flex items-center gap-1.5 transition-all"
                  >
                    <ClipboardCheck className="w-4 h-4" />
                    <span>TRIAGE COMPLAINT</span>
                  </button>
                )}

                {activeComplaint.status === 'TRIAGED' && (
                  <button
                    onClick={() => setShowAssignModal(true)}
                    className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-bold shadow-md flex items-center gap-1.5 transition-all"
                  >
                    <HardHat className="w-4 h-4" />
                    <span>ASSIGN FIELD WORKER</span>
                  </button>
                )}

                {activeComplaint.status === 'REOPENED' && (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setShowTriageModal(true)}
                      className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold shadow-md flex items-center gap-1.5"
                    >
                      <ClipboardCheck className="w-3.5 h-3.5" />
                      <span>Re-triage</span>
                    </button>
                    <button
                      onClick={() => setShowAssignModal(true)}
                      className="px-3.5 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-bold shadow-md flex items-center gap-1.5"
                    >
                      <HardHat className="w-3.5 h-3.5" />
                      <span>Reassign</span>
                    </button>
                  </div>
                )}

                {activeComplaint.status !== 'REPORTED' &&
                  activeComplaint.status !== 'TRIAGED' &&
                  activeComplaint.status !== 'REOPENED' && (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setShowTriageModal(true)}
                        className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold"
                      >
                        Re-triage
                      </button>
                      <button
                        onClick={() => setShowAssignModal(true)}
                        className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold"
                      >
                        Reassign
                      </button>
                    </div>
                  )}
              </div>
            </div>
          )}

          {/* 6 & 12. REOPENED COMPLAINT VIEW (Citizen Rejected Resolution) */}
          {activeComplaint.status === 'REOPENED' && (
            <div className="bg-rose-50 border-2 border-rose-300 rounded-2xl p-5 text-rose-950 space-y-3 shadow-sm">
              <div className="flex items-start justify-between gap-3 border-b border-rose-200 pb-3">
                <div className="flex items-center gap-2.5">
                  <span className="px-2.5 py-0.5 rounded-full bg-rose-600 text-white font-bold text-xs uppercase tracking-wider">
                    REOPENED
                  </span>
                  <h4 className="text-sm sm:text-base font-bold text-rose-950">
                    Citizen rejected the previous resolution.
                  </h4>
                </div>
                {activeComplaint.reopenedAt && (
                  <span className="text-xs text-rose-700 font-medium shrink-0">
                    Reopened {new Date(activeComplaint.reopenedAt).toLocaleString()}
                  </span>
                )}
              </div>

              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-rose-800 block mb-1">
                  Citizen Stated Reason:
                </span>
                <p className="text-xs sm:text-sm text-rose-950 bg-white/90 p-3.5 rounded-xl border border-rose-200 font-medium leading-relaxed shadow-2xs">
                  "{activeComplaint.reopenReason || 'The reported issue was not satisfactorily rectified.'}"
                </p>
              </div>

              {activeComplaint.reopenEvidenceUrl && (
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-rose-800 block mb-1">
                    Citizen Evidence Submitted at Reopen:
                  </span>
                  <div className="h-36 w-48 rounded-lg overflow-hidden border border-rose-300 bg-white">
                    <img
                      src={activeComplaint.reopenEvidenceUrl}
                      alt="Reopen evidence"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
              )}

              <div className="bg-rose-100/70 p-3 rounded-xl border border-rose-200 text-xs text-rose-900 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>
                    Municipal action is required again. Ticket is now pending Supervisor re-triage or re-dispatch.
                  </span>
                </div>
                {currentRole === 'supervisor' && (
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => setShowTriageModal(true)}
                      className="px-3 py-1 bg-white hover:bg-slate-100 text-rose-800 border border-rose-300 rounded-lg text-xs font-bold"
                    >
                      Re-triage
                    </button>
                    <button
                      onClick={() => setShowAssignModal(true)}
                      className="px-3 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold shadow-sm"
                    >
                      Reassign
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 11. CLOSED COMPLAINT VIEW (Professional Completion State) */}
          {isClosed && (
            <div className="bg-gradient-to-r from-emerald-50 via-teal-50/60 to-emerald-50 border-2 border-emerald-400 rounded-2xl p-6 text-emerald-950 space-y-4 shadow-sm">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-emerald-200 pb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-md">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-[11px] uppercase font-extrabold tracking-wider text-emerald-800">
                      Civic Accountability Loop Complete
                    </span>
                    <h3 className="text-base sm:text-lg font-bold text-emerald-950">
                      Complaint Closed — Citizen Verified
                    </h3>
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold">
                    <CheckCircle className="w-3.5 h-3.5" />
                    <span>✓ Complaint Resolved</span>
                  </span>
                  <span className="inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-full bg-teal-100 text-teal-800 border border-teal-300 font-bold">
                    <CheckCircle className="w-3.5 h-3.5" />
                    <span>✓ Citizen Verified</span>
                  </span>
                  <span className="inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-full bg-blue-100 text-blue-800 border border-blue-300 font-bold">
                    <CheckCircle className="w-3.5 h-3.5" />
                    <span>✓ Resolution Completed</span>
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="bg-white/80 p-3.5 rounded-xl border border-emerald-200">
                  <span className="font-bold text-emerald-900 block mb-1">Verification Details:</span>
                  <div className="space-y-1 text-slate-700">
                    <div>
                      Verified by: <strong className="text-slate-900">{activeComplaint.verifiedBy || activeComplaint.citizenName || 'Citizen'}</strong>
                    </div>
                    <div>
                      Verified at:{' '}
                      <strong className="text-slate-900">
                        {activeComplaint.verifiedAt
                          ? new Date(activeComplaint.verifiedAt).toLocaleString()
                          : activeComplaint.closedAt
                          ? new Date(activeComplaint.closedAt).toLocaleString()
                          : new Date(activeComplaint.updatedAt).toLocaleString()}
                      </strong>
                    </div>
                  </div>
                </div>

                <div className="bg-white/80 p-3.5 rounded-xl border border-emerald-200">
                  <span className="font-bold text-emerald-900 block mb-1">Citizen Feedback:</span>
                  <p className="text-slate-800 italic">
                    "{activeComplaint.citizenVerificationNote || 'Citizen verified that the reported issue was resolved on-site.'}"
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* 2. DEDICATED VERIFICATION PANEL (When Awaiting Verification) */}
          {isAwaitingVerification && (
            <div className="bg-white border-2 border-emerald-500 rounded-2xl p-6 shadow-md space-y-5">
              <div className="border-b border-slate-200 pb-3">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-600" />
                  <h3 className="text-base font-bold text-slate-900">Verify Resolution</h3>
                </div>
                <p className="text-xs text-slate-600 mt-1">
                  Has this civic issue been properly resolved?
                </p>
              </div>

              {/* Primary verification buttons */}
              {!isConfirmingVerify && !isReopening && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                  <button
                    onClick={() => setIsConfirmingVerify(true)}
                    className="p-4 rounded-xl border-2 border-emerald-500 bg-emerald-50/70 hover:bg-emerald-100 text-emerald-950 font-bold text-sm text-left transition-all flex items-center justify-between group shadow-sm hover:scale-[1.01]"
                  >
                    <div>
                      <div className="flex items-center gap-2 text-emerald-700 font-extrabold">
                        <CheckCircle className="w-5 h-5 text-emerald-600" />
                        <span>✓ Resolution Verified</span>
                      </div>
                      <p className="text-xs text-emerald-900/80 font-normal mt-1">
                        Confirm that the problem is completely fixed on-site and close the complaint.
                      </p>
                    </div>
                    <ArrowRight className="w-5 h-5 text-emerald-600 shrink-0 group-hover:translate-x-1 transition-transform" />
                  </button>

                  <button
                    onClick={() => setIsReopening(true)}
                    className="p-4 rounded-xl border-2 border-rose-300 bg-rose-50/60 hover:bg-rose-100 text-rose-950 font-bold text-sm text-left transition-all flex items-center justify-between group shadow-sm hover:scale-[1.01]"
                  >
                    <div>
                      <div className="flex items-center gap-2 text-rose-700 font-extrabold">
                        <RotateCcw className="w-5 h-5 text-rose-600" />
                        <span>✕ Issue Not Resolved</span>
                      </div>
                      <p className="text-xs text-rose-900/80 font-normal mt-1">
                        Report that the defect remains. Reopen ticket and route back to Supervisor.
                      </p>
                    </div>
                    <ArrowRight className="w-5 h-5 text-rose-600 shrink-0 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              )}

              {/* Confirmation Step: Verify & Close */}
              {isConfirmingVerify && (
                <div className="bg-emerald-50/70 border border-emerald-300 rounded-xl p-5 space-y-4 animate-in fade-in">
                  <div>
                    <h4 className="text-sm font-bold text-emerald-950">
                      Are you sure this issue has been resolved?
                    </h4>
                    <p className="text-xs text-emerald-800 mt-0.5">
                      Confirming will formally close this ticket in the municipal registry and record your verification.
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Citizen Verification Note (Optional):
                    </label>
                    <textarea
                      rows={2}
                      value={citizenNotes}
                      onChange={(e) => setCitizenNotes(e.target.value)}
                      placeholder="e.g. Inspected on-site this morning. Work is satisfactory, thank you."
                      className="w-full p-2.5 border border-slate-300 rounded-lg text-xs text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <div className="flex items-center justify-end gap-3 pt-1">
                    <button
                      type="button"
                      onClick={() => setIsConfirmingVerify(false)}
                      className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleConfirmVerify}
                      className="px-5 py-2.5 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl shadow-md transition-all flex items-center gap-1.5"
                    >
                      <CheckCircle className="w-4 h-4" />
                      <span>Yes, Confirm Resolution & Close Issue</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Reopen Form Step: Issue Not Resolved */}
              {isReopening && (
                <form onSubmit={handleConfirmReopen} className="bg-rose-50/70 border border-rose-300 rounded-xl p-5 space-y-4 animate-in fade-in">
                  <div>
                    <h4 className="text-sm font-bold text-rose-950">
                      Issue Not Resolved — Request Reopening
                    </h4>
                    <p className="text-xs text-rose-800 mt-0.5">
                      Please explain why the civic defect persists so the Municipal Supervisor can re-triage and re-dispatch field specialists.
                    </p>
                  </div>

                  {reopenError && (
                    <div className="p-3 rounded-lg bg-rose-100 border border-rose-300 text-rose-800 text-xs font-medium">
                      {reopenError}
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1">
                      Reason for Reopening (Required) <span className="text-rose-600">*</span>
                    </label>
                    <textarea
                      rows={3}
                      value={reopenReason}
                      onChange={(e) => setReopenReason(e.target.value)}
                      placeholder="e.g. The street light is still not working."
                      className="w-full p-2.5 border border-rose-300 rounded-lg text-xs text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-rose-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Additional Evidence Photo (Optional):
                    </label>
                    <div className="flex items-center gap-3">
                      <label className="cursor-pointer px-3 py-2 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-lg flex items-center gap-1.5 shadow-2xs">
                        <UploadCloud className="w-3.5 h-3.5" />
                        <span>Upload photo</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={handleReopenFileUpload}
                        />
                      </label>
                      {reopenEvidenceUrl && (
                        <span className="text-xs text-emerald-700 font-medium flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Photo attached</span>
                        </span>
                      )}
                    </div>
                    {reopenEvidenceUrl && (
                      <div className="mt-2 h-24 w-36 rounded-lg overflow-hidden border border-slate-300">
                        <img src={reopenEvidenceUrl} alt="Reopen proof" className="w-full h-full object-cover" />
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-end gap-3 pt-1">
                    <button
                      type="button"
                      onClick={() => setIsReopening(false)}
                      className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={!reopenReason.trim()}
                      className="px-5 py-2.5 text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white rounded-xl shadow-md transition-all flex items-center gap-1.5 disabled:opacity-50"
                    >
                      <RotateCcw className="w-4 h-4" />
                      <span>Submit Reopen Request</span>
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* VISUAL SEPARATION: 1. CITIZEN REPORT (Initial Issue) */}
          <div className="border border-slate-200 rounded-2xl p-5 bg-white space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900">
                  CITIZEN REPORT (INITIAL CIVIC ISSUE)
                </h3>
              </div>
              <span className="text-xs text-slate-500 font-medium">
                Reported {new Date(activeComplaint.createdAt).toLocaleDateString()}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Problem Description:
                  </h4>
                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-xs sm:text-sm text-slate-800 leading-relaxed">
                    {activeComplaint.description}
                  </div>
                </div>

                {/* Department & SLA Card */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-xs space-y-2">
                  <div className="font-bold text-slate-800 uppercase tracking-wider text-[11px] border-b border-slate-200 pb-1.5 flex items-center justify-between">
                    <span>Municipal Assignment</span>
                    <SlaBadge deadline={activeComplaint.deadline} />
                  </div>
                  <div className="flex justify-between py-0.5 border-b border-slate-200/60">
                    <span className="text-slate-500">Department:</span>
                    <span className="font-semibold text-slate-900">
                      {activeComplaint.department || activeComplaint.assignedDepartment || 'Pending Triage'}
                    </span>
                  </div>
                  <div className="flex justify-between py-0.5 border-b border-slate-200/60">
                    <span className="text-slate-500">Assigned Specialist:</span>
                    <span className="font-semibold text-slate-900">
                      {activeComplaint.assignedWorker || 'Pending Assignment'}
                    </span>
                  </div>
                  <div className="flex justify-between py-0.5 border-b border-slate-200/60">
                    <span className="text-slate-500">Target SLA:</span>
                    <span className="font-semibold text-slate-900">
                      {activeComplaint.deadline
                        ? new Date(activeComplaint.deadline).toLocaleString()
                        : 'Pending Triage'}
                    </span>
                  </div>
                  {activeComplaint.triageNotes && (
                    <div className="pt-1">
                      <span className="text-slate-500 block mb-0.5">Triage Notes:</span>
                      <span className="italic text-slate-700 bg-white p-2 rounded border border-slate-200 block text-[11px]">
                        "{activeComplaint.triageNotes}"
                      </span>
                    </div>
                  )}
                </div>

                {/* 9. Human Review of AI Decisions & Triage Assessment */}
                {activeComplaint.aiTriage && (
                  <div className="bg-gradient-to-r from-blue-50/70 to-indigo-50/60 border border-blue-200 rounded-xl p-3.5 text-xs space-y-2">
                    <div className="flex items-center justify-between border-b border-blue-200 pb-1.5">
                      <div className="flex items-center gap-1.5 font-bold text-blue-900 text-[11px] uppercase tracking-wider">
                        <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                        <span>AI Triage Analysis & Human Review</span>
                      </div>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        activeComplaint.aiTriage.acceptedBySupervisor
                          ? 'bg-emerald-100 text-emerald-800'
                          : activeComplaint.aiTriage.supervisorOverridden
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}>
                        {activeComplaint.aiTriage.acceptedBySupervisor
                          ? '✓ Supervisor Confirmed'
                          : activeComplaint.aiTriage.supervisorOverridden
                          ? '⚠️ Supervisor Overridden'
                          : 'Pending Review'}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-[11px]">
                      <div>
                        <span className="text-slate-500 block text-[10px]">AI Category:</span>
                        <strong className="text-slate-900">{activeComplaint.aiTriage.suggestedCategory}</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[10px]">AI Severity:</span>
                        <strong className={activeComplaint.aiTriage.suggestedPriority === 'CRITICAL' ? 'text-rose-600' : 'text-blue-900'}>
                          {activeComplaint.aiTriage.suggestedPriority}
                        </strong>
                      </div>
                    </div>
                    <p className="text-[11px] text-slate-600 italic bg-white/70 p-2 rounded border border-blue-100">
                      "{activeComplaint.aiTriage.reasoning}"
                    </p>
                    <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1">
                      <span>Confidence: {Math.round(activeComplaint.aiTriage.confidence * 100)}%</span>
                      <span className="italic">{activeComplaint.aiTriage.model}</span>
                    </div>
                  </div>
                )}
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                    CITIZEN EVIDENCE (ORIGINAL PHOTO)
                  </h4>
                  <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-semibold">
                    At report time
                  </span>
                </div>
                {activeComplaint.photoUrl ? (
                  <div className="rounded-xl overflow-hidden border border-slate-200 h-56 bg-slate-100 shadow-inner">
                    <img
                      src={activeComplaint.photoUrl}
                      alt={activeComplaint.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                ) : (
                  <div className="rounded-xl border border-dashed border-slate-300 h-56 flex flex-col items-center justify-center text-slate-400 bg-slate-50 text-xs">
                    <span>No initial photo attached</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* VISUAL SEPARATION: 2. FIELD WORKER RESOLUTION (Proof of Work) */}
          {(activeComplaint.evidence ||
            isAwaitingVerification ||
            isClosed ||
            activeComplaint.status === 'REOPENED') && (
            <div className="border-2 border-emerald-300 rounded-2xl p-5 bg-emerald-50/40 space-y-4">
              <div className="flex items-center justify-between border-b border-emerald-200/80 pb-3">
                <div className="flex items-center gap-2">
                  <FileCheck className="w-5 h-5 text-emerald-700" />
                  <h3 className="text-sm font-bold uppercase tracking-wider text-emerald-950">
                    FIELD WORKER RESOLUTION (REPAIR WORK & EVIDENCE)
                  </h3>
                </div>
                {activeComplaint.evidence?.submittedAt && (
                  <span className="text-xs text-emerald-800 font-medium">
                    Submitted {new Date(activeComplaint.evidence.submittedAt).toLocaleString()} by{' '}
                    <strong>{activeComplaint.evidence.submittedBy}</strong>
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <div>
                    <h4 className="text-xs font-bold text-emerald-900 mb-1">Resolution Summary:</h4>
                    <p className="text-xs sm:text-sm text-emerald-950 bg-white p-3.5 rounded-xl border border-emerald-200 leading-relaxed shadow-2xs">
                      {activeComplaint.category === 'Street Lights' &&
                      activeComplaint.evidence?.resolutionDescription?.toLowerCase().includes('road')
                        ? categoryTemplate.defaultResolutionDescription
                        : activeComplaint.evidence?.resolutionDescription ||
                          activeComplaint.evidence?.workerNotes ||
                          activeComplaint.resolutionDescription ||
                          categoryTemplate.defaultResolutionDescription}
                    </p>
                  </div>

                  <div className="bg-white p-3 rounded-xl border border-emerald-200 text-xs text-emerald-900 space-y-1">
                    <div>
                      <strong>Materials / Parts Consumed:</strong>{' '}
                      {activeComplaint.category === 'Street Lights' &&
                      activeComplaint.evidence?.partsReplaced?.toLowerCase().includes('road')
                        ? categoryTemplate.defaultMaterialsUsed
                        : activeComplaint.evidence?.partsReplaced || categoryTemplate.defaultMaterialsUsed}
                    </div>
                    <div>
                      <strong>Field Specialist:</strong>{' '}
                      {activeComplaint.evidence?.submittedBy || activeComplaint.assignedWorker || 'Field Crew'} (
                      {activeComplaint.department || activeComplaint.assignedDepartment || 'Operations'})
                    </div>
                  </div>

                  {activeComplaint.workNotes && activeComplaint.workNotes.length > 0 && (
                    <div>
                      <span className="text-[11px] font-bold text-emerald-950 block mb-1">
                        Field Observations ({activeComplaint.workNotes.length}):
                      </span>
                      <div className="space-y-1.5 max-h-36 overflow-y-auto">
                        {activeComplaint.workNotes.map((wn) => (
                          <div key={wn.id} className="text-[11px] bg-white p-2.5 rounded-lg border border-emerald-100">
                            <span className="font-semibold text-slate-800">{wn.workerName}:</span> {wn.note}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div>
                  <h4 className="text-xs font-bold text-emerald-900 uppercase tracking-wider mb-2">
                    Visual Evidence Comparison (Before vs. After):
                  </h4>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-600 block mb-1">
                        BEFORE WORK EVIDENCE
                      </span>
                      <div className="rounded-xl overflow-hidden border border-slate-300 h-44 bg-slate-100 shadow-2xs">
                        <img
                          src={
                            activeComplaint.category === 'Street Lights' &&
                            activeComplaint.evidence?.beforePhotoUrl?.includes('1515162816999')
                              ? categoryTemplate.defaultBeforePhoto
                              : activeComplaint.evidence?.beforePhotoUrl ||
                                activeComplaint.photoUrl ||
                                categoryTemplate.defaultBeforePhoto
                          }
                          alt="Before work"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </div>

                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800 block mb-1">
                        AFTER WORK EVIDENCE
                      </span>
                      <div className="rounded-xl overflow-hidden border-2 border-emerald-400 h-44 bg-emerald-100 shadow-2xs">
                        <img
                          src={
                            activeComplaint.category === 'Street Lights' &&
                            (activeComplaint.evidence?.afterPhotoUrl?.includes('1581092160607') ||
                              activeComplaint.evidence?.afterPhotoUrl?.includes('1581092335397') ||
                              activeComplaint.evidence?.afterPhotoUrl?.includes('1518241353330'))
                              ? categoryTemplate.defaultAfterPhoto
                              : activeComplaint.evidence?.afterPhotoUrl ||
                                activeComplaint.evidence?.photoUrl ||
                                categoryTemplate.defaultAfterPhoto
                          }
                          alt="After work resolution"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Field Worker Quick Action Controls (when simulating field worker role) */}
          {currentRole === 'field_worker' && (
            <div className="bg-slate-800 text-white p-4 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Wrench className="w-4 h-4" /> Field Worker Controls
                </span>
                <span className="text-xs text-slate-300">
                  Assigned Specialist: {activeComplaint.assignedWorker || 'Pending'}
                </span>
              </div>

              {activeComplaint.status === 'ASSIGNED' && (
                <button
                  onClick={() =>
                    startWork(activeComplaint.id, activeComplaint.assignedWorker || 'Field Specialist')
                  }
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-semibold"
                >
                  Mark Work as "IN PROGRESS"
                </button>
              )}

              {(activeComplaint.status === 'IN PROGRESS' ||
                activeComplaint.status === 'ASSIGNED') &&
                !showResolveForm && (
                  <button
                    onClick={() => setShowResolveForm(true)}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold"
                  >
                    Submit Resolution Evidence
                  </button>
                )}

              {showResolveForm && (
                <form
                  onSubmit={handleWorkerResolve}
                  className="bg-slate-900 p-4 rounded-lg space-y-3 text-xs"
                >
                  <h4 className="font-bold text-white">Submit Work Completion Report:</h4>
                  <div>
                    <label className="block text-slate-300 mb-1">Work Done Notes:</label>
                    <textarea
                      rows={2}
                      value={workerNotes}
                      onChange={(e) => setWorkerNotes(e.target.value)}
                      placeholder="Detailed repair description..."
                      className="w-full p-2 bg-slate-800 border border-slate-700 rounded text-white"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-slate-300 mb-1">Parts Replaced:</label>
                    <input
                      type="text"
                      value={partsReplaced}
                      onChange={(e) => setPartsReplaced(e.target.value)}
                      placeholder="e.g. 50kg asphalt patch, valve seal"
                      className="w-full p-2 bg-slate-800 border border-slate-700 rounded text-white"
                    />
                  </div>
                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setShowResolveForm(false)}
                      className="px-3 py-1 bg-slate-800 text-slate-300 rounded"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded"
                    >
                      Submit for Citizen Verification
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* Full Audit Log / Traceability History */}
          <div>
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">
              Full Traceability Audit Trail ({activeComplaint.timeline.length} events)
            </h3>
            <div className="relative pl-6 border-l-2 border-slate-200 space-y-4">
              {activeComplaint.timeline.map((entry) => (
                <div key={entry.id} className="relative group">
                  <div
                    className={`absolute -left-[31px] top-1.5 w-3.5 h-3.5 rounded-full border-2 border-white ring-2 ${
                      entry.status === 'VERIFIED'
                        ? 'bg-teal-600 ring-teal-200'
                        : entry.status === 'CLOSED'
                        ? 'bg-emerald-600 ring-emerald-200'
                        : entry.status === 'REOPENED'
                        ? 'bg-rose-600 ring-rose-200'
                        : entry.status === 'IN PROGRESS'
                        ? 'bg-amber-600 ring-amber-200'
                        : 'bg-blue-600 ring-blue-200'
                    }`}
                  />
                  <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-xs">
                    <div className="flex items-center justify-between text-slate-500 mb-1">
                      <span className="font-semibold text-slate-800">
                        {entry.actor} ({String(entry.actorRole).toUpperCase()})
                      </span>
                      <span>
                        {new Date(entry.timestamp).toLocaleString(undefined, {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-mono text-[11px] text-blue-700 font-bold">
                        Status: {entry.status}
                      </span>
                      {entry.status === 'CLOSED' && (
                        <span className="text-[10px] bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded font-bold">
                          ✓ FINAL CLOSED
                        </span>
                      )}
                      {entry.status === 'REOPENED' && (
                        <span className="text-[10px] bg-rose-100 text-rose-800 px-1.5 py-0.2 rounded font-bold">
                          ↺ REOPENED
                        </span>
                      )}
                    </div>
                    {entry.comment && <p className="text-slate-700">{entry.comment}</p>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-semibold transition-colors"
          >
            Close Window
          </button>
        </div>
      </div>

      {/* Triage Modal */}
      {showTriageModal && (
        <TriageModal
          complaint={activeComplaint}
          onClose={() => setShowTriageModal(false)}
          onTriageComplete={() => {
            setShowAssignModal(true);
          }}
        />
      )}

      {/* Assign Modal */}
      {showAssignModal && (
        <AssignWorkerModal
          complaint={activeComplaint}
          onClose={() => setShowAssignModal(false)}
        />
      )}
    </div>
  );
};
