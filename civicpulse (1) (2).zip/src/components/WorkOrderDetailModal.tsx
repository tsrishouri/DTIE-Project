import React, { useState } from 'react';
import { useCivic } from '../context/CivicContext';
import { Complaint, ComplaintStatus } from '../types';
import { StatusBadge, PriorityBadge, SlaBadge } from './StatusBadge';
import { calculateSla } from '../utils/sla';
import {
  X,
  MapPin,
  Calendar,
  User,
  Phone,
  Clock,
  Wrench,
  CheckCircle2,
  FileCheck,
  Camera,
  UploadCloud,
  FileText,
  AlertTriangle,
  Send,
  Building2,
  CheckCircle,
  HardHat,
  ChevronRight,
  ShieldCheck,
  Plus,
} from 'lucide-react';

import { getCategoryEvidence } from '../data/categoryEvidence';

const WORKFLOW_STAGES = [
  { stage: 'REPORT', label: '1. Report', desc: 'Citizen registered' },
  { stage: 'TRIAGE', label: '2. Triage', desc: 'Priority & Dept set' },
  { stage: 'ASSIGN', label: '3. Assign', desc: 'Field crew assigned' },
  { stage: 'ACT', label: '4. Act', desc: 'Work in progress' },
  { stage: 'PROVE', label: '5. Prove', desc: 'Resolution proof' },
  { stage: 'VERIFY', label: '6. Verify', desc: 'Citizen verification' },
];

export const WorkOrderDetailModal: React.FC<{
  complaint: Complaint;
  onClose: () => void;
}> = ({ complaint, onClose }) => {
  const {
    complaints,
    selectedWorker,
    startWork,
    addWorkNote,
    submitResolution,
  } = useCivic();

  // Keep fresh complaint data
  const activeComplaint = complaints.find((c) => c.id === complaint.id) || complaint;
  const template = getCategoryEvidence(activeComplaint.category);

  // Worker name to use as actor
  const currentWorkerName = selectedWorker?.name || activeComplaint.assignedWorker || 'Field Specialist';

  // Work notes input state
  const [newNoteInput, setNewNoteInput] = useState('');
  const [isAddingNote, setIsAddingNote] = useState(false);

  // Resolution submission form state - context aware based on complaint category
  const [resolutionDesc, setResolutionDesc] = useState(
    activeComplaint.resolutionDescription ||
      activeComplaint.evidence?.resolutionDescription ||
      template.defaultResolutionDescription
  );
  const [beforePhoto, setBeforePhoto] = useState<string>(
    activeComplaint.evidence?.beforePhotoUrl ||
      activeComplaint.photoUrl ||
      template.defaultBeforePhoto
  );
  const [afterPhoto, setAfterPhoto] = useState<string>(
    activeComplaint.evidence?.afterPhotoUrl ||
      activeComplaint.evidence?.photoUrl ||
      template.defaultAfterPhoto
  );
  const [partsReplaced, setPartsReplaced] = useState(
    activeComplaint.evidence?.partsReplaced || template.defaultMaterialsUsed
  );
  const [formError, setFormError] = useState<string | null>(null);

  // Sync form state when active complaint changes or if existing evidence is mismatched
  React.useEffect(() => {
    const isCategoryMismatched =
      activeComplaint.category !== 'Roads' &&
      ((activeComplaint.evidence?.partsReplaced &&
        activeComplaint.evidence.partsReplaced.toLowerCase().includes('road')) ||
        (activeComplaint.evidence?.beforePhotoUrl &&
          activeComplaint.evidence.beforePhotoUrl.includes('1515162816999')));

    if (isCategoryMismatched || !activeComplaint.evidence) {
      setResolutionDesc(
        activeComplaint.resolutionDescription || template.defaultResolutionDescription
      );
      setBeforePhoto(activeComplaint.photoUrl || template.defaultBeforePhoto);
      setAfterPhoto(template.defaultAfterPhoto);
      setPartsReplaced(template.defaultMaterialsUsed);
    } else {
      setResolutionDesc(
        activeComplaint.resolutionDescription ||
          activeComplaint.evidence.resolutionDescription ||
          activeComplaint.evidence.workerNotes ||
          template.defaultResolutionDescription
      );
      setBeforePhoto(
        activeComplaint.evidence.beforePhotoUrl ||
          activeComplaint.photoUrl ||
          template.defaultBeforePhoto
      );
      setAfterPhoto(
        activeComplaint.evidence.afterPhotoUrl ||
          activeComplaint.evidence.photoUrl ||
          template.defaultAfterPhoto
      );
      setPartsReplaced(
        activeComplaint.evidence.partsReplaced || template.defaultMaterialsUsed
      );
    }
  }, [activeComplaint.id, activeComplaint.category]);

  // Stage status progression helper
  const getStageStatus = (stageName: string) => {
    if (activeComplaint.status === 'REOPENED') {
      if (stageName === 'REPORT' || stageName === 'TRIAGE') return 'completed';
      return 'reopened';
    }

    const stageHierarchy: Record<ComplaintStatus, number> = {
      'REPORTED': 0,
      'TRIAGED': 1,
      'ASSIGNED': 2,
      'IN PROGRESS': 3,
      'RESOLUTION SUBMITTED': 4,
      'AWAITING VERIFICATION': 5,
      'VERIFIED': 5,
      'CLOSED': 6,
      'VERIFIED / CLOSED': 6,
      'REOPENED': 1,
    };

    const currentStageNum = stageHierarchy[activeComplaint.status] ?? 0;
    const stageIndexMap: Record<string, number> = {
      'REPORT': 0,
      'TRIAGE': 1,
      'ASSIGN': 2,
      'ACT': 3,
      'PROVE': 4,
      'VERIFY': 5,
    };

    const thisIndex = stageIndexMap[stageName];
    if (thisIndex < currentStageNum) return 'completed';
    if (thisIndex === currentStageNum || (thisIndex === 5 && currentStageNum >= 5)) return 'current';
    return 'pending';
  };

  const handleStartWorkClick = () => {
    startWork(activeComplaint.id, currentWorkerName);
  };

  const handleAddNoteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNoteInput.trim()) return;
    addWorkNote(activeComplaint.id, currentWorkerName, newNoteInput.trim());
    setNewNoteInput('');
    setIsAddingNote(false);
  };

  const handleFileUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    setter: (url: string) => void
  ) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setter(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmitResolution = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resolutionDesc.trim()) {
      setFormError('Please provide a meaningful resolution description.');
      return;
    }
    if (!afterPhoto) {
      setFormError('At least one resolution evidence image (After Work) is required.');
      return;
    }

    setFormError(null);
    submitResolution(
      activeComplaint.id,
      currentWorkerName,
      resolutionDesc.trim(),
      afterPhoto,
      beforePhoto || undefined,
      partsReplaced.trim() || undefined
    );
  };

  const isAssigned = activeComplaint.status === 'ASSIGNED';
  const isInProgress = activeComplaint.status === 'IN PROGRESS';
  const isAwaitingVerification =
    activeComplaint.status === 'AWAITING VERIFICATION' ||
    activeComplaint.status === 'RESOLUTION SUBMITTED';
  const isClosed = activeComplaint.status === 'VERIFIED / CLOSED';

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden animate-in zoom-in-95">
        {/* Header */}
        <div className="bg-[#0F1E36] text-white px-6 py-5 flex items-center justify-between border-b border-slate-800">
          <div className="flex flex-wrap items-center gap-3">
            <span className="font-mono text-sm font-bold bg-slate-800 px-3 py-1 rounded-lg border border-slate-700 text-amber-400">
              {activeComplaint.id}
            </span>
            <StatusBadge status={activeComplaint.status} size="md" />
            <PriorityBadge priority={activeComplaint.priority} />
            <SlaBadge deadline={activeComplaint.deadline} />
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="overflow-y-auto p-6 space-y-6">
          {/* Work Order Title & Metadata */}
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 font-medium mb-1">
              <span className="uppercase tracking-wider text-amber-700 font-bold">
                {activeComplaint.category}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                Assigned: {new Date(activeComplaint.updatedAt).toLocaleDateString()}
              </span>
              <span>•</span>
              <span className="text-slate-700 font-semibold">
                Worker: {currentWorkerName}
              </span>
            </div>

            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 leading-snug">
              {activeComplaint.title}
            </h1>

            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600 mt-2">
              <span className="flex items-center gap-1.5 font-medium text-slate-800">
                <MapPin className="w-3.5 h-3.5 text-amber-600" />
                <span>{activeComplaint.location}</span>
              </span>
              <span className="flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5 text-blue-600" />
                <span>Dept: {activeComplaint.department || activeComplaint.assignedDepartment || 'General Services'}</span>
              </span>
              <span className="flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-slate-400" />
                <span>Citizen: {activeComplaint.citizenName}</span>
              </span>
            </div>
          </div>

          {/* 4. CivicPulse Lifecycle Stepper */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 sm:p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <HardHat className="w-4 h-4 text-amber-600" />
                <span>Field Operations Lifecycle Progress</span>
              </div>
              <span className="text-[11px] text-slate-500 font-medium">
                Target SLA: {activeComplaint.deadline ? new Date(activeComplaint.deadline).toLocaleString() : '48 Hours'}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-6 gap-2">
              {WORKFLOW_STAGES.map((step) => {
                const stepState = getStageStatus(step.stage);
                const isCurrent = stepState === 'current';
                const isCompleted = stepState === 'completed';

                return (
                  <div
                    key={step.stage}
                    className={`p-2.5 rounded-xl border text-center transition-all ${
                      isCompleted
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                        : isCurrent
                        ? 'bg-amber-50 border-amber-500 text-amber-950 ring-2 ring-amber-500 font-bold shadow-sm'
                        : 'bg-white border-slate-200 text-slate-400'
                    }`}
                  >
                    <div className="flex items-center justify-center mb-1">
                      {isCompleted ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      ) : isCurrent ? (
                        <div className="w-2.5 h-2.5 rounded-full bg-amber-600 animate-ping" />
                      ) : (
                        <div className="w-2 h-2 rounded-full bg-slate-300" />
                      )}
                    </div>
                    <div className="text-xs font-bold leading-tight">{step.label}</div>
                    <div className="text-[10px] text-slate-500 mt-0.5">{step.desc}</div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 5. START WORK Primary Trigger Banner */}
          {isAssigned && (
            <div className="bg-amber-50 border-2 border-amber-400 rounded-2xl p-5 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-200 text-amber-900 flex items-center justify-center shrink-0">
                  <Wrench className="w-6 h-6 text-amber-800" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-amber-950">
                    Work Order Ready to Begin
                  </h3>
                  <p className="text-xs text-amber-800 mt-0.5">
                    Municipal Supervisor assigned this complaint to {currentWorkerName}. Click below to confirm arrival and mark work In Progress.
                  </p>
                </div>
              </div>

              <button
                onClick={handleStartWorkClick}
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs sm:text-sm shadow-md transition-all flex items-center justify-center gap-2 hover:scale-[1.02]"
              >
                <Wrench className="w-4 h-4" />
                <span>START WORK</span>
              </button>
            </div>
          )}

          {/* Description & Citizen Evidence */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Work Order Description
                </h3>
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs sm:text-sm text-slate-800 leading-relaxed">
                  {activeComplaint.description}
                </div>
              </div>

              {activeComplaint.triageNotes && (
                <div className="bg-blue-50/70 border border-blue-200 rounded-xl p-3.5 text-xs text-blue-900">
                  <span className="font-bold text-blue-950 block mb-1">
                    Municipal Supervisor Triage Notes:
                  </span>
                  <p className="italic text-blue-800">"{activeComplaint.triageNotes}"</p>
                </div>
              )}
            </div>

            {/* Clearly Labeled CITIZEN EVIDENCE */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  CITIZEN EVIDENCE (INITIAL REPORT)
                </h3>
                <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-semibold">
                  Reported by Citizen
                </span>
              </div>
              {activeComplaint.photoUrl ? (
                <div className="rounded-xl overflow-hidden border border-slate-200 h-52 bg-slate-100 shadow-inner">
                  <img
                    src={activeComplaint.photoUrl}
                    alt="Citizen Initial Evidence"
                    className="w-full h-full object-cover"
                  />
                </div>
              ) : (
                <div className="rounded-xl border border-dashed border-slate-300 h-52 flex flex-col items-center justify-center text-slate-400 bg-slate-50 text-xs">
                  <span>No photo attached in initial report</span>
                </div>
              )}
            </div>
          </div>

          {/* 6. WORK NOTES Section (Structured, Non-overwriting) */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-slate-700" />
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Field Work Notes & Observations ({activeComplaint.workNotes?.length || 0})
                </h3>
              </div>
              {isInProgress && !isAddingNote && (
                <button
                  onClick={() => setIsAddingNote(true)}
                  className="px-3 py-1 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-lg text-xs font-semibold flex items-center gap-1 shadow-sm transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Note</span>
                </button>
              )}
            </div>

            {/* Existing notes list */}
            {activeComplaint.workNotes && activeComplaint.workNotes.length > 0 ? (
              <div className="space-y-2">
                {activeComplaint.workNotes.map((wn) => (
                  <div
                    key={wn.id}
                    className="bg-white p-3 rounded-lg border border-slate-200 text-xs space-y-1 shadow-2xs"
                  >
                    <div className="flex items-center justify-between text-slate-500 text-[11px]">
                      <span className="font-semibold text-slate-800">{wn.workerName}</span>
                      <span>{new Date(wn.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                    <p className="text-slate-800">{wn.note}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-400 italic">
                No preliminary work notes recorded yet.
              </p>
            )}

            {/* Add note form */}
            {isAddingNote && (
              <form onSubmit={handleAddNoteSubmit} className="bg-white p-3.5 rounded-xl border border-slate-300 space-y-2.5">
                <label className="block text-xs font-bold text-slate-800">
                  New Work Note / Observation:
                </label>
                <textarea
                  rows={2}
                  value={newNoteInput}
                  onChange={(e) => setNewNoteInput(e.target.value)}
                  placeholder="e.g. Inspected damaged street light pole. Replacement component required."
                  className="w-full p-2.5 border border-slate-300 rounded-lg text-xs text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                  required
                />
                <div className="flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setIsAddingNote(false);
                      setNewNoteInput('');
                    }}
                    className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-lg"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 text-xs font-semibold bg-amber-600 hover:bg-amber-700 text-white rounded-lg shadow-sm"
                  >
                    Save Work Note
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* 7, 8, 9. RESOLUTION EVIDENCE & SUBMIT RESOLUTION (For IN PROGRESS) */}
          {isInProgress && (
            <div className="bg-emerald-50/60 border-2 border-emerald-300 rounded-2xl p-5 space-y-5">
              <div className="border-b border-emerald-200/80 pb-3">
                <div className="flex items-center gap-2">
                  <FileCheck className="w-5 h-5 text-emerald-700" />
                  <h3 className="text-base font-bold text-emerald-950">
                    Resolution Evidence & Completion Submission
                  </h3>
                </div>
                <p className="text-xs text-emerald-800 mt-0.5">
                  Provide Before/After visual evidence and a detailed description before submitting for citizen verification.
                </p>
              </div>

              {formError && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              <form onSubmit={handleSubmitResolution} className="space-y-5 text-xs">
                {/* 7. Clearly Labeled BEFORE & AFTER Evidence */}
                <div>
                  <h4 className="font-bold text-slate-800 uppercase tracking-wider mb-2">
                    Visual Evidence Comparison
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* BEFORE WORK EVIDENCE */}
                    <div className="bg-white p-3.5 rounded-xl border border-slate-200 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-800 text-xs">
                          BEFORE WORK EVIDENCE
                        </span>
                        <span className="text-[10px] text-slate-400">At start of repair</span>
                      </div>
                      <div className="h-36 rounded-lg overflow-hidden border border-slate-200 bg-slate-100">
                        {beforePhoto ? (
                          <img src={beforePhoto} alt="Before work" className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-slate-400">No before photo</div>
                        )}
                      </div>
                      <div className="flex items-center justify-between pt-1">
                        <label className="cursor-pointer text-[11px] text-blue-600 hover:text-blue-700 font-semibold flex items-center gap-1">
                          <UploadCloud className="w-3.5 h-3.5" />
                          <span>Upload Before Photo</span>
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => handleFileUpload(e, setBeforePhoto)}
                          />
                        </label>
                        <select
                          onChange={(e) => setBeforePhoto(e.target.value)}
                          className="text-[10px] border border-slate-200 rounded px-1.5 py-1 text-slate-600 max-w-[130px] truncate"
                        >
                          <option value="">Demo Presets</option>
                          {template.beforePresets.map((p, idx) => (
                            <option key={idx} value={p.url}>{p.label}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* AFTER WORK EVIDENCE */}
                    <div className="bg-white p-3.5 rounded-xl border-2 border-emerald-300 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-emerald-900 text-xs flex items-center gap-1">
                          <span>AFTER WORK EVIDENCE</span>
                          <span className="text-rose-500">*</span>
                        </span>
                        <span className="text-[10px] text-emerald-700 font-medium">Completed repair</span>
                      </div>
                      <div className="h-36 rounded-lg overflow-hidden border border-emerald-200 bg-emerald-50">
                        {afterPhoto ? (
                          <img src={afterPhoto} alt="After work" className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-emerald-600">Upload required</div>
                        )}
                      </div>
                      <div className="flex items-center justify-between pt-1">
                        <label className="cursor-pointer text-[11px] text-emerald-700 hover:text-emerald-800 font-bold flex items-center gap-1">
                          <UploadCloud className="w-3.5 h-3.5" />
                          <span>Upload After Photo</span>
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => handleFileUpload(e, setAfterPhoto)}
                          />
                        </label>
                        <select
                          onChange={(e) => setAfterPhoto(e.target.value)}
                          className="text-[10px] border border-emerald-300 rounded px-1.5 py-1 text-emerald-800 font-medium max-w-[130px] truncate"
                        >
                          <option value="">Demo Presets</option>
                          {template.afterPresets.map((p, idx) => (
                            <option key={idx} value={p.url}>{p.label}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 8. RESOLUTION DESCRIPTION */}
                <div>
                  <label className="block font-bold text-slate-800 mb-1.5">
                    Resolution Description <span className="text-rose-500">*</span>
                  </label>
                  <textarea
                    rows={3}
                    value={resolutionDesc}
                    onChange={(e) => setResolutionDesc(e.target.value)}
                    placeholder="e.g. Street light wiring repaired and lamp replaced. Tested successfully."
                    className="w-full p-3 rounded-xl border border-slate-300 text-slate-900 text-xs sm:text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white"
                    required
                  />
                </div>

                {/* Parts Replaced */}
                <div>
                  <label className="block font-bold text-slate-800 mb-1">
                    Parts Replaced / Materials Consumed (Optional)
                  </label>
                  <input
                    type="text"
                    value={partsReplaced}
                    onChange={(e) => setPartsReplaced(e.target.value)}
                    placeholder="e.g. 120W Philips LED Driver, Ground clamp, 40kg asphalt cold mix"
                    className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 text-xs bg-white"
                  />
                </div>

                {/* 9. SUBMIT RESOLUTION Trigger */}
                <div className="pt-2 flex justify-end">
                  <button
                    type="submit"
                    className="w-full sm:w-auto px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm shadow-md transition-all flex items-center justify-center gap-2 hover:scale-[1.02]"
                  >
                    <Send className="w-4 h-4" />
                    <span>SUBMIT RESOLUTION</span>
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Already Submitted View (AWAITING VERIFICATION / CLOSED) */}
          {(isAwaitingVerification || isClosed) && activeComplaint.evidence && (
            <div className="bg-emerald-50/70 border border-emerald-300 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between border-b border-emerald-200 pb-2">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-950">
                    Field Worker Resolution Evidence Logged
                  </h3>
                </div>
                <span className="text-[11px] text-emerald-700 font-medium">
                  Submitted by {activeComplaint.evidence.submittedBy}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="font-bold text-slate-700 block mb-1">Resolution Summary:</span>
                  <p className="bg-white p-3 rounded-lg border border-emerald-200 text-slate-900 leading-relaxed">
                    {activeComplaint.evidence.resolutionDescription ||
                      activeComplaint.evidence.workerNotes ||
                      template.defaultResolutionDescription}
                  </p>
                  {(activeComplaint.evidence.partsReplaced || template.defaultMaterialsUsed) && (
                    <div className="mt-2 text-emerald-800 text-[11px]">
                      <strong>Materials Used:</strong>{' '}
                      {activeComplaint.evidence.partsReplaced || template.defaultMaterialsUsed}
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <span className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Before Work</span>
                    <div className="h-28 rounded-lg overflow-hidden border border-slate-200">
                      <img
                        src={
                          activeComplaint.evidence.beforePhotoUrl ||
                          activeComplaint.photoUrl ||
                          template.defaultBeforePhoto
                        }
                        alt="Before"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-emerald-700 uppercase block mb-1">After Work</span>
                    <div className="h-28 rounded-lg overflow-hidden border border-emerald-300">
                      <img
                        src={
                          activeComplaint.evidence.afterPhotoUrl ||
                          activeComplaint.evidence.photoUrl ||
                          template.defaultAfterPhoto
                        }
                        alt="After"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 13. Activity History */}
          <div>
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">
              Full Audit & Dispatch History ({activeComplaint.timeline.length} entries)
            </h3>
            <div className="relative pl-6 border-l-2 border-slate-200 space-y-4">
              {activeComplaint.timeline.map((entry) => (
                <div key={entry.id} className="relative group">
                  <div className="absolute -left-[31px] top-1.5 w-3.5 h-3.5 rounded-full bg-amber-600 border-2 border-white ring-2 ring-amber-200" />
                  <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-xs">
                    <div className="flex items-center justify-between text-slate-500 mb-1">
                      <span className="font-semibold text-slate-800">
                        {entry.actor} ({entry.actorRole})
                      </span>
                      <span>
                        {new Date(entry.timestamp).toLocaleString(undefined, {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                    <div className="font-mono text-[11px] text-amber-700 font-bold mb-1">
                      Status: {entry.status}
                    </div>
                    {entry.comment && <p className="text-slate-700">{entry.comment}</p>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-semibold transition-colors"
          >
            Close Work Order
          </button>
        </div>
      </div>
    </div>
  );
};
