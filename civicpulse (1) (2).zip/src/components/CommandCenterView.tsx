import React, { useState } from 'react';
import { useCivic } from '../context/CivicContext';
import { Complaint, ComplaintCategory } from '../types';
import {
  calculateKpis,
  calculateFunnelStages,
  calculateCategoryBreakdown,
} from '../utils/analytics';
import { IntelligenceMapView } from './IntelligenceMapView';
import { SmartInsightsView } from './SmartInsightsView';
import { CivicImpactView } from './CivicImpactView';
import {
  Building2,
  Activity,
  Layers,
  Clock,
  CheckCircle2,
  AlertCircle,
  RotateCcw,
  ShieldCheck,
  TrendingUp,
  SlidersHorizontal,
  Compass,
  BrainCircuit,
  Award,
  ChevronRight,
  ArrowRight,
  Sparkles,
  BarChart3,
  Calendar,
} from 'lucide-react';

interface CommandCenterViewProps {
  onSelectComplaint: (complaint: Complaint) => void;
}

export const CommandCenterView: React.FC<CommandCenterViewProps> = ({ onSelectComplaint }) => {
  const { complaints, setActiveView } = useCivic();

  // Active sub-capability tab
  const [activeTab, setActiveTab] = useState<'overview' | 'map' | 'insights' | 'impact'>('overview');

  // Time filter simulated state
  const [timeFilter, setTimeFilter] = useState<'all' | '30d' | '7d'>('all');

  // Compute live real-time KPIs and funnel strictly from complaints
  const kpis = calculateKpis(complaints);
  const funnel = calculateFunnelStages(complaints);
  const categories = calculateCategoryBreakdown(complaints);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* 1. Header with Title & Subtitle */}
      <div className="bg-[#0F1E36] text-white rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border border-slate-800 shadow-xl">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-semibold mb-2 border border-emerald-500/30">
            <Activity className="w-3.5 h-3.5" />
            <span>Executive Operations Telemetry</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            CivicPulse Command Center
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
            Real-time visibility into civic issues, municipal response and resolution performance.
          </p>
        </div>

        {/* Quick link back to Operations Ledger */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setActiveView('dashboard')}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold transition-all flex items-center gap-2 shadow-sm"
          >
            <span>Operations Center Ledger</span>
            <ArrowRight className="w-4 h-4 text-emerald-400" />
          </button>
        </div>
      </div>

      {/* 4 Connected Capabilities Navigation Tabs */}
      <div className="bg-white rounded-xl border border-slate-200 p-1.5 shadow-xs flex flex-wrap gap-1">
        <button
          onClick={() => setActiveTab('overview')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold transition-all ${
            activeTab === 'overview'
              ? 'bg-slate-900 text-white shadow-sm'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <BarChart3 className="w-4 h-4 text-emerald-400" />
          <span>Operations KPIs & Pipeline</span>
        </button>

        <button
          onClick={() => setActiveTab('map')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold transition-all ${
            activeTab === 'map'
              ? 'bg-slate-900 text-white shadow-sm'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Compass className="w-4 h-4 text-blue-400" />
          <span>Civic Issue Intelligence Map</span>
        </button>

        <button
          onClick={() => setActiveTab('insights')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold transition-all ${
            activeTab === 'insights'
              ? 'bg-slate-900 text-white shadow-sm'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <BrainCircuit className="w-4 h-4 text-indigo-400" />
          <span>Smart Civic Insights</span>
        </button>

        <button
          onClick={() => setActiveTab('impact')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold transition-all ${
            activeTab === 'impact'
              ? 'bg-slate-900 text-white shadow-sm'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Award className="w-4 h-4 text-amber-400" />
          <span>Civic Impact Dashboard</span>
        </button>
      </div>

      {/* SUB-VIEW 1: OVERVIEW & KPIs + RESOLUTION PERFORMANCE */}
      {activeTab === 'overview' && (
        <div className="space-y-6 animate-in fade-in">
          {/* 2. KPI CARDS (8 KPI Cards Derived from Real Complaint State) */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-4 gap-3.5">
            {/* 1. Total Complaints */}
            <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-slate-300 transition-all space-y-1">
              <div className="flex items-center justify-between text-slate-500">
                <span className="text-[11px] font-bold uppercase tracking-wider">Total Complaints</span>
                <Layers className="w-4 h-4 text-slate-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold text-slate-900">
                {kpis.totalComplaints}
              </div>
              <p className="text-[11px] text-slate-500">All registered complaints</p>
            </div>

            {/* 2. Active Complaints */}
            <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-amber-300 transition-all space-y-1">
              <div className="flex items-center justify-between text-amber-800">
                <span className="text-[11px] font-bold uppercase tracking-wider">Active Complaints</span>
                <Activity className="w-4 h-4 text-amber-600" />
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold text-amber-900">
                {kpis.activeComplaints}
              </div>
              <p className="text-[11px] text-amber-700">Complaints not closed</p>
            </div>

            {/* 3. Resolved Complaints */}
            <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-emerald-300 transition-all space-y-1">
              <div className="flex items-center justify-between text-emerald-800">
                <span className="text-[11px] font-bold uppercase tracking-wider">Resolved Complaints</span>
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold text-emerald-900">
                {kpis.resolvedComplaints}
              </div>
              <p className="text-[11px] text-emerald-700">Closed with citizen verification</p>
            </div>

            {/* 4. Awaiting Verification */}
            <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-orange-300 transition-all space-y-1">
              <div className="flex items-center justify-between text-orange-800">
                <span className="text-[11px] font-bold uppercase tracking-wider">Awaiting Verification</span>
                <Clock className="w-4 h-4 text-orange-600 animate-pulse" />
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold text-orange-950">
                {kpis.awaitingVerification}
              </div>
              <p className="text-[11px] text-orange-700">Resolution proof submitted</p>
            </div>

            {/* 5. Reopened Complaints */}
            <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-rose-300 transition-all space-y-1">
              <div className="flex items-center justify-between text-rose-800">
                <span className="text-[11px] font-bold uppercase tracking-wider">Reopened Complaints</span>
                <RotateCcw className="w-4 h-4 text-rose-600" />
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold text-rose-900">
                {kpis.reopenedComplaints}
              </div>
              <p className="text-[11px] text-rose-700">Resolution rejected by resident</p>
            </div>

            {/* 6. SLA Compliance */}
            <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-blue-300 transition-all space-y-1">
              <div className="flex items-center justify-between text-blue-800">
                <span className="text-[11px] font-bold uppercase tracking-wider">SLA Compliance</span>
                <ShieldCheck className="w-4 h-4 text-blue-600" />
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold text-blue-900">
                {kpis.slaComplianceRate !== null ? `${kpis.slaComplianceRate}%` : '100%'}
              </div>
              <p className="text-[11px] text-blue-700">Resolved prior to SLA deadline</p>
            </div>

            {/* 7. Average Resolution Time */}
            <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-indigo-300 transition-all space-y-1">
              <div className="flex items-center justify-between text-indigo-800">
                <span className="text-[11px] font-bold uppercase tracking-wider">Avg Resolution Time</span>
                <Clock className="w-4 h-4 text-indigo-600" />
              </div>
              <div className="text-xl sm:text-2xl font-extrabold text-indigo-950 truncate">
                {kpis.avgResolutionFormatted}
              </div>
              <p className="text-[11px] text-indigo-700">Reported to closed duration</p>
            </div>

            {/* 8. Citizen Verification Rate */}
            <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-teal-300 transition-all space-y-1">
              <div className="flex items-center justify-between text-teal-800">
                <span className="text-[11px] font-bold uppercase tracking-wider">Citizen Verification Rate</span>
                <TrendingUp className="w-4 h-4 text-teal-600" />
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold text-teal-900">
                {kpis.citizenVerificationRate !== null ? `${kpis.citizenVerificationRate}%` : '100%'}
              </div>
              <p className="text-[11px] text-teal-700">Resolutions verified vs reopened</p>
            </div>
          </div>

          {/* 3. RESOLUTION PERFORMANCE SECTION */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Resolution Performance Pipeline
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Full lifecycle stage progression from citizen submission to verified closure
                </p>
              </div>

              <div className="flex items-center gap-2 text-xs font-bold text-slate-600 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
                <span>Accountability Flow:</span>
                <span className="font-mono text-emerald-700">REPORT → TRIAGE → ASSIGN → ACT → PROVE → VERIFY</span>
              </div>
            </div>

            {/* Visual Funnel Stage Cards */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
              {funnel.map((item, index) => (
                <div
                  key={item.stage}
                  className="bg-slate-50/70 p-4 rounded-xl border border-slate-200 flex flex-col justify-between space-y-3 hover:border-slate-300 transition-all"
                >
                  <div>
                    <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                      <span className="font-bold text-slate-700">{item.label}</span>
                      <span className="font-mono font-semibold text-slate-400">Step {index + 1}</span>
                    </div>
                    <div className="text-2xl font-extrabold text-slate-900">{item.count}</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      {item.percentage}% of total issues
                    </div>
                  </div>

                  {/* Visual Progress Bar */}
                  <div>
                    <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${item.color}`}
                        style={{ width: `${Math.max(8, item.percentage)}%` }}
                      />
                    </div>
                    <p className="text-[10px] text-slate-500 mt-2 leading-snug line-clamp-2">
                      {item.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Pipeline Stage Bar */}
            <div className="space-y-1.5 pt-2">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-600">
                <span>Overall Municipal Workstream Distribution</span>
                <span>{kpis.totalComplaints} Active Ledger Items</span>
              </div>
              <div className="h-4 w-full bg-slate-100 rounded-full overflow-hidden flex shadow-inner">
                {funnel.map((item) => (
                  <div
                    key={`bar-${item.stage}`}
                    className={`h-full ${item.color} transition-all`}
                    style={{ width: `${item.percentage}%` }}
                    title={`${item.label}: ${item.count} (${item.percentage}%)`}
                  />
                ))}
              </div>
              <div className="flex flex-wrap items-center gap-3 pt-1 text-[11px] text-slate-500">
                {funnel.map((item) => (
                  <div key={`legend-${item.stage}`} className="flex items-center gap-1.5">
                    <span className={`w-2.5 h-2.5 rounded-full ${item.color}`} />
                    <span className="font-medium text-slate-700">{item.label}</span>
                    <span className="font-mono font-bold text-slate-500">({item.count})</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Category Distribution Grid */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-4">
            <div className="border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-900">
                Infrastructure Category Breakdown
              </h3>
              <p className="text-xs text-slate-500">
                Complaint volume, resolved completions, and active field load by civic domain
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
              {categories.map((cat) => (
                <div
                  key={cat.category}
                  className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 space-y-2"
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-900">{cat.category}</span>
                    <span className="font-mono font-bold text-slate-700 bg-white px-2 py-0.5 rounded border border-slate-200">
                      {cat.total} issues ({cat.percentage}%)
                    </span>
                  </div>

                  <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full bg-gradient-to-r ${cat.color}`}
                      style={{ width: `${cat.percentage}%` }}
                    />
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
                    <span>
                      Resolved: <strong className="text-emerald-700">{cat.resolved}</strong>
                    </span>
                    <span>
                      Active: <strong className="text-amber-700">{cat.active}</strong>
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 2: CIVIC ISSUE INTELLIGENCE MAP */}
      {activeTab === 'map' && (
        <div className="animate-in fade-in space-y-6">
          <IntelligenceMapView
            complaints={complaints}
            onSelectComplaint={onSelectComplaint}
          />
        </div>
      )}

      {/* SUB-VIEW 3: SMART CIVIC INSIGHTS */}
      {activeTab === 'insights' && (
        <div className="animate-in fade-in space-y-6">
          <SmartInsightsView
            complaints={complaints}
            onSelectComplaint={onSelectComplaint}
          />
        </div>
      )}

      {/* SUB-VIEW 4: CIVIC IMPACT DASHBOARD */}
      {activeTab === 'impact' && (
        <div className="animate-in fade-in space-y-6">
          <CivicImpactView complaints={complaints} />
        </div>
      )}
    </div>
  );
};
