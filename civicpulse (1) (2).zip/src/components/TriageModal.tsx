import React, { useState, useEffect } from 'react';
import { Complaint, PriorityLevel, MunicipalDepartment, AiTriageSuggestion } from '../types';
import { MUNICIPAL_DEPARTMENTS } from '../data/mockData';
import { useCivic } from '../context/CivicContext';
import { aiService } from '../services/aiService';
import {
  X,
  ClipboardCheck,
  Building2,
  Clock,
  AlertTriangle,
  FileText,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  Copy,
  Sliders,
  Check,
} from 'lucide-react';

interface TriageModalProps {
  complaint: Complaint;
  onClose: () => void;
  onTriageComplete?: () => void;
}

const SLA_OPTIONS = [
  { hours: 4, label: '4 Hours (Emergency)' },
  { hours: 12, label: '12 Hours (Urgent)' },
  { hours: 24, label: '24 Hours (Standard)' },
  { hours: 48, label: '48 Hours (Routine)' },
  { hours: 72, label: '72 Hours (Extended)' },
];

export const TriageModal: React.FC<TriageModalProps> = ({
  complaint,
  onClose,
  onTriageComplete,
}) => {
  const { complaints, triageComplaint } = useCivic();

  const getDefaultDept = (): MunicipalDepartment => {
    switch (complaint.category) {
      case 'Roads':
        return 'Road Maintenance';
      case 'Street Lights':
        return 'Street Lighting';
      case 'Water Supply':
        return 'Water Supply';
      case 'Garbage':
        return 'Sanitation';
      case 'Drainage':
        return 'Drainage';
      case 'Public Safety':
        return 'Public Safety';
      default:
        return 'General Services';
    }
  };

  const [priority, setPriority] = useState<PriorityLevel>(complaint.priority || 'MEDIUM');
  const [department, setDepartment] = useState<MunicipalDepartment>(
    (complaint.department as MunicipalDepartment) || getDefaultDept()
  );
  const [slaHours, setSlaHours] = useState<number>(24);
  const [notes, setNotes] = useState<string>(
    complaint.triageNotes || `${complaint.category} damage inspected. Dispatch field unit for on-site repair.`
  );

  // AI Assistance State
  const [aiSuggestion, setAiSuggestion] = useState<AiTriageSuggestion | null>(complaint.aiTriage || null);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [isAiAccepted, setIsAiAccepted] = useState(false);
  const [hasSupervisorOverridden, setHasSupervisorOverridden] = useState(false);

  // Duplicate Check State
  const [duplicateMatch, setDuplicateMatch] = useState(() =>
    aiService.detectDuplicates(
      {
        id: complaint.id,
        title: complaint.title,
        description: complaint.description,
        category: complaint.category,
        location: complaint.location,
      },
      complaints
    )
  );

  useEffect(() => {
    if (!complaint.aiTriage) {
      setIsAiLoading(true);
      aiService
        .suggestTriage(complaint.title, complaint.description, complaint.location)
        .then((sug) => {
          setAiSuggestion(sug);
        })
        .catch(console.warn)
        .finally(() => setIsAiLoading(false));
    }
  }, [complaint]);

  const handleAcceptAiRecommendation = () => {
    if (!aiSuggestion) return;
    setPriority(aiSuggestion.suggestedPriority);
    setDepartment(aiSuggestion.suggestedDepartment);
    setSlaHours(aiSuggestion.recommendedSlaHours);
    setNotes(
      (prev) =>
        `${prev.trim()} [AI recommendation adopted: ${aiSuggestion.suggestedPriority} priority, ${aiSuggestion.suggestedDepartment}, SLA ${aiSuggestion.recommendedSlaHours}h (${Math.round(aiSuggestion.confidence * 100)}% confidence)]`
    );
    setIsAiAccepted(true);
    setHasSupervisorOverridden(false);
  };

  const handleManualOverride = () => {
    setIsAiAccepted(false);
    setHasSupervisorOverridden(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    triageComplaint(complaint.id, priority, department, slaHours, notes, {
      accepted: isAiAccepted,
      suggestion: aiSuggestion || undefined,
    });
    if (onTriageComplete) onTriageComplete();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-xl max-h-[92vh] flex flex-col overflow-hidden animate-in zoom-in-95">
        {/* Header */}
        <div className="bg-[#0F1E36] text-white px-6 py-4 flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 border border-blue-500/30 flex items-center justify-center">
              <ClipboardCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs uppercase font-bold text-blue-400 tracking-wider">
                  Phase 2: Triage Protocol
                </span>
                <span className="font-mono text-xs bg-slate-800 text-emerald-400 px-2 py-0.5 rounded font-bold">
                  {complaint.id}
                </span>
              </div>
              <h2 className="text-lg font-bold text-white">Triage Municipal Complaint</h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Complaint Summary Pill */}
        <div className="bg-slate-50 border-b border-slate-200 px-6 py-2.5 text-xs text-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 shrink-0">
          <div className="font-semibold text-slate-900 truncate">
            {complaint.title}
          </div>
          <div className="text-slate-500 shrink-0">
            Ward: <strong className="text-slate-800">{complaint.ward || complaint.location}</strong>
          </div>
        </div>

        <div className="overflow-y-auto flex-1 p-6 space-y-5 text-xs sm:text-sm">
          {/* AI CIVIC TRIAGE ASSISTANCE PANEL */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-blue-50/80 to-indigo-50/70 border border-blue-200 text-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-blue-900 text-sm">
                <Sparkles className="w-4 h-4 text-blue-600" />
                <span>AI Civic Triage Recommendation</span>
              </div>
              {aiSuggestion && (
                <span className="bg-blue-100 text-blue-800 text-[11px] font-bold px-2 py-0.5 rounded-md border border-blue-200">
                  {Math.round(aiSuggestion.confidence * 100)}% Confidence
                </span>
              )}
            </div>

            {aiSuggestion && (
              <>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-xs">
                  <div className="p-2 bg-white rounded-lg border border-blue-100">
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">AI Category</span>
                    <span className="font-bold text-slate-900">{aiSuggestion.suggestedCategory}</span>
                  </div>
                  <div className="p-2 bg-white rounded-lg border border-blue-100">
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">AI Severity</span>
                    <span className={`font-bold ${
                      aiSuggestion.suggestedPriority === 'CRITICAL' ? 'text-rose-600' :
                      aiSuggestion.suggestedPriority === 'HIGH' ? 'text-amber-700' : 'text-blue-700'
                    }`}>
                      {aiSuggestion.suggestedPriority}
                    </span>
                  </div>
                  <div className="p-2 bg-white rounded-lg border border-blue-100">
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">AI Department</span>
                    <span className="font-bold text-slate-900 truncate block">{aiSuggestion.suggestedDepartment}</span>
                  </div>
                  <div className="p-2 bg-white rounded-lg border border-blue-100">
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">Target SLA</span>
                    <span className="font-bold text-emerald-700">{aiSuggestion.recommendedSlaHours}h window</span>
                  </div>
                </div>

                <div className="text-[11px] text-slate-600 bg-white/70 p-2.5 rounded-lg border border-blue-100/70">
                  <strong className="text-slate-800">Reasoning:</strong> {aiSuggestion.reasoning}
                  <div className="mt-1 flex flex-wrap gap-1 text-[10px] text-slate-500 font-mono">
                    {aiSuggestion.keyFactors.map((kf, i) => (
                      <span key={i} className="bg-slate-100 px-1.5 py-0.5 rounded">
                        • {kf}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Model Attribution & Accept Button */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1">
                  <span className="text-[10px] text-slate-500 italic">
                    Model: {aiSuggestion.model}
                  </span>

                  {!isAiAccepted ? (
                    <button
                      type="button"
                      onClick={handleAcceptAiRecommendation}
                      className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg shadow-sm flex items-center gap-1.5 transition-all self-start sm:self-auto"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Accept AI Recommendation</span>
                    </button>
                  ) : (
                    <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-100 px-2.5 py-1 rounded-lg">
                      <Check className="w-3.5 h-3.5" />
                      <span>AI Recommendation Accepted</span>
                    </div>
                  )}
                </div>
              </>
            )}

            {isAiLoading && (
              <div className="text-xs text-blue-700 italic animate-pulse">
                Running natural language civic triage analysis...
              </div>
            )}
          </div>

          {/* DUPLICATE SIMILARITY DETECTION PANEL */}
          {duplicateMatch && duplicateMatch.isDuplicate && (
            <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-300 text-xs text-amber-950 flex items-start gap-2.5">
              <Copy className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-amber-900 uppercase text-[11px]">
                    Potential Duplicate Detected ({duplicateMatch.similarity}% Match)
                  </span>
                  <span className="bg-amber-200 text-amber-900 font-mono text-[10px] px-1.5 py-0.5 rounded font-bold">
                    {duplicateMatch.matchedComplaintId}
                  </span>
                </div>
                <p className="mt-0.5 text-amber-900 font-medium">
                  "{duplicateMatch.matchedTitle}"
                </p>
                <p className="mt-1 text-[11px] text-amber-800">
                  {duplicateMatch.reason}. Supervisor review recommended before dispatching duplicate crew.
                </p>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} id="triage-form" className="space-y-5">
            {/* Decision Status Badge */}
            <div className="flex items-center justify-between text-xs pb-1">
              <span className="font-bold text-slate-800 uppercase tracking-wider">
                Supervisor Review & Final Determination
              </span>
              <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                isAiAccepted
                  ? 'bg-blue-100 text-blue-800'
                  : hasSupervisorOverridden
                  ? 'bg-amber-100 text-amber-800'
                  : 'bg-slate-100 text-slate-700'
              }`}>
                {isAiAccepted ? 'AI Suggested (Confirmed)' : hasSupervisorOverridden ? 'Supervisor Override' : 'Manual Triage'}
              </span>
            </div>

            {/* Priority Selection */}
            <div>
              <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                <span>Assessed Severity / Priority *</span>
              </label>
              <div className="grid grid-cols-4 gap-2">
                {(['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'] as PriorityLevel[]).map((p) => {
                  const isSelected = priority === p;
                  const isAiChoice = aiSuggestion?.suggestedPriority === p;
                  const colors = {
                    LOW: 'border-slate-300 text-slate-700 hover:border-slate-400',
                    MEDIUM: 'border-blue-300 text-blue-700 hover:border-blue-400',
                    HIGH: 'border-amber-300 text-amber-800 hover:border-amber-400',
                    CRITICAL: 'border-rose-400 text-rose-800 hover:border-rose-500',
                  }[p];
                  const activeColors = {
                    LOW: 'bg-slate-100 border-slate-500 ring-2 ring-slate-400 font-bold',
                    MEDIUM: 'bg-blue-50 border-blue-600 ring-2 ring-blue-500 font-bold',
                    HIGH: 'bg-amber-50 border-amber-600 ring-2 ring-amber-500 font-bold',
                    CRITICAL: 'bg-rose-50 border-rose-600 ring-2 ring-rose-500 font-bold',
                  }[p];

                  return (
                    <button
                      key={p}
                      type="button"
                      onClick={() => {
                        setPriority(p);
                        if (isAiChoice) {
                          // matches AI
                        } else {
                          handleManualOverride();
                        }
                      }}
                      className={`relative py-2 px-3 rounded-xl border text-center text-xs transition-all ${
                        isSelected ? activeColors : colors
                      }`}
                    >
                      {isAiChoice && (
                        <span className="absolute -top-1.5 -right-1 bg-blue-600 text-white text-[8px] px-1 rounded-full font-bold">
                          AI
                        </span>
                      )}
                      {p}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Department Selection */}
            <div>
              <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5 text-blue-600" />
                <span>Responsible Municipal Department *</span>
              </label>
              <select
                value={department}
                onChange={(e) => {
                  setDepartment(e.target.value as MunicipalDepartment);
                  handleManualOverride();
                }}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-slate-900 text-xs sm:text-sm font-medium focus:ring-2 focus:ring-blue-500 focus:outline-none"
              >
                {MUNICIPAL_DEPARTMENTS.map((dept) => (
                  <option key={dept} value={dept}>
                    {dept}
                  </option>
                ))}
              </select>
            </div>

            {/* SLA Deadline Selection */}
            <div>
              <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-emerald-600" />
                <span>Target SLA Resolution Window *</span>
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {SLA_OPTIONS.map((opt) => (
                  <button
                    key={opt.hours}
                    type="button"
                    onClick={() => {
                      setSlaHours(opt.hours);
                      if (aiSuggestion?.recommendedSlaHours !== opt.hours) {
                        handleManualOverride();
                      }
                    }}
                    className={`py-2 px-3 rounded-xl border text-left text-xs transition-all ${
                      slaHours === opt.hours
                        ? 'bg-emerald-50 border-emerald-600 text-emerald-950 ring-2 ring-emerald-500 font-bold'
                        : 'border-slate-200 text-slate-700 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div>{opt.label}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Triage Notes */}
            <div>
              <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-slate-600" />
                <span>Supervisor Triage Notes & Action Plan</span>
              </label>
              <textarea
                rows={3}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. Damage inspected on site. Assign road maintenance crew for emergency asphalt patching."
                className="w-full p-3 rounded-xl border border-slate-300 text-slate-900 text-xs sm:text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>
          </form>
        </div>

        {/* Actions Footer */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-50 border-t border-slate-200 shrink-0">
          <div className="text-xs text-slate-500 hidden sm:block">
            {isAiAccepted ? '✓ AI Recommendation Accepted' : hasSupervisorOverridden ? '⚠️ Manual Supervisor Override' : 'Standard Protocol'}
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              form="triage-form"
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold shadow-md transition-all flex items-center gap-1.5"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Confirm & Set Status to TRIAGED</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
