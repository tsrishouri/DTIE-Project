import React, { useState, useEffect } from 'react';
import { useCivic } from '../context/CivicContext';
import { Complaint, ComplaintStatus } from '../types';
import { StatusBadge, PriorityBadge, SlaBadge } from './StatusBadge';
import {
  Search,
  MapPin,
  Calendar,
  AlertCircle,
  CheckCircle2,
  Clock,
  ArrowRight,
  ShieldCheck,
  FileCheck,
  RotateCcw,
  CheckCircle,
  ShieldAlert,
  Building2,
  User,
  Zap,
} from 'lucide-react';
import { extractWardName, extractZoneName } from '../utils/coordinates';

export const getCitizenStatusMessage = (status: ComplaintStatus): string => {
  switch (status) {
    case 'REPORTED':
      return 'Your complaint has been received.';
    case 'TRIAGED':
      return 'Your complaint has been reviewed by the municipal team.';
    case 'ASSIGNED':
      return 'A field specialist has been assigned.';
    case 'IN PROGRESS':
      return 'Work is currently underway.';
    case 'RESOLUTION SUBMITTED':
      return 'Resolution evidence has been submitted.';
    case 'AWAITING VERIFICATION':
      return 'Please verify whether the issue has been resolved.';
    case 'VERIFIED':
      return 'You verified the resolution.';
    case 'CLOSED':
    case 'VERIFIED / CLOSED':
      return 'Complaint successfully closed.';
    case 'REOPENED':
      return 'You reported that the issue was not fully resolved. Municipal action is required again.';
    default:
      return 'Complaint is currently in the municipal workflow.';
  }
};

export const TrackComplaintView: React.FC<{
  onSelectComplaint: (complaint: Complaint) => void;
}> = ({ onSelectComplaint }) => {
  const { complaints, selectedComplaintId } = useCivic();
  const [trackInput, setTrackInput] = useState(selectedComplaintId || '');
  const [searchedComplaint, setSearchedComplaint] = useState<Complaint | null>(null);
  const [hasSearched, setHasSearched] = useState(false);

  useEffect(() => {
    if (selectedComplaintId) {
      setTrackInput(selectedComplaintId);
      const found = complaints.find((c) => c.id.toLowerCase() === selectedComplaintId.toLowerCase());
      setSearchedComplaint(found || null);
      setHasSearched(true);
    }
  }, [selectedComplaintId, complaints]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!trackInput.trim()) return;

    const trimmed = trackInput.trim().toUpperCase();
    const found = complaints.find(
      (c) =>
        c.id.toUpperCase() === trimmed ||
        c.id.toUpperCase().includes(trimmed)
    );
    setSearchedComplaint(found || null);
    setHasSearched(true);
  };

  const isAwaitingVerification =
    searchedComplaint &&
    (searchedComplaint.status === 'AWAITING VERIFICATION' ||
      searchedComplaint.status === 'RESOLUTION SUBMITTED');

  const isClosed =
    searchedComplaint &&
    (searchedComplaint.status === 'CLOSED' ||
      searchedComplaint.status === 'VERIFIED / CLOSED');

  const isReopened = searchedComplaint && searchedComplaint.status === 'REOPENED';

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Search Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm">
        <div className="max-w-xl mx-auto text-center mb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-semibold mb-2">
            <Search className="w-3.5 h-3.5" />
            <span>Real-Time Citizen Tracking</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900">Track Your Civic Complaint</h1>
          <p className="text-xs text-slate-500 mt-1">
            Enter your unique Complaint ID (e.g. <span className="font-mono font-bold text-slate-700">CP-2026-1042</span>) to see live progress and verified resolution proof.
          </p>
        </div>

        <form onSubmit={handleSearch} className="max-w-md mx-auto flex gap-2">
          <div className="relative flex-1">
            <input
              type="text"
              value={trackInput}
              onChange={(e) => setTrackInput(e.target.value)}
              placeholder="e.g. CP-2026-1042"
              className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-300 text-sm font-mono text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-inner"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
          </div>
          <button
            type="submit"
            className="px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm shadow-md transition-all shrink-0"
          >
            Track Status
          </button>
        </form>

        {/* Quick sample chips */}
        <div className="mt-4 text-center">
          <span className="text-[11px] text-slate-400 mr-2">Try quick demo IDs:</span>
          <div className="inline-flex flex-wrap gap-1.5 justify-center mt-1">
            {complaints.slice(0, 5).map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => {
                  setTrackInput(c.id);
                  setSearchedComplaint(c);
                  setHasSearched(true);
                }}
                className="font-mono text-xs px-2.5 py-1 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium transition-colors"
              >
                {c.id}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Result Display */}
      {hasSearched && (
        <div>
          {searchedComplaint ? (
            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-md space-y-0">
              <div className="bg-[#0F1E36] text-white p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <div className="flex flex-wrap items-center gap-3 mb-1">
                    <span className="font-mono text-sm font-bold text-emerald-400 bg-slate-800 px-3 py-1 rounded">
                      {searchedComplaint.id}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-medium text-xs">
                      {searchedComplaint.ward || extractWardName(searchedComplaint.location)} • {searchedComplaint.zone || extractZoneName(searchedComplaint.location)}
                    </span>
                    {searchedComplaint.isEscalated && (
                      <span className="px-2 py-0.5 rounded bg-purple-600 text-white font-bold text-xs uppercase tracking-wider flex items-center gap-1">
                        <Zap className="w-3 h-3" /> ESCALATED
                      </span>
                    )}
                    <StatusBadge status={searchedComplaint.status} size="md" />
                    <PriorityBadge priority={searchedComplaint.priority} />
                    <SlaBadge deadline={searchedComplaint.deadline} />
                  </div>
                  <h2 className="text-xl font-bold text-white mt-2">{searchedComplaint.title}</h2>
                </div>

                <button
                  onClick={() => onSelectComplaint(searchedComplaint)}
                  className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shrink-0 hover:scale-[1.02] transition-transform"
                >
                  <span>Open Full Details & Evidence</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Citizen Accountability Alert Banners */}
              {isAwaitingVerification && (
                <div className="bg-amber-50 border-b-2 border-amber-300 p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5 shrink-0" />
                    <div>
                      <h3 className="text-sm font-bold text-amber-950">
                        Resolution submitted — your verification is required.
                      </h3>
                      <p className="text-xs text-amber-900 mt-0.5">
                        Please verify whether the issue has been resolved on-site or request a reopening.
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => onSelectComplaint(searchedComplaint)}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-sm shrink-0"
                  >
                    Verify or Reopen Now →
                  </button>
                </div>
              )}

              {isClosed && (
                <div className="bg-emerald-50 border-b border-emerald-200 p-4 flex items-center gap-3 text-emerald-950">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  <div className="flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-bold text-xs uppercase tracking-wider text-emerald-800">
                        Complaint Closed — Citizen Verified
                      </span>
                      <span className="text-[11px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded font-semibold">
                        ✓ Resolution Completed
                      </span>
                    </div>
                    <p className="text-xs text-emerald-900 mt-0.5">
                      Citizen confirmed resolution.{' '}
                      {searchedComplaint.citizenVerificationNote &&
                        `"${searchedComplaint.citizenVerificationNote}"`}
                    </p>
                  </div>
                </div>
              )}

              {isReopened && (
                <div className="bg-rose-50 border-b border-rose-200 p-4 flex items-start gap-3 text-rose-950">
                  <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-xs uppercase tracking-wider text-rose-800 block">
                      Reopened by Citizen
                    </span>
                    <p className="text-xs text-rose-900 mt-0.5 font-medium">
                      You reported that the issue was not fully resolved. Municipal action is required again.
                    </p>
                    <p className="text-xs text-rose-800 italic mt-1 bg-white/80 p-2 rounded border border-rose-200">
                      Reason: "{searchedComplaint.reopenReason}"
                    </p>
                  </div>
                </div>
              )}

              <div className="p-6 space-y-6">
                {/* 10. Dedicated Citizen Status Message */}
                <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center shrink-0 mt-0.5">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
                      Current Complaint State
                    </div>
                    <div className="text-sm font-bold text-slate-900 mt-0.5">
                      {getCitizenStatusMessage(searchedComplaint.status)}
                    </div>
                    <div className="text-xs text-slate-500 mt-1">
                      {searchedComplaint.timeline[searchedComplaint.timeline.length - 1]?.comment ||
                        'Complaint is currently recorded in the municipal ledger.'}
                    </div>
                    <span className="text-[11px] text-slate-400 mt-1 block">
                      Last updated {new Date(searchedComplaint.updatedAt).toLocaleString()}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs bg-white p-4 rounded-xl border border-slate-200">
                  <div>
                    <span className="text-slate-400 block mb-0.5">Category:</span>
                    <span className="font-semibold text-slate-800">{searchedComplaint.category}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block mb-0.5">Location:</span>
                    <span className="font-semibold text-slate-800">{searchedComplaint.location}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block mb-0.5">Department:</span>
                    <span className="font-semibold text-slate-800">
                      {searchedComplaint.department || searchedComplaint.assignedDepartment || 'Pending Triage'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block mb-0.5">Assigned Specialist:</span>
                    <span className="font-semibold text-slate-800">
                      {searchedComplaint.assignedWorker || 'Pending Assignment'}
                    </span>
                  </div>
                </div>

                {/* Resolution proof snippet if available */}
                {searchedComplaint.evidence && (
                  <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/70">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <FileCheck className="w-4 h-4 text-emerald-700" />
                        <span className="text-xs font-bold text-emerald-950 uppercase">
                          Work Resolution Evidence Logged
                        </span>
                      </div>
                      <span className="text-[11px] text-emerald-700">
                        By {searchedComplaint.evidence.submittedBy}
                      </span>
                    </div>
                    <p className="text-xs text-emerald-900 mb-3">
                      "{searchedComplaint.evidence.workerNotes || searchedComplaint.evidence.resolutionDescription}"
                    </p>
                    <button
                      onClick={() => onSelectComplaint(searchedComplaint)}
                      className="text-xs font-bold text-emerald-700 hover:text-emerald-900 underline flex items-center gap-1"
                    >
                      Inspect before/after evidence photos & full details →
                    </button>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-600">
              <AlertCircle className="w-10 h-10 text-amber-500 mx-auto mb-2" />
              <h3 className="text-base font-bold text-slate-900">Complaint Not Found</h3>
              <p className="text-xs text-slate-500 mt-1">
                No complaint matches "{trackInput}". Please check the ID or search from your citizen dashboard.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
