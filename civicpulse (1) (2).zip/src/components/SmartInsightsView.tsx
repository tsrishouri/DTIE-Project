import React from 'react';
import { Complaint, ComplaintCategory } from '../types';
import {
  calculateWardHotspots,
  calculateBottlenecks,
  calculateDepartmentPerformance,
  calculateCategoryBreakdown,
  calculateKpis,
} from '../utils/analytics';
import {
  BrainCircuit,
  Flame,
  AlertTriangle,
  TrendingUp,
  Clock,
  ShieldAlert,
  Building2,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  Zap,
} from 'lucide-react';

interface SmartInsightsViewProps {
  complaints: Complaint[];
  onSelectComplaint?: (complaint: Complaint) => void;
}

export const SmartInsightsView: React.FC<SmartInsightsViewProps> = ({
  complaints,
  onSelectComplaint,
}) => {
  const kpis = calculateKpis(complaints);
  const hotspots = calculateWardHotspots(complaints);
  const bottlenecks = calculateBottlenecks(complaints);
  const deptPerformance = calculateDepartmentPerformance(complaints);
  const categoryBreakdown = calculateCategoryBreakdown(complaints);

  // Top category
  const topCategory = [...categoryBreakdown].sort((a, b) => b.total - a.total)[0];

  // Reopened complaints analysis
  const reopenedComplaints = complaints.filter((c) => c.status === 'REOPENED');

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-2xl p-6 border border-indigo-900/40 shadow-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-semibold mb-2 border border-indigo-500/30">
            <BrainCircuit className="w-3.5 h-3.5" />
            <span>Automated Operational Intelligence</span>
          </div>
          <h3 className="text-xl font-extrabold text-white">Smart Civic Insights</h3>
          <p className="text-xs text-indigo-200 mt-1 max-w-2xl">
            Heuristic pattern detection analyzing complaint clustering, stage latency bottlenecks, department dispatch velocity, and citizen verification risks.
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-sm border border-white/15 px-4 py-2.5 rounded-xl text-right shrink-0">
          <span className="text-[10px] uppercase font-bold text-indigo-300 block">Analysis Sample</span>
          <span className="text-xl font-extrabold text-white">{complaints.length} Live Records</span>
        </div>
      </div>

      {/* Grid: Hotspots + Bottleneck Diagnosis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 1. Hotspot Detection & Geographic Clustering */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center font-bold">
                <Flame className="w-4 h-4 text-rose-600" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900">Geographic Hotspot Analysis</h4>
                <p className="text-[11px] text-slate-500">Wards with highest complaint density & open defects</p>
              </div>
            </div>
            <span className="text-xs font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
              {hotspots.length} Zones Tracked
            </span>
          </div>

          {hotspots.length === 0 ? (
            <p className="text-xs text-slate-400 py-6 text-center">No complaints recorded yet.</p>
          ) : (
            <div className="space-y-3">
              {hotspots.slice(0, 4).map((h, idx) => (
                <div
                  key={h.wardName}
                  className="p-3 rounded-xl bg-slate-50 border border-slate-200 hover:border-slate-300 transition-all text-xs space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 font-bold text-[10px] flex items-center justify-center">
                        #{idx + 1}
                      </span>
                      <span className="font-bold text-slate-900">{h.wardName}</span>
                    </div>
                    <span className="font-mono font-bold text-slate-700 bg-white px-2 py-0.5 rounded border border-slate-200">
                      {h.totalIssues} issue{h.totalIssues > 1 ? 's' : ''} ({h.activeIssues} active)
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
                    <span>
                      Primary defect: <strong className="text-slate-800">{h.dominantCategory}</strong>
                    </span>
                    {h.reopenedIssues > 0 && (
                      <span className="text-rose-700 font-bold bg-rose-100 px-1.5 py-0.5 rounded">
                        ⚠ {h.reopenedIssues} Reopened
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Dispatcher Actionable Recommendation */}
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs text-amber-900 flex items-start gap-2.5">
            <Zap className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <strong className="block text-amber-950 font-bold">Recommended Operational Dispatch:</strong>
              <span>
                {topCategory
                  ? `High volume of ${topCategory.category} issues detected. Prioritize mobilizing dedicated repair crew with pre-stocked replacement materials to minimize round-trip logistics.`
                  : 'Monitor incoming reports for geographic clustering.'}
              </span>
            </div>
          </div>
        </div>

        {/* 2. Operational Bottlenecks Diagnosis */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
                <Clock className="w-4 h-4 text-blue-600" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900">Operational Bottleneck Diagnosis</h4>
                <p className="text-[11px] text-slate-500">Average duration across the 4 key execution stages</p>
              </div>
            </div>
            <span className="text-xs font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
              Avg: {kpis.avgResolutionFormatted}
            </span>
          </div>

          <div className="space-y-3.5">
            {bottlenecks.map((b) => {
              const maxHours = Math.max(...bottlenecks.map((x) => x.avgHours), 1);
              const widthPct = Math.min(100, Math.round((b.avgHours / maxHours) * 100));

              return (
                <div key={b.stage} className="space-y-1 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-800">{b.stage}</span>
                    <span className="font-mono font-bold text-slate-900">{b.avgHours} hrs</span>
                  </div>

                  {/* Latency Progress Bar */}
                  <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        b.severity === 'high'
                          ? 'bg-rose-500'
                          : b.severity === 'medium'
                          ? 'bg-amber-500'
                          : 'bg-emerald-500'
                      }`}
                      style={{ width: `${widthPct}%` }}
                    />
                  </div>

                  <p className="text-[11px] text-slate-500">{b.insight}</p>
                </div>
              );
            })}
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-xs text-blue-900 flex items-start gap-2.5">
            <Sparkles className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <div>
              <strong className="block text-blue-950 font-bold">Pipeline Optimization Note:</strong>
              <span>
                Field execution represents the largest duration fraction. Pre-authorizing parts replacement for high-frequency categories reduces mean resolution time by ~35%.
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Grid: Department Accountability Leaderboard + Reopen Risk Detection */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Department Leaderboard (2 cols) */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 shadow-sm p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <Building2 className="w-5 h-5 text-slate-700" />
              <div>
                <h4 className="text-sm font-bold text-slate-900">Department Accountability Leaderboard</h4>
                <p className="text-[11px] text-slate-500">Resolution throughput, backlog, and SLA compliance</p>
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 text-slate-700 font-bold uppercase text-[10px] border-b border-slate-200">
                <tr>
                  <th className="px-3 py-2.5">Department</th>
                  <th className="px-3 py-2.5 text-center">Total</th>
                  <th className="px-3 py-2.5 text-center">Active</th>
                  <th className="px-3 py-2.5 text-center">Resolved</th>
                  <th className="px-3 py-2.5 text-center">Avg Time</th>
                  <th className="px-3 py-2.5 text-right">SLA Adherence</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {deptPerformance.map((dept) => (
                  <tr key={dept.department} className="hover:bg-slate-50/80">
                    <td className="px-3 py-2.5 font-bold text-slate-900">{dept.department}</td>
                    <td className="px-3 py-2.5 text-center font-mono text-slate-700">{dept.totalAssigned}</td>
                    <td className="px-3 py-2.5 text-center font-mono text-amber-700">{dept.inProgress}</td>
                    <td className="px-3 py-2.5 text-center font-mono text-emerald-700">{dept.resolved}</td>
                    <td className="px-3 py-2.5 text-center text-slate-600">
                      {dept.avgHours !== null ? `${dept.avgHours}h` : '—'}
                    </td>
                    <td className="px-3 py-2.5 text-right">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold ${
                          dept.slaCompliance >= 90
                            ? 'bg-emerald-100 text-emerald-800'
                            : dept.slaCompliance >= 75
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {dept.slaCompliance}%
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Reopen Risk & Citizen Quality Gate (1 col) */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <ShieldAlert className="w-5 h-5 text-rose-600" />
            <div>
              <h4 className="text-sm font-bold text-slate-900">Reopen Quality Sentinel</h4>
              <p className="text-[11px] text-slate-500">Citizen resolution rejection monitor</p>
            </div>
          </div>

          {reopenedComplaints.length === 0 ? (
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 text-center space-y-2">
              <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
              <h5 className="text-xs font-bold text-emerald-950">Zero Active Reopenings</h5>
              <p className="text-[11px] text-emerald-800">
                100% of evaluated field resolutions have met citizen satisfaction without rejection.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs space-y-2">
                <div className="flex items-center justify-between text-rose-900 font-bold">
                  <span>{reopenedComplaints.length} Reopened Issue{reopenedComplaints.length > 1 ? 's' : ''}</span>
                  <span className="bg-rose-200 text-rose-900 px-2 py-0.5 rounded text-[10px]">Action Required</span>
                </div>
                <p className="text-[11px] text-rose-800">
                  Citizens flagged that repairs were incomplete or surface-level.
                </p>
              </div>

              {reopenedComplaints.map((c) => (
                <div
                  key={c.id}
                  onClick={() => onSelectComplaint && onSelectComplaint(c)}
                  className="p-3 rounded-xl border border-slate-200 hover:border-rose-300 hover:bg-rose-50/30 cursor-pointer transition-all text-xs space-y-1"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-slate-800">{c.id}</span>
                    <span className="text-[10px] font-semibold text-rose-700 bg-rose-100 px-1.5 py-0.5 rounded">
                      {c.category}
                    </span>
                  </div>
                  <p className="text-slate-700 font-medium truncate">{c.title}</p>
                  <p className="text-[11px] text-rose-800 italic line-clamp-2">
                    "{c.reopenReason}"
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
