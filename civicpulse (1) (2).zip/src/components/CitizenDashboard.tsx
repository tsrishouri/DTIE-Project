import React, { useMemo } from 'react';
import { useCivic } from '../context/CivicContext';
import { ComplaintCategory, Complaint } from '../types';
import { StatusBadge, PriorityBadge, SlaBadge } from './StatusBadge';
import {
  Search,
  PlusCircle,
  MapPin,
  Calendar,
  AlertCircle,
  CheckCircle2,
  Clock,
  ShieldCheck,
  ChevronRight,
  Filter,
  FileCheck,
  RotateCcw,
  Activity,
  Layers,
} from 'lucide-react';
import { extractWardName } from '../utils/coordinates';

const CATEGORIES: ('ALL' | ComplaintCategory)[] = [
  'ALL',
  'Roads',
  'Street Lights',
  'Water Supply',
  'Garbage',
  'Drainage',
  'Public Safety',
  'Other',
];

export const CitizenDashboard: React.FC<{
  onSelectComplaint: (complaint: Complaint) => void;
}> = ({ onSelectComplaint }) => {
  const {
    complaints,
    setActiveView,
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    selectedStatus,
    setSelectedStatus,
  } = useCivic();

  // 13. Dynamic metrics calculated from actual complaint data
  const stats = useMemo(() => {
    const totalReports = complaints.length;
    const activeIssues = complaints.filter(
      (c) =>
        c.status === 'REPORTED' ||
        c.status === 'TRIAGED' ||
        c.status === 'ASSIGNED' ||
        c.status === 'IN PROGRESS' ||
        c.status === 'REOPENED'
    ).length;
    const awaitingVerification = complaints.filter(
      (c) => c.status === 'AWAITING VERIFICATION' || c.status === 'RESOLUTION SUBMITTED'
    ).length;
    const resolved = complaints.filter(
      (c) =>
        c.status === 'CLOSED' ||
        c.status === 'VERIFIED / CLOSED' ||
        c.status === 'VERIFIED'
    ).length;

    return {
      totalReports,
      activeIssues,
      awaitingVerification,
      resolved,
    };
  }, [complaints]);

  const awaitingVerificationList = complaints.filter(
    (c) => c.status === 'AWAITING VERIFICATION' || c.status === 'RESOLUTION SUBMITTED'
  );

  const filteredComplaints = complaints.filter((c) => {
    const matchesSearch =
      searchQuery === '' ||
      c.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.location.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory =
      selectedCategory === 'ALL' || c.category === selectedCategory;

    let matchesStatus = true;
    if (selectedStatus === 'ACTIVE') {
      matchesStatus =
        c.status === 'REPORTED' ||
        c.status === 'TRIAGED' ||
        c.status === 'ASSIGNED' ||
        c.status === 'IN PROGRESS' ||
        c.status === 'REOPENED';
    } else if (selectedStatus === 'RESOLVED') {
      matchesStatus =
        c.status === 'CLOSED' ||
        c.status === 'VERIFIED / CLOSED' ||
        c.status === 'VERIFIED';
    } else if (selectedStatus !== 'ALL') {
      matchesStatus = c.status === selectedStatus;
    }

    return matchesSearch && matchesCategory && matchesStatus;
  });

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Hero Action Card */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-slate-800 to-teal-950 text-white p-6 sm:p-10 shadow-xl border border-slate-700/60">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-semibold mb-4 border border-emerald-500/30">
            <ShieldCheck className="w-4 h-4" />
            <span>Civic Transparency & Verified Resolutions</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight leading-tight">
            Report Civic Issues. <br className="hidden sm:inline" />
            Track Resolution to Verified Closure.
          </h1>
          <p className="mt-3 text-slate-300 text-sm sm:text-base leading-relaxed">
            From damaged roads to failed street lights and water leaks — report neighborhood problems directly to municipal field teams and inspect proof before closing the ticket.
          </p>

          <div className="mt-6 flex flex-wrap gap-3">
            <button
              onClick={() => setActiveView('report')}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm shadow-lg shadow-emerald-900/40 transition-all hover:scale-[1.02]"
            >
              <PlusCircle className="w-5 h-5" />
              <span>Report Issue (Voice + GPS)</span>
            </button>

            <button
              onClick={() => setActiveView('track')}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-sm border border-slate-600/80 transition-all"
            >
              <Search className="w-5 h-5" />
              <span>Track Complaint ID</span>
            </button>
          </div>
        </div>
      </div>

      {/* 13. Dynamic Citizen Dashboard Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Reports */}
        <button
          onClick={() => setSelectedStatus('ALL')}
          className={`p-4 rounded-2xl border text-left transition-all ${
            selectedStatus === 'ALL'
              ? 'bg-white border-blue-500 shadow-md ring-2 ring-blue-500/30'
              : 'bg-white border-slate-200 hover:border-slate-300 shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Total Reports</span>
            <Layers className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-900">{stats.totalReports}</div>
          <p className="text-[11px] text-slate-500 mt-1">All civic complaints lodged</p>
        </button>

        {/* Active Issues */}
        <button
          onClick={() => setSelectedStatus('ACTIVE')}
          className={`p-4 rounded-2xl border text-left transition-all ${
            selectedStatus === 'ACTIVE'
              ? 'bg-white border-amber-500 shadow-md ring-2 ring-amber-500/30'
              : 'bg-white border-slate-200 hover:border-slate-300 shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-800">Active Issues</span>
            <Activity className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-amber-900">{stats.activeIssues}</div>
          <p className="text-[11px] text-amber-700/80 mt-1">In triage or field execution</p>
        </button>

        {/* Awaiting Verification */}
        <button
          onClick={() => setSelectedStatus('AWAITING VERIFICATION')}
          className={`p-4 rounded-2xl border text-left transition-all ${
            selectedStatus === 'AWAITING VERIFICATION'
              ? 'bg-amber-50 border-amber-500 shadow-md ring-2 ring-amber-500/30'
              : stats.awaitingVerification > 0
              ? 'bg-amber-50/70 border-amber-300 hover:border-amber-400 shadow-xs'
              : 'bg-white border-slate-200 hover:border-slate-300 shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-orange-800">
              Awaiting Verification
            </span>
            <AlertCircle className="w-4 h-4 text-orange-600 animate-pulse" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-orange-950">
            {stats.awaitingVerification}
          </div>
          <p className="text-[11px] text-orange-800/80 mt-1">Requires resident review</p>
        </button>

        {/* Resolved */}
        <button
          onClick={() => setSelectedStatus('RESOLVED')}
          className={`p-4 rounded-2xl border text-left transition-all ${
            selectedStatus === 'RESOLVED'
              ? 'bg-white border-emerald-500 shadow-md ring-2 ring-emerald-500/30'
              : 'bg-white border-slate-200 hover:border-slate-300 shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-800">Resolved</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-emerald-900">{stats.resolved}</div>
          <p className="text-[11px] text-emerald-700/80 mt-1">Citizen verified & closed</p>
        </button>
      </div>

      {/* Awaiting Citizen Verification Alert Banner */}
      {awaitingVerificationList.length > 0 && (
        <div className="rounded-2xl bg-amber-50 border-2 border-amber-300 p-5 shadow-sm">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
                <AlertCircle className="w-6 h-6 animate-pulse text-amber-700" />
              </div>
              <div>
                <h3 className="text-base font-bold text-amber-950">
                  {awaitingVerificationList.length} Resolved Issue{awaitingVerificationList.length > 1 ? 's' : ''} Awaiting Your Verification
                </h3>
                <p className="text-xs text-amber-800 mt-0.5">
                  Field workers have submitted fix evidence. Confirm on-site resolution or reopen if the defect persists.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {awaitingVerificationList.slice(0, 2).map((item) => (
                <button
                  key={item.id}
                  onClick={() => onSelectComplaint(item)}
                  className="px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-sm transition-all flex items-center gap-1.5"
                >
                  <span>Review {item.id}</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 space-y-4">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          {/* Search box */}
          <div className="relative w-full sm:w-96">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by Complaint ID (e.g. CP-2026-1042) or keyword..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-inner"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          </div>

          {/* Quick counts */}
          <div className="flex items-center gap-2 text-xs text-slate-600 font-medium">
            <span>Showing: <strong className="text-slate-900">{filteredComplaints.length}</strong> complaints</span>
            {selectedStatus !== 'ALL' && (
              <button
                onClick={() => setSelectedStatus('ALL')}
                className="text-[11px] text-blue-600 hover:underline font-semibold ml-2"
              >
                Clear status filter
              </button>
            )}
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          <span className="text-xs font-semibold text-slate-500 mr-1 shrink-0 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" /> Category:
          </span>
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-slate-900 text-white shadow-sm font-semibold'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Complaints Grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-slate-900">Community Complaint Ledger</h2>
          <span className="text-xs text-slate-500">
            Click any ticket to inspect timeline & resolution evidence
          </span>
        </div>

        {filteredComplaints.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
            <Clock className="w-12 h-12 text-slate-400 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-800">No matching civic complaints found</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              Try adjusting your search terms or filter settings, or report a new civic issue.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('ALL');
                setSelectedStatus('ALL');
              }}
              className="mt-4 px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold"
            >
              Clear Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredComplaints.map((complaint) => {
              const isAwaiting =
                complaint.status === 'AWAITING VERIFICATION' ||
                complaint.status === 'RESOLUTION SUBMITTED';
              const isReopenedTicket = complaint.status === 'REOPENED';
              const isClosedTicket =
                complaint.status === 'CLOSED' ||
                complaint.status === 'VERIFIED / CLOSED';

              return (
                <div
                  key={complaint.id}
                  onClick={() => onSelectComplaint(complaint)}
                  className={`bg-white rounded-2xl border transition-all hover:shadow-lg cursor-pointer flex flex-col overflow-hidden group ${
                    isAwaiting
                      ? 'border-amber-400 ring-2 ring-amber-300/40 bg-amber-50/10'
                      : isReopenedTicket
                      ? 'border-rose-300 ring-1 ring-rose-200'
                      : isClosedTicket
                      ? 'border-emerald-200/90'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  {/* Card photo or category banner */}
                  <div className="relative h-44 bg-slate-100 overflow-hidden">
                    {complaint.photoUrl ? (
                      <img
                        src={complaint.photoUrl}
                        alt={complaint.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-slate-400 text-xs">
                        No photo attached
                      </div>
                    )}
                    <div className="absolute top-3 left-3 flex flex-wrap items-center gap-1.5">
                      <span className="font-mono text-xs font-bold px-2.5 py-1 rounded-md bg-black/75 text-white backdrop-blur-xs">
                        {complaint.id}
                      </span>
                      <PriorityBadge priority={complaint.priority} />
                    </div>

                    <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
                      <span className="text-xs font-bold text-white bg-black/60 px-2 py-0.5 rounded backdrop-blur-xs">
                        {complaint.category}
                      </span>
                      <SlaBadge deadline={complaint.deadline} />
                    </div>
                  </div>

                  {/* Card body */}
                  <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <StatusBadge status={complaint.status} size="sm" />
                        <span className="text-[11px] text-slate-400">
                          {new Date(complaint.createdAt).toLocaleDateString()}
                        </span>
                      </div>

                      <h3 className="font-bold text-slate-900 text-sm sm:text-base leading-snug line-clamp-2 group-hover:text-emerald-700 transition-colors">
                        {complaint.title}
                      </h3>

                      <p className="text-xs text-slate-600 mt-2 line-clamp-2 leading-relaxed">
                        {complaint.description}
                      </p>
                    </div>

                    <div className="space-y-3 pt-3 border-t border-slate-100">
                      <div className="flex items-center justify-between text-xs text-slate-500">
                        <div className="flex items-center gap-1.5 truncate">
                          <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span className="truncate">{complaint.location}</span>
                        </div>
                        <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 font-semibold text-[10px] shrink-0">
                          {complaint.ward || extractWardName(complaint.location)}
                        </span>
                      </div>

                      {/* Prominent Verification Callout */}
                      {isAwaiting && (
                        <div className="bg-amber-100/70 border border-amber-300 rounded-xl p-2.5 flex items-center justify-between text-xs text-amber-950 font-bold">
                          <span className="flex items-center gap-1.5">
                            <AlertCircle className="w-4 h-4 text-amber-700 shrink-0" />
                            <span>Verification Required</span>
                          </span>
                          <span className="text-[11px] text-amber-800 underline">Review proof →</span>
                        </div>
                      )}

                      {/* Reopened Callout */}
                      {isReopenedTicket && (
                        <div className="bg-rose-100/70 border border-rose-300 rounded-xl p-2.5 flex items-center justify-between text-xs text-rose-950 font-bold">
                          <span className="flex items-center gap-1.5">
                            <RotateCcw className="w-4 h-4 text-rose-700 shrink-0" />
                            <span>Reopened by Citizen</span>
                          </span>
                          <span className="text-[11px] text-rose-800 underline">Details →</span>
                        </div>
                      )}

                      {/* Closed Callout */}
                      {isClosedTicket && (
                        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-2 flex items-center justify-between text-xs text-emerald-900 font-semibold">
                          <span className="flex items-center gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            <span>Citizen Verified & Closed</span>
                          </span>
                        </div>
                      )}

                      <div className="flex items-center justify-between text-xs pt-1">
                        <span className="text-slate-400">
                          {complaint.timeline.length} lifecycle log{complaint.timeline.length > 1 ? 's' : ''}
                        </span>
                        <span className="text-emerald-700 font-bold group-hover:translate-x-0.5 transition-transform flex items-center gap-0.5">
                          <span>Inspect</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
