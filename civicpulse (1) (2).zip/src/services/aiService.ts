import {
  Complaint,
  ComplaintCategory,
  PriorityLevel,
  MunicipalDepartment,
  AiTriageSuggestion,
  DuplicateMatchResult,
} from '../types';

/**
 * Service abstraction for CivicPulse AI Assistance:
 * - AI Civic Triage Assistance (Category, Severity, Department, SLA recommendation)
 * - Duplicate Similarity Detection
 * - Human-in-the-loop review guardrails
 */

interface KeywordPattern {
  keywords: string[];
  category: ComplaintCategory;
  department: MunicipalDepartment;
  severityBoost?: PriorityLevel;
  slaHours: number;
}

const CATEGORY_PATTERNS: KeywordPattern[] = [
  {
    category: 'Roads',
    department: 'Road Maintenance',
    keywords: [
      'pothole',
      'asphalt',
      'road',
      'crater',
      'pavement',
      'curb',
      'crack',
      'resurfacing',
      'trench',
      'ditch',
      'tar',
      'speed breaker',
      'manhole edge',
      'road depression',
      'axle',
      'skid',
    ],
    slaHours: 24,
  },
  {
    category: 'Street Lights',
    department: 'Street Lighting',
    keywords: [
      'light',
      'lamp',
      'bulb',
      'pole',
      'dark',
      'darkness',
      'streetlight',
      'blackout',
      'illumination',
      'flicker',
      'wiring',
      'luminaire',
      'fixture',
      'street lamp',
      'night visibility',
    ],
    slaHours: 24,
  },
  {
    category: 'Water Supply',
    department: 'Water Supply',
    keywords: [
      'water',
      'pipeline',
      'pipe',
      'burst',
      'leak',
      'drinking water',
      'valve',
      'meter',
      'pressure',
      'main line',
      'rupture',
      'contamination',
      'tap',
      'submerged pipe',
    ],
    slaHours: 12,
  },
  {
    category: 'Garbage',
    department: 'Sanitation',
    keywords: [
      'garbage',
      'trash',
      'waste',
      'debris',
      'dump',
      'bin',
      'dumpster',
      'litter',
      'refuse',
      'overflowing',
      'stench',
      'smell',
      'rotten',
      'sanitation',
      'compactor',
    ],
    slaHours: 24,
  },
  {
    category: 'Drainage',
    department: 'Drainage',
    keywords: [
      'drain',
      'drainage',
      'sewer',
      'stormwater',
      'culvert',
      'clogging',
      'clogged',
      'overflowing drain',
      'rainwater',
      'sewage backup',
      'gutter',
      'manhole overflow',
      'stagnant water',
    ],
    slaHours: 24,
  },
  {
    category: 'Public Safety',
    department: 'Public Safety',
    keywords: [
      'hazard',
      'safety',
      'barrier',
      'live wire',
      'electrocution',
      'collapsed',
      'danger',
      'accident',
      'emergency',
      'open manhole',
      'fallen tree',
      'exposed wire',
      'fire hazard',
      'deep pit',
      'structural crack',
    ],
    severityBoost: 'CRITICAL',
    slaHours: 4,
  },
];

const CRITICAL_KEYWORDS = [
  'live wire',
  'electrocution',
  'pipe burst',
  'ruptured',
  'open manhole',
  'collapsed',
  'deep trench',
  'school zone',
  'hospital',
  'fire',
  'emergency',
  'severe hazard',
  'falling',
  'death',
  'danger to life',
];

const HIGH_KEYWORDS = [
  'flooding',
  'large pothole',
  'blackout',
  'skid',
  'heavy traffic',
  'overflowing sewage',
  'accident risk',
  'urgent',
  'hazard',
  'broken pole',
  'major',
];

const LOW_KEYWORDS = [
  'minor',
  'small',
  'paint',
  'cosmetic',
  'faint',
  'slight',
  'request',
  'inquiry',
  'cleaning needed',
];

export class AiTriageService {
  /**
   * Generates AI suggestions for Category, Severity, Department, SLA and explainability factors.
   * Uses Gemini API when an API key is configured; otherwise provides an instant, high-precision
   * deterministic civic triage copilot.
   */
  async suggestTriage(
    title: string,
    description: string,
    location?: string
  ): Promise<AiTriageSuggestion> {
    const combinedText = `${title} ${description} ${location || ''}`.toLowerCase();
    const analyzedAt = new Date().toISOString();

    // Try Gemini API if key is present
    const geminiKey =
      (typeof import.meta !== 'undefined' && import.meta.env?.VITE_GEMINI_API_KEY) ||
      (typeof process !== 'undefined' && process.env?.VITE_GEMINI_API_KEY);

    if (geminiKey && geminiKey.length > 10) {
      try {
        const result = await this.callGeminiModel(geminiKey, title, description, location);
        if (result) return result;
      } catch (err) {
        console.warn('Gemini API call failed, falling back to deterministic copilot:', err);
      }
    }

    // High-precision Deterministic Triage Engine (Honest labeling)
    return this.runDeterministicTriage(combinedText, title, description, location, analyzedAt);
  }

  private runDeterministicTriage(
    combinedText: string,
    title: string,
    description: string,
    location?: string,
    analyzedAt: string = new Date().toISOString()
  ): AiTriageSuggestion {
    let topCategory: ComplaintCategory = 'Roads';
    let topDepartment: MunicipalDepartment = 'Road Maintenance';
    let maxMatchCount = 0;
    const detectedFactors: string[] = [];

    // Category detection
    for (const pattern of CATEGORY_PATTERNS) {
      const matched = pattern.keywords.filter((kw) => combinedText.includes(kw));
      if (matched.length > maxMatchCount) {
        maxMatchCount = matched.length;
        topCategory = pattern.category;
        topDepartment = pattern.department;
        detectedFactors.push(`Matched ${matched.length} domain keywords: "${matched.slice(0, 3).join('", "')}"`);
      }
    }

    if (maxMatchCount === 0) {
      topCategory = 'Other';
      topDepartment = 'General Services';
      detectedFactors.push('No specific domain keywords; categorized under general civic services');
    }

    // Severity / Priority detection
    let suggestedPriority: PriorityLevel = 'MEDIUM';
    let recommendedSla = 24;

    const criticalMatches = CRITICAL_KEYWORDS.filter((kw) => combinedText.includes(kw));
    const highMatches = HIGH_KEYWORDS.filter((kw) => combinedText.includes(kw));
    const lowMatches = LOW_KEYWORDS.filter((kw) => combinedText.includes(kw));

    if (criticalMatches.length > 0) {
      suggestedPriority = 'CRITICAL';
      recommendedSla = 4;
      detectedFactors.push(`Critical safety triggers detected: "${criticalMatches.slice(0, 2).join('", "')}"`);
    } else if (highMatches.length > 0 || maxMatchCount >= 3) {
      suggestedPriority = 'HIGH';
      recommendedSla = 12;
      detectedFactors.push(`High urgency factor: "${highMatches.slice(0, 2).join('", "') || 'Multiple problem indicators'}"`);
    } else if (lowMatches.length > 0 && highMatches.length === 0) {
      suggestedPriority = 'LOW';
      recommendedSla = 48;
      detectedFactors.push('Minor impact classification based on descriptive text');
    } else {
      suggestedPriority = 'MEDIUM';
      recommendedSla = 24;
      detectedFactors.push('Standard priority level: non-acute municipal maintenance');
    }

    // School zone or Hospital proximity bump
    if (combinedText.includes('school') || combinedText.includes('hospital')) {
      if (suggestedPriority === 'MEDIUM') suggestedPriority = 'HIGH';
      detectedFactors.push('Sensitive civic zone proximity (School/Hospital area)');
    }

    // Confidence calculation (0.84 to 0.96)
    const baseConfidence = 0.82;
    const bonus = Math.min(0.14, maxMatchCount * 0.03 + (criticalMatches.length > 0 ? 0.04 : 0));
    const confidence = Number((baseConfidence + bonus).toFixed(2));

    const reasoning = `Recommended ${suggestedPriority} priority for ${topCategory} (${topDepartment}). ${detectedFactors.join('. ')}.`;

    return {
      suggestedCategory: topCategory,
      suggestedPriority,
      suggestedDepartment: topDepartment,
      recommendedSlaHours: recommendedSla,
      confidence,
      reasoning,
      keyFactors: detectedFactors,
      model: 'CivicPulse Deterministic Triage Engine (Heuristic Copilot)',
      analyzedAt,
    };
  }

  private async callGeminiModel(
    apiKey: string,
    title: string,
    description: string,
    location?: string
  ): Promise<AiTriageSuggestion | null> {
    const prompt = `Analyze this civic complaint for municipal triage.
Title: ${title}
Description: ${description}
Location: ${location || 'Unknown'}

Return ONLY a valid JSON object matching this schema:
{
  "category": "Roads" | "Street Lights" | "Water Supply" | "Garbage" | "Drainage" | "Public Safety" | "Other",
  "priority": "LOW" | "MEDIUM" | "HIGH" | "CRITICAL",
  "department": "Road Maintenance" | "Street Lighting" | "Water Supply" | "Sanitation" | "Drainage" | "Public Safety" | "General Services",
  "recommendedSlaHours": 4 | 12 | 24 | 48,
  "confidence": number between 0.8 and 0.99,
  "reasoning": string summary,
  "keyFactors": array of string observations
}`;

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { responseMimeType: 'application/json' },
        }),
      }
    );

    if (!response.ok) return null;
    const json = await response.json();
    const rawText = json.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!rawText) return null;

    const parsed = JSON.parse(rawText);
    return {
      suggestedCategory: parsed.category,
      suggestedPriority: parsed.priority,
      suggestedDepartment: parsed.department,
      recommendedSlaHours: parsed.recommendedSlaHours || 24,
      confidence: parsed.confidence || 0.92,
      reasoning: parsed.reasoning || 'Categorized via Google Gemini 2.5 Flash model.',
      keyFactors: Array.isArray(parsed.keyFactors) ? parsed.keyFactors : ['GenAI Natural Language Triage'],
      model: 'Google Gemini 2.5 Flash (Cloud AI)',
      analyzedAt: new Date().toISOString(),
    };
  }

  /**
   * Compares an incoming complaint against existing active complaints
   * to detect probable duplicates using keyword and spatial overlap.
   */
  detectDuplicates(
    target: {
      title: string;
      description: string;
      category?: string;
      location?: string;
      id?: string;
    },
    allComplaints: Complaint[]
  ): DuplicateMatchResult {
    const targetTitleTokens = this.tokenize(`${target.title} ${target.description}`);
    const targetLoc = (target.location || '').toLowerCase();

    let highestScore = 0;
    let matchedComplaint: Complaint | null = null;
    let matchReason = '';

    for (const other of allComplaints) {
      if (target.id && other.id === target.id) continue;
      // Focus on active/reopened complaints
      if (other.status === 'CLOSED' || other.status === 'VERIFIED / CLOSED') continue;

      let score = 0;
      const reasons: string[] = [];

      // Category match
      if (target.category && other.category === target.category) {
        score += 30;
        reasons.push('Same category');
      }

      // Location / Ward match
      const otherLoc = (other.location || '').toLowerCase();
      if (targetLoc && otherLoc) {
        const targetWardMatch = targetLoc.match(/ward\s*\d+|sector\s*\d+/i);
        const otherWardMatch = otherLoc.match(/ward\s*\d+|sector\s*\d+/i);

        if (targetWardMatch && otherWardMatch && targetWardMatch[0] === otherWardMatch[0]) {
          score += 30;
          reasons.push(`Same ward (${targetWardMatch[0].toUpperCase()})`);
        } else if (targetLoc.includes(otherLoc.slice(0, 12)) || otherLoc.includes(targetLoc.slice(0, 12))) {
          score += 25;
          reasons.push('Overlapping street name');
        }
      }

      // Token overlap
      const otherTokens = this.tokenize(`${other.title} ${other.description}`);
      const intersection = targetTitleTokens.filter((t) => otherTokens.includes(t));
      const overlapRatio = intersection.length / Math.max(1, Math.min(targetTitleTokens.length, otherTokens.length));

      if (overlapRatio > 0.35) {
        score += Math.min(40, Math.round(overlapRatio * 50));
        reasons.push(`Key terms match: "${intersection.slice(0, 2).join('", "')}"`);
      }

      if (score > highestScore) {
        highestScore = score;
        matchedComplaint = other;
        matchReason = reasons.join(' • ');
      }
    }

    if (highestScore >= 55 && matchedComplaint) {
      return {
        isDuplicate: true,
        matchedComplaintId: matchedComplaint.id,
        matchedTitle: matchedComplaint.title,
        similarity: Math.min(98, highestScore),
        reason: matchReason || 'High semantic and geographical overlap with existing report',
      };
    }

    return {
      isDuplicate: false,
      similarity: highestScore,
      reason: 'No significant duplicate detected',
    };
  }

  private tokenize(text: string): string[] {
    const stopWords = new Set([
      'the',
      'and',
      'a',
      'an',
      'in',
      'on',
      'at',
      'of',
      'for',
      'with',
      'is',
      'to',
      'near',
      'by',
      'this',
      'that',
      'from',
      'or',
      'has',
      'have',
      'it',
      'been',
    ]);
    return text
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, ' ')
      .split(/\s+/)
      .filter((w) => w.length > 2 && !stopWords.has(w));
  }
}

export const aiService = new AiTriageService();
