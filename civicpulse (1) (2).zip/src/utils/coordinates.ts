import { Complaint } from '../types';

export interface GeoCoordinate {
  lat: number;
  lng: number;
}

// Bounding box for the Metro Civic District
export const DISTRICT_CENTER: GeoCoordinate = { lat: 37.7749, lng: -122.4194 };

export const WARD_LOCATIONS: Record<string, GeoCoordinate> = {
  'Ward 7': { lat: 37.7765, lng: -122.4182 },
  'Ward 12': { lat: 37.7821, lng: -122.4245 },
  'Sector 8': { lat: 37.7690, lng: -122.4110 },
  'Sector 4': { lat: 37.7632, lng: -122.4280 },
  'Ward 5': { lat: 37.7885, lng: -122.4150 },
  'Lakeview Colony': { lat: 37.7550, lng: -122.4350 },
  'Central Ring Road': { lat: 37.7765, lng: -122.4182 },
  'Oak Lane': { lat: 37.7821, lng: -122.4245 },
  'North Avenue': { lat: 37.7690, lng: -122.4110 },
  'Pine Crest': { lat: 37.7632, lng: -122.4280 },
  'Market Square': { lat: 37.7885, lng: -122.4150 },
  'Civic Center': { lat: 37.7790, lng: -122.4180 },
  'West End': { lat: 37.7710, lng: -122.4320 },
  'South Bay Area': { lat: 37.7580, lng: -122.4120 },
};

/**
 * Returns accurate or deterministic coordinates for any complaint
 */
export function getComplaintCoordinates(complaint: Complaint): GeoCoordinate {
  if (
    complaint.coordinates &&
    typeof complaint.coordinates.lat === 'number' &&
    typeof complaint.coordinates.lng === 'number' &&
    !isNaN(complaint.coordinates.lat) &&
    !isNaN(complaint.coordinates.lng)
  ) {
    return complaint.coordinates;
  }

  // Match known landmarks in location string
  const locLower = complaint.location.toLowerCase();
  for (const [name, coords] of Object.entries(WARD_LOCATIONS)) {
    if (locLower.includes(name.toLowerCase())) {
      // Add tiny deterministic jitter based on ID to avoid perfect overlap of markers
      const charCodeSum = complaint.id.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0);
      const jitterLat = ((charCodeSum % 11) - 5) * 0.0006;
      const jitterLng = (((charCodeSum * 3) % 11) - 5) * 0.0006;
      return {
        lat: Number((coords.lat + jitterLat).toFixed(5)),
        lng: Number((coords.lng + jitterLng).toFixed(5)),
      };
    }
  }

  // Deterministic fallback based on complaint ID hash within district bounds
  const hash = complaint.id.split('').reduce((acc, c) => acc * 31 + c.charCodeAt(0), 0);
  const offsetLat = (((Math.abs(hash) % 100) - 50) / 100) * 0.025;
  const offsetLng = (((Math.abs(hash >> 2) % 100) - 50) / 100) * 0.025;

  return {
    lat: Number((DISTRICT_CENTER.lat + offsetLat).toFixed(5)),
    lng: Number((DISTRICT_CENTER.lng + offsetLng).toFixed(5)),
  };
}

/**
 * Extract ward / sector name cleanly from location string
 */
export function extractWardName(location: string): string {
  const match = location.match(/(Ward\s*\d+|Sector\s*\d+|Lakeview\s*Colony|Market\s*Square|Central\s*Ring)/i);
  if (match) return match[0];
  const parts = location.split(',');
  if (parts.length > 1) return parts[parts.length - 1].trim();
  return location.trim() || 'Ward 7';
}

export const ZONE_MAPPING: Record<string, string> = {
  'Ward 1': 'North Zone',
  'Ward 2': 'North Zone',
  'Ward 5': 'North Zone',
  'Sector 8': 'North Zone',
  'North Avenue': 'North Zone',
  'Ward 3': 'South Zone',
  'Ward 4': 'South Zone',
  'Sector 4': 'South Zone',
  'South Bay Area': 'South Zone',
  'Lakeview Colony': 'South Zone',
  'Ward 6': 'East Zone',
  'Ward 7': 'East Zone',
  'Central Ring Road': 'East Zone',
  'Ward 8': 'West Zone',
  'Ward 9': 'West Zone',
  'West End': 'West Zone',
  'Pine Crest': 'West Zone',
  'Ward 10': 'Central Zone',
  'Ward 11': 'Central Zone',
  'Ward 12': 'Central Zone',
  'Civic Center': 'Central Zone',
  'Market Square': 'Central Zone',
  'Oak Lane': 'Central Zone',
};

/**
 * Deterministically identify Municipal Zone (North, South, East, West, Central)
 */
export function extractZoneName(location: string, ward?: string): string {
  const targetWard = ward || extractWardName(location);
  if (ZONE_MAPPING[targetWard]) {
    return ZONE_MAPPING[targetWard];
  }
  for (const [key, zone] of Object.entries(ZONE_MAPPING)) {
    if (location.toLowerCase().includes(key.toLowerCase())) {
      return zone;
    }
  }
  return 'Central Zone';
}

export interface HotspotCluster {
  wardName: string;
  zoneName: string;
  count: number;
  criticalCount: number;
  dominantCategory: string;
  complaintIds: string[];
  severity: 'CRITICAL' | 'HIGH' | 'MODERATE';
}

/**
 * Calculates active hotspot clusters across the municipal grid
 */
export function calculateHotspots(complaints: Complaint[]): HotspotCluster[] {
  const active = complaints.filter(
    (c) => c.status !== 'CLOSED' && c.status !== 'VERIFIED / CLOSED'
  );

  const wardMap: Record<
    string,
    {
      count: number;
      criticalCount: number;
      categories: Record<string, number>;
      ids: string[];
      zone: string;
    }
  > = {};

  active.forEach((c) => {
    const ward = c.ward || extractWardName(c.location);
    const zone = c.zone || extractZoneName(c.location, ward);

    if (!wardMap[ward]) {
      wardMap[ward] = {
        count: 0,
        criticalCount: 0,
        categories: {},
        ids: [],
        zone,
      };
    }

    wardMap[ward].count += 1;
    if (c.priority === 'CRITICAL' || c.priority === 'HIGH') {
      wardMap[ward].criticalCount += 1;
    }
    wardMap[ward].ids.push(c.id);
    wardMap[ward].categories[c.category] = (wardMap[ward].categories[c.category] || 0) + 1;
  });

  return Object.entries(wardMap)
    .filter(([_, data]) => data.count >= 2)
    .map(([ward, data]) => {
      let dominantCategory = 'General';
      let maxCatCount = 0;
      Object.entries(data.categories).forEach(([cat, cnt]) => {
        if (cnt > maxCatCount) {
          maxCatCount = cnt;
          dominantCategory = cat;
        }
      });

      const severity: 'CRITICAL' | 'HIGH' | 'MODERATE' =
        data.criticalCount >= 2 || data.count >= 4
          ? 'CRITICAL'
          : data.count >= 3 || data.criticalCount >= 1
          ? 'HIGH'
          : 'MODERATE';

      return {
        wardName: ward,
        zoneName: data.zone,
        count: data.count,
        criticalCount: data.criticalCount,
        dominantCategory,
        complaintIds: data.ids,
        severity,
      };
    })
    .sort((a, b) => b.count - a.count);
}

/**
 * Privacy Safeguard: Mask citizen phone number for public/prototype displays
 */
export function maskSensitiveContact(phone?: string, mask: boolean = true): string {
  if (!phone) return 'Not Provided';
  if (!mask) return phone;

  // Mask middle digits: e.g. +1 (555) 782-9012 -> +1 (555) •••-9012
  const cleaned = phone.trim();
  if (cleaned.length < 7) return '•••••••';
  
  const lastFour = cleaned.slice(-4);
  const prefix = cleaned.slice(0, cleaned.length - 8);
  return `${prefix || '+1 (555)'} •••-${lastFour}`;
}
