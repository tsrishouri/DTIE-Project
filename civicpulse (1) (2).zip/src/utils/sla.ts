export interface SlaInfo {
  status: 'NORMAL' | 'DUE_SOON' | 'BREACHED' | 'NOT_SET';
  label: string;
  badgeClass: string;
  textColor: string;
  dotColor: string;
  remainingHours: number | null;
}

export function calculateSla(deadline?: string): SlaInfo {
  if (!deadline) {
    return {
      status: 'NOT_SET',
      label: 'SLA: Not Set',
      badgeClass: 'bg-slate-100 text-slate-600 border-slate-200',
      textColor: 'text-slate-600',
      dotColor: 'bg-slate-400',
      remainingHours: null,
    };
  }

  const deadlineMs = new Date(deadline).getTime();
  const nowMs = Date.now();
  const diffHours = (deadlineMs - nowMs) / (1000 * 60 * 60);

  if (diffHours < 0) {
    const overdueHours = Math.abs(Math.round(diffHours));
    return {
      status: 'BREACHED',
      label: `SLA BREACHED (${overdueHours}h overdue)`,
      badgeClass: 'bg-rose-100 text-rose-800 border-rose-300 font-bold',
      textColor: 'text-rose-700',
      dotColor: 'bg-rose-600 animate-pulse',
      remainingHours: Math.round(diffHours),
    };
  }

  if (diffHours <= 6) {
    const hours = Math.max(1, Math.round(diffHours));
    return {
      status: 'DUE_SOON',
      label: `SLA: Due Soon (${hours}h remaining)`,
      badgeClass: 'bg-amber-100 text-amber-900 border-amber-300 font-semibold',
      textColor: 'text-amber-700',
      dotColor: 'bg-amber-500 animate-ping',
      remainingHours: hours,
    };
  }

  const hours = Math.round(diffHours);
  if (hours >= 48) {
    const days = Math.round(hours / 24);
    return {
      status: 'NORMAL',
      label: `SLA: ${days}d remaining`,
      badgeClass: 'bg-emerald-50 text-emerald-800 border-emerald-300 font-medium',
      textColor: 'text-emerald-700',
      dotColor: 'bg-emerald-500',
      remainingHours: hours,
    };
  }

  return {
    status: 'NORMAL',
    label: `SLA: ${hours}h remaining`,
    badgeClass: 'bg-emerald-50 text-emerald-800 border-emerald-300 font-medium',
    textColor: 'text-emerald-700',
    dotColor: 'bg-emerald-500',
    remainingHours: hours,
  };
}
