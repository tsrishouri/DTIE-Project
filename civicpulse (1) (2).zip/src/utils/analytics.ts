import { Complaint, ComplaintCategory, ComplaintStatus, MunicipalDepartment } from '../types';
import { extractWardName } from './coordinates';

export interface KpiMetrics {
  totalComplaints: number;
  activeComplaints: number;
  resolvedComplaints: number;
  awaitingVerification: number;
  reopenedComplaints: number;
  slaComplianceRate: number | null; // e.g. 92.5 (%)
  slaBreachedCount: number;
  avgResolutionHours: number | null;
  avgResolutionFormatted: string;
  citizenVerificationRate: number | null; // e.g. 85 (%)
}

export interface StageFunnelItem {
  stage: ComplaintStatus | string;
  label: string;
  count: number;
  percentage: number;
  color: string;
  description: string;
}

export interface CategoryMetric {
  category: ComplaintCategory;
  total: number;
  active: number;
  resolved: number;
  reopened: number;
  percentage: number;
  color: string;
}

export interface DepartmentMetric {
  department: string;
  totalAssigned: number;
  resolved: number;
  inProgress: number;
  slaCompliance: number;
  avgHours: number | null;
}

export interface WardHotspot {
  wardName: string;
  totalIssues: number;
  activeIssues: number;
  resolvedIssues: number;
  reopenedIssues: number;
  dominantCategory: ComplaintCategory;
  primaryLocation: string;
}

export interface BottleneckItem {
  stage: string;
  avgHours: number;
  sampleCount: number;
  severity: 'low' | 'medium' | 'high';
  insight: string;
}

export interface CivicImpactData {
  citizensServed: number;
  potholesRepaired: number;
  streetLightsIlluminated: number;
  waterPreservedGallons: number;
  wasteTonsCleared: number;
  drainsUnclogged: number;
  civicTrustScore: number;
}

/**
 * Computes all operations KPI metrics strictly from real complaint data
 */
export function calculateKpis(complaints: Complaint[]): KpiMetrics {
  const totalComplaints = complaints.length;

  if (totalComplaints === 0) {
    return {
      totalComplaints: 0,
      activeComplaints: 0,
      resolvedComplaints: 0,
      awaitingVerification: 0,
      reopenedComplaints: 0,
      slaComplianceRate: null,
      slaBreachedCount: 0,
      avgResolutionHours: null,
      avgResolutionFormatted: 'No closed issues',
      citizenVerificationRate: null,
    };
  }

  const activeComplaints = complaints.filter(
    (c) => c.status !== 'CLOSED' && c.status !== 'VERIFIED / CLOSED'
  ).length;

  const resolvedList = complaints.filter(
    (c) =>
      c.status === 'CLOSED' ||
      c.status === 'VERIFIED / CLOSED' ||
      c.status === 'VERIFIED'
  );
  const resolvedComplaints = resolvedList.length;

  const awaitingVerification = complaints.filter(
    (c) => c.status === 'AWAITING VERIFICATION' || c.status === 'RESOLUTION SUBMITTED'
  ).length;

  const reopenedComplaints = complaints.filter((c) => c.status === 'REOPENED').length;

  // SLA Compliance among resolved complaints that had an SLA deadline
  let closedWithSla = 0;
  let metSlaCount = 0;
  let slaBreachedCount = 0;

  complaints.forEach((c) => {
    if (c.deadline) {
      const deadlineMs = new Date(c.deadline).getTime();
      const isResolved =
        c.status === 'CLOSED' ||
        c.status === 'VERIFIED / CLOSED' ||
        c.status === 'VERIFIED';

      if (isResolved) {
        closedWithSla++;
        // Determine completion timestamp
        const completedTimeMs = c.closedAt
          ? new Date(c.closedAt).getTime()
          : c.verifiedAt
          ? new Date(c.verifiedAt).getTime()
          : c.evidence?.submittedAt
          ? new Date(c.evidence.submittedAt).getTime()
          : new Date(c.updatedAt).getTime();

        if (completedTimeMs <= deadlineMs) {
          metSlaCount++;
        } else {
          slaBreachedCount++;
        }
      } else {
        // For active complaints with deadline breached
        if (Date.now() > deadlineMs) {
          slaBreachedCount++;
        }
      }
    }
  });

  const slaComplianceRate =
    closedWithSla > 0
      ? Math.round((metSlaCount / closedWithSla) * 100)
      : complaints.some((c) => c.deadline)
      ? 100
      : null;

  // Average Resolution Time (REPORTED to CLOSED)
  let totalResolutionHours = 0;
  let validResolutionCount = 0;

  resolvedList.forEach((c) => {
    const createdMs = new Date(c.createdAt).getTime();
    const endMs = c.closedAt
      ? new Date(c.closedAt).getTime()
      : c.verifiedAt
      ? new Date(c.verifiedAt).getTime()
      : c.evidence?.submittedAt
      ? new Date(c.evidence.submittedAt).getTime()
      : new Date(c.updatedAt).getTime();

    if (endMs > createdMs) {
      const diffHours = (endMs - createdMs) / (1000 * 3600);
      totalResolutionHours += diffHours;
      validResolutionCount++;
    }
  });

  const avgResolutionHours =
    validResolutionCount > 0
      ? Number((totalResolutionHours / validResolutionCount).toFixed(1))
      : null;

  let avgResolutionFormatted = 'N/A (No closed data)';
  if (avgResolutionHours !== null) {
    if (avgResolutionHours < 24) {
      avgResolutionFormatted = `${avgResolutionHours} hrs`;
    } else {
      const days = (avgResolutionHours / 24).toFixed(1);
      avgResolutionFormatted = `${days} days (${avgResolutionHours} hrs)`;
    }
  }

  // Citizen Verification Rate:
  // Complaints verified/closed / (verified/closed + reopened)
  const evaluatedCount = resolvedComplaints + reopenedComplaints;
  const citizenVerificationRate =
    evaluatedCount > 0
      ? Math.round((resolvedComplaints / evaluatedCount) * 100)
      : null;

  return {
    totalComplaints,
    activeComplaints,
    resolvedComplaints,
    awaitingVerification,
    reopenedComplaints,
    slaComplianceRate,
    slaBreachedCount,
    avgResolutionHours,
    avgResolutionFormatted,
    citizenVerificationRate,
  };
}

/**
 * 6-Stage Resolution Performance Funnel
 */
export function calculateFunnelStages(complaints: Complaint[]): StageFunnelItem[] {
  const total = Math.max(1, complaints.length);

  const reportedCount = complaints.filter((c) => c.status === 'REPORTED').length;
  const triagedCount = complaints.filter((c) => c.status === 'TRIAGED').length;
  const assignedCount = complaints.filter((c) => c.status === 'ASSIGNED').length;
  const inProgressCount = complaints.filter((c) => c.status === 'IN PROGRESS').length;
  const awaitingCount = complaints.filter(
    (c) => c.status === 'AWAITING VERIFICATION' || c.status === 'RESOLUTION SUBMITTED'
  ).length;
  const closedCount = complaints.filter(
    (c) =>
      c.status === 'CLOSED' ||
      c.status === 'VERIFIED / CLOSED' ||
      c.status === 'VERIFIED'
  ).length;

  return [
    {
      stage: 'REPORTED',
      label: '1. Reported',
      count: reportedCount,
      percentage: Math.round((reportedCount / total) * 100),
      color: 'bg-blue-500',
      description: 'Newly registered citizen tickets awaiting municipal triage.',
    },
    {
      stage: 'TRIAGED',
      label: '2. Triaged',
      count: triagedCount,
      percentage: Math.round((triagedCount / total) * 100),
      color: 'bg-sky-500',
      description: 'Assessed for priority, department allocation and SLA deadline.',
    },
    {
      stage: 'ASSIGNED',
      label: '3. Assigned',
      count: assignedCount,
      percentage: Math.round((assignedCount / total) * 100),
      color: 'bg-amber-500',
      description: 'Dispatched to specialized field technicians or work crews.',
    },
    {
      stage: 'IN PROGRESS',
      label: '4. In Progress',
      count: inProgressCount,
      percentage: Math.round((inProgressCount / total) * 100),
      color: 'bg-orange-500',
      description: 'Active on-site repair, excavation, wiring or sanitation.',
    },
    {
      stage: 'AWAITING VERIFICATION',
      label: '5. Awaiting Verification',
      count: awaitingCount,
      percentage: Math.round((awaitingCount / total) * 100),
      color: 'bg-teal-500',
      description: 'Resolution evidence submitted; resident confirmation pending.',
    },
    {
      stage: 'CLOSED',
      label: '6. Closed',
      count: closedCount,
      percentage: Math.round((closedCount / total) * 100),
      color: 'bg-emerald-600',
      description: 'Formally closed with verified citizen confirmation.',
    },
  ];
}

/**
 * Category-wise breakdown
 */
export function calculateCategoryBreakdown(complaints: Complaint[]): CategoryMetric[] {
  const categories: ComplaintCategory[] = [
    'Roads',
    'Street Lights',
    'Water Supply',
    'Garbage',
    'Drainage',
    'Public Safety',
    'Other',
  ];

  const total = Math.max(1, complaints.length);

  const colorMap: Record<ComplaintCategory, string> = {
    'Roads': 'from-amber-500 to-amber-600',
    'Street Lights': 'from-yellow-400 to-orange-500',
    'Water Supply': 'from-blue-500 to-cyan-600',
    'Garbage': 'from-emerald-500 to-teal-600',
    'Drainage': 'from-teal-500 to-cyan-700',
    'Public Safety': 'from-rose-500 to-red-600',
    'Other': 'from-slate-500 to-slate-700',
  };

  return categories.map((cat) => {
    const list = complaints.filter((c) => c.category === cat);
    const catTotal = list.length;
    const resolved = list.filter(
      (c) =>
        c.status === 'CLOSED' ||
        c.status === 'VERIFIED / CLOSED' ||
        c.status === 'VERIFIED'
    ).length;
    const reopened = list.filter((c) => c.status === 'REOPENED').length;
    const active = catTotal - resolved;

    return {
      category: cat,
      total: catTotal,
      active,
      resolved,
      reopened,
      percentage: complaints.length > 0 ? Math.round((catTotal / total) * 100) : 0,
      color: colorMap[cat] || 'from-slate-500 to-slate-600',
    };
  });
}

/**
 * Department Performance Ranking
 */
export function calculateDepartmentPerformance(complaints: Complaint[]): DepartmentMetric[] {
  const deptMap: Record<string, { total: number; resolved: number; inProgress: number; onTime: number; withSla: number; hoursSum: number; hoursCount: number }> = {};

  complaints.forEach((c) => {
    const dept = c.department || c.assignedDepartment || 'General Services';
    if (!deptMap[dept]) {
      deptMap[dept] = { total: 0, resolved: 0, inProgress: 0, onTime: 0, withSla: 0, hoursSum: 0, hoursCount: 0 };
    }

    const d = deptMap[dept];
    d.total++;

    if (c.status === 'IN PROGRESS') d.inProgress++;

    const isResolved =
      c.status === 'CLOSED' ||
      c.status === 'VERIFIED / CLOSED' ||
      c.status === 'VERIFIED';

    if (isResolved) {
      d.resolved++;
      const createdMs = new Date(c.createdAt).getTime();
      const endMs = c.closedAt
        ? new Date(c.closedAt).getTime()
        : c.verifiedAt
        ? new Date(c.verifiedAt).getTime()
        : new Date(c.updatedAt).getTime();
      if (endMs > createdMs) {
        d.hoursSum += (endMs - createdMs) / (1000 * 3600);
        d.hoursCount++;
      }

      if (c.deadline) {
        d.withSla++;
        if (endMs <= new Date(c.deadline).getTime()) {
          d.onTime++;
        }
      }
    }
  });

  return Object.entries(deptMap).map(([department, data]) => {
    const slaCompliance = data.withSla > 0 ? Math.round((data.onTime / data.withSla) * 100) : 100;
    const avgHours = data.hoursCount > 0 ? Number((data.hoursSum / data.hoursCount).toFixed(1)) : null;

    return {
      department,
      totalAssigned: data.total,
      resolved: data.resolved,
      inProgress: data.inProgress,
      slaCompliance,
      avgHours,
    };
  }).sort((a, b) => b.totalAssigned - a.totalAssigned);
}

/**
 * Ward & Location Hotspot Clusters
 */
export function calculateWardHotspots(complaints: Complaint[]): WardHotspot[] {
  const map: Record<string, { total: number; active: number; resolved: number; reopened: number; categories: Record<ComplaintCategory, number>; sampleLocation: string }> = {};

  complaints.forEach((c) => {
    const ward = extractWardName(c.location);
    if (!map[ward]) {
      map[ward] = {
        total: 0,
        active: 0,
        resolved: 0,
        reopened: 0,
        categories: {
          'Roads': 0,
          'Street Lights': 0,
          'Water Supply': 0,
          'Garbage': 0,
          'Drainage': 0,
          'Public Safety': 0,
          'Other': 0,
        },
        sampleLocation: c.location,
      };
    }

    const item = map[ward];
    item.total++;
    item.categories[c.category] = (item.categories[c.category] || 0) + 1;

    if (c.status === 'REOPENED') {
      item.reopened++;
      item.active++;
    } else if (
      c.status === 'CLOSED' ||
      c.status === 'VERIFIED / CLOSED' ||
      c.status === 'VERIFIED'
    ) {
      item.resolved++;
    } else {
      item.active++;
    }
  });

  return Object.entries(map).map(([wardName, data]) => {
    // Determine dominant category
    let topCat: ComplaintCategory = 'Roads';
    let maxCount = -1;
    (Object.entries(data.categories) as [ComplaintCategory, number][]).forEach(([cat, count]) => {
      if (count > maxCount) {
        maxCount = count;
        topCat = cat;
      }
    });

    return {
      wardName,
      totalIssues: data.total,
      activeIssues: data.active,
      resolvedIssues: data.resolved,
      reopenedIssues: data.reopened,
      dominantCategory: topCat,
      primaryLocation: data.sampleLocation,
    };
  }).sort((a, b) => b.totalIssues - a.totalIssues);
}

/**
 * Operational Bottleneck Diagnosis
 */
export function calculateBottlenecks(complaints: Complaint[]): BottleneckItem[] {
  let triageHoursSum = 0;
  let triageCount = 0;

  let assignHoursSum = 0;
  let assignCount = 0;

  let resolveHoursSum = 0;
  let resolveCount = 0;

  let verifyHoursSum = 0;
  let verifyCount = 0;

  complaints.forEach((c) => {
    let reportTime: number | null = null;
    let triageTime: number | null = null;
    let assignTime: number | null = null;
    let resolveTime: number | null = null;
    let verifyTime: number | null = null;

    c.timeline.forEach((log) => {
      const timeMs = new Date(log.timestamp).getTime();
      if (log.status === 'REPORTED' && reportTime === null) reportTime = timeMs;
      if (log.status === 'TRIAGED' && triageTime === null) triageTime = timeMs;
      if (log.status === 'ASSIGNED' && assignTime === null) assignTime = timeMs;
      if (log.status === 'RESOLUTION SUBMITTED' && resolveTime === null) resolveTime = timeMs;
      if ((log.status === 'VERIFIED' || log.status === 'CLOSED') && verifyTime === null) verifyTime = timeMs;
    });

    if (reportTime && triageTime && triageTime >= reportTime) {
      triageHoursSum += (triageTime - reportTime) / (1000 * 3600);
      triageCount++;
    }

    if (triageTime && assignTime && assignTime >= triageTime) {
      assignHoursSum += (assignTime - triageTime) / (1000 * 3600);
      assignCount++;
    }

    if (assignTime && resolveTime && resolveTime >= assignTime) {
      resolveHoursSum += (resolveTime - assignTime) / (1000 * 3600);
      resolveCount++;
    }

    if (resolveTime && verifyTime && verifyTime >= resolveTime) {
      verifyHoursSum += (verifyTime - resolveTime) / (1000 * 3600);
      verifyCount++;
    }
  });

  const avgTriage = triageCount > 0 ? Number((triageHoursSum / triageCount).toFixed(1)) : 2.5;
  const avgAssign = assignCount > 0 ? Number((assignHoursSum / assignCount).toFixed(1)) : 1.8;
  const avgResolve = resolveCount > 0 ? Number((resolveHoursSum / resolveCount).toFixed(1)) : 22.4;
  const avgVerify = verifyCount > 0 ? Number((verifyHoursSum / verifyCount).toFixed(1)) : 8.2;

  return [
    {
      stage: 'Triage & Assessment',
      avgHours: avgTriage,
      sampleCount: triageCount,
      severity: avgTriage > 8 ? 'high' : avgTriage > 4 ? 'medium' : 'low',
      insight: avgTriage < 4 ? 'Optimal response: Supervisors categorize issues rapidly.' : 'Delayed initial assessment by dispatch desk.',
    },
    {
      stage: 'Field Dispatch & Crew Assignment',
      avgHours: avgAssign,
      sampleCount: assignCount,
      severity: avgAssign > 6 ? 'high' : avgAssign > 3 ? 'medium' : 'low',
      insight: avgAssign < 3 ? 'Efficient crew matching: Technicians dispatched promptly.' : 'Crew capacity bottleneck during peak shifts.',
    },
    {
      stage: 'On-Site Field Execution',
      avgHours: avgResolve,
      sampleCount: resolveCount,
      severity: avgResolve > 36 ? 'high' : avgResolve > 18 ? 'medium' : 'low',
      insight: 'Primary operational duration involving procurement, welding, paving & electrical tests.',
    },
    {
      stage: 'Citizen Resolution Verification',
      avgHours: avgVerify,
      sampleCount: verifyCount,
      severity: avgVerify > 24 ? 'high' : avgVerify > 12 ? 'medium' : 'low',
      insight: 'Residents inspect repairs and confirm satisfactory resolution closure.',
    },
  ];
}

/**
 * Measurable Civic Impact Quantifier
 */
export function calculateCivicImpact(complaints: Complaint[]): CivicImpactData {
  const resolvedList = complaints.filter(
    (c) =>
      c.status === 'CLOSED' ||
      c.status === 'VERIFIED / CLOSED' ||
      c.status === 'VERIFIED'
  );

  let potholesRepaired = 0;
  let streetLightsIlluminated = 0;
  let waterPreservedGallons = 0;
  let wasteTonsCleared = 0;
  let drainsUnclogged = 0;

  resolvedList.forEach((c) => {
    switch (c.category) {
      case 'Roads':
        potholesRepaired += 1;
        break;
      case 'Street Lights':
        streetLightsIlluminated += 2; // array or multiple luminaires
        break;
      case 'Water Supply':
        waterPreservedGallons += 4500; // estimated drinking water saved from rupture
        break;
      case 'Garbage':
        wasteTonsCleared += 2.4; // tonnage from compactor
        break;
      case 'Drainage':
        drainsUnclogged += 1;
        break;
      default:
        break;
    }
  });

  // Citizens protected & served (estimated average neighborhood footprint per resolution)
  const citizensServed = resolvedList.length * 480;

  // Civic Trust Score
  const totalEvaluated = resolvedList.length + complaints.filter((c) => c.status === 'REOPENED').length;
  const civicTrustScore = totalEvaluated > 0
    ? Math.round((resolvedList.length / totalEvaluated) * 100)
    : 100;

  return {
    citizensServed,
    potholesRepaired,
    streetLightsIlluminated,
    waterPreservedGallons,
    wasteTonsCleared: Number(wasteTonsCleared.toFixed(1)),
    drainsUnclogged,
    civicTrustScore,
  };
}
